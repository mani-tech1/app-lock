import express from 'express';
import rateLimit from 'express-rate-limit';
import crypto from 'node:crypto';

// ---------- config ----------
const env = process.env;
const PROD = env.NODE_ENV === 'production';
const PORT = Number(env.PORT || 3000);
const PROVIDER = (env.EMAIL_PROVIDER || 'console').toLowerCase();
const FROM_EMAIL = env.FROM_EMAIL || '';
const FROM_NAME = env.FROM_NAME || 'App Locker';
const OTP_TTL_SEC = Number(env.OTP_TTL_SEC || 600);
const RESEND_COOLDOWN_SEC = Number(env.RESEND_COOLDOWN_SEC || 60);
const MAX_ATTEMPTS = Number(env.MAX_ATTEMPTS || 5);
const LOCKOUT_SEC = Number(env.LOCKOUT_SEC || 900);
const MAX_SENDS_PER_HOUR = Number(env.MAX_SENDS_PER_HOUR || 5);

const SECRET = env.OTP_SECRET || '';
if (!SECRET || SECRET === 'change-me') {
  if (PROD) {
    console.error('OTP_SECRET is missing. Refusing to start.');
    process.exit(1);
  }
  console.warn('WARNING: OTP_SECRET not set, using an insecure development secret.');
}
const KEY = SECRET || 'dev-only-insecure-secret';

if (PROD && PROVIDER === 'console') {
  console.error('EMAIL_PROVIDER=console is not allowed in production. Refusing to start.');
  process.exit(1);
}

// ---------- state (in memory: a restart only means "ask for a new code") ----------
const otps = new Map();   // key -> { hash, expiresAt, attempts, lastSentAt }
const locks = new Map();  // key -> lockedUntil (ms)
const sends = new Map();  // email -> [timestamps within the last hour]

setInterval(() => {
  const now = Date.now();
  for (const [k, v] of otps) if (v.expiresAt < now) otps.delete(k);
  for (const [k, t] of locks) if (t < now) locks.delete(k);
  for (const [k, arr] of sends) {
    const fresh = arr.filter((t) => now - t < 3_600_000);
    if (fresh.length) sends.set(k, fresh); else sends.delete(k);
  }
}, 60_000).unref();

// ---------- helpers ----------
const hmac = (data) => crypto.createHmac('sha256', KEY).update(data).digest();
const b64url = (buf) => buf.toString('base64url');

function safeEqual(a, b) {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/;
const UUID_RE = /^[0-9a-fA-F-]{36}$/;

function parseCommon(body) {
  const email = String(body?.email ?? '').trim().toLowerCase();
  const deviceId = String(body?.deviceId ?? '');
  const purpose = String(body?.purpose ?? '');
  if (email.length > 254 || !EMAIL_RE.test(email)) return null;
  if (!UUID_RE.test(deviceId)) return null;
  if (purpose !== 'register' && purpose !== 'reset') return null;
  return { email, deviceId, purpose };
}

const keyOf = (c) => `${c.purpose}|${c.email}|${c.deviceId}`;
const proofFor = (deviceId, email) => b64url(hmac(`proof|${deviceId}|${email}`));
const codeHash = (key, code) => b64url(hmac(`otp|${key}|${code}`));
const secondsLeft = (ms) => Math.max(1, Math.ceil(ms / 1000));

function fail(res, status, error, extra = {}) {
  return res.status(status).json({ ok: false, error, ...extra });
}

// ---------- email ----------
async function postJson(url, headers, payload) {
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json', ...headers },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(15_000),
  });
  if (!r.ok) throw new Error(`email provider responded ${r.status}`);
}

async function sendEmail(to, subject, text, html) {
  switch (PROVIDER) {
    case 'brevo':
      return postJson('https://api.brevo.com/v3/smtp/email', { 'api-key': env.BREVO_API_KEY || '' }, {
        sender: { email: FROM_EMAIL, name: FROM_NAME },
        to: [{ email: to }],
        subject,
        textContent: text,
        htmlContent: html,
      });
    case 'resend':
      return postJson('https://api.resend.com/emails', { authorization: `Bearer ${env.RESEND_API_KEY || ''}` }, {
        from: `${FROM_NAME} <${FROM_EMAIL}>`,
        to: [to],
        subject,
        text,
        html,
      });
    case 'smtp': {
      const { default: nodemailer } = await import('nodemailer');
      const transport = nodemailer.createTransport({
        host: env.SMTP_HOST,
        port: Number(env.SMTP_PORT || 587),
        secure: Number(env.SMTP_PORT) === 465,
        auth: { user: env.SMTP_USER, pass: env.SMTP_PASS },
        connectionTimeout: 15_000,
        socketTimeout: 15_000,
      });
      await transport.sendMail({ from: `"${FROM_NAME}" <${FROM_EMAIL}>`, to, subject, text, html });
      return;
    }
    case 'console':
      console.log(`[DEV EMAIL] to=${to} | ${text}`);
      return;
    default:
      throw new Error(`unknown EMAIL_PROVIDER "${PROVIDER}"`);
  }
}

function otpMessage(code, purpose) {
  const why = purpose === 'register'
    ? 'verify your recovery email'
    : 'reset your PIN';
  const mins = Math.round(OTP_TTL_SEC / 60);
  const text = `Your App Locker code is ${code}. Use it to ${why}. It expires in ${mins} minutes. If you did not ask for this, ignore this email.`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:420px">
    <p>Use this code to ${why}:</p>
    <p style="font-size:32px;letter-spacing:6px;font-weight:bold">${code}</p>
    <p>It expires in ${mins} minutes. If you did not ask for this, ignore this email.</p></div>`;
  return { subject: 'Your App Locker verification code', text, html };
}

// ---------- app ----------
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(express.json({ limit: '2kb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));

const ipLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) =>
    fail(res, 429, 'RATE_LIMITED', { retryAfterSec: 600 }),
});
app.use('/otp', ipLimiter);

app.post('/otp/send', async (req, res) => {
  const c = parseCommon(req.body);
  if (!c) return fail(res, 400, 'INVALID_INPUT');

  // Resetting is only allowed for the email this phone verified earlier.
  if (c.purpose === 'reset') {
    const given = String(req.body?.proof ?? '');
    if (!given || !safeEqual(given, proofFor(c.deviceId, c.email))) {
      return fail(res, 403, 'BAD_PROOF');
    }
  }

  const key = keyOf(c);
  const now = Date.now();

  const lockedUntil = locks.get(key) || 0;
  if (lockedUntil > now) {
    return fail(res, 429, 'LOCKED', { retryAfterSec: secondsLeft(lockedUntil - now) });
  }

  const existing = otps.get(key);
  if (existing && now - existing.lastSentAt < RESEND_COOLDOWN_SEC * 1000) {
    const wait = RESEND_COOLDOWN_SEC * 1000 - (now - existing.lastSentAt);
    return fail(res, 429, 'COOLDOWN', { retryAfterSec: secondsLeft(wait) });
  }

  const recent = (sends.get(c.email) || []).filter((t) => now - t < 3_600_000);
  if (recent.length >= MAX_SENDS_PER_HOUR) {
    const wait = 3_600_000 - (now - recent[0]);
    return fail(res, 429, 'RATE_LIMITED', { retryAfterSec: secondsLeft(wait) });
  }

  const code = crypto.randomInt(0, 1_000_000).toString().padStart(6, '0');
  const msg = otpMessage(code, c.purpose);
  try {
    await sendEmail(c.email, msg.subject, msg.text, msg.html);
  } catch (e) {
    console.error('email send failed:', e.message);
    return fail(res, 502, 'EMAIL_FAILED');
  }

  otps.set(key, { hash: codeHash(key, code), expiresAt: now + OTP_TTL_SEC * 1000, attempts: 0, lastSentAt: now });
  sends.set(c.email, [...recent, now]);
  res.json({ ok: true, expiresInSec: OTP_TTL_SEC, resendAfterSec: RESEND_COOLDOWN_SEC });
});

app.post('/otp/verify', (req, res) => {
  const c = parseCommon(req.body);
  const code = String(req.body?.code ?? '');
  if (!c || !/^\d{6}$/.test(code)) return fail(res, 400, 'INVALID_INPUT');

  const key = keyOf(c);
  const now = Date.now();

  const lockedUntil = locks.get(key) || 0;
  if (lockedUntil > now) {
    return fail(res, 429, 'LOCKED', { retryAfterSec: secondsLeft(lockedUntil - now) });
  }

  const entry = otps.get(key);
  if (!entry || entry.expiresAt < now) {
    otps.delete(key);
    return fail(res, 400, 'EXPIRED');
  }

  if (!safeEqual(entry.hash, codeHash(key, code))) {
    entry.attempts += 1;
    if (entry.attempts >= MAX_ATTEMPTS) {
      otps.delete(key);
      locks.set(key, now + LOCKOUT_SEC * 1000);
      return fail(res, 429, 'TOO_MANY_ATTEMPTS', { retryAfterSec: LOCKOUT_SEC });
    }
    return fail(res, 400, 'INVALID_CODE', { attemptsLeft: MAX_ATTEMPTS - entry.attempts });
  }

  otps.delete(key); // one use only
  const body = { ok: true };
  if (c.purpose === 'register') body.proof = proofFor(c.deviceId, c.email);
  res.json(body);
});

app.use((_req, res) => fail(res, 404, 'NOT_FOUND'));
app.use((err, _req, res, _next) => {
  if (err?.type === 'entity.parse.failed' || err?.type === 'entity.too.large') {
    return fail(res, 400, 'INVALID_INPUT');
  }
  console.error(err);
  fail(res, 500, 'SERVER');
});

app.listen(PORT, () => console.log(`OTP backend listening on :${PORT} (provider: ${PROVIDER})`));

# App Locker OTP backend

Sends a 6-digit code to the recovery email and checks it. The Android app only ever sends
the email address and the code; **no email credentials are inside the APK**.

## What it does
- `POST /otp/send`   body: `{ email, deviceId, purpose: "register" | "reset", proof? }`
- `POST /otp/verify` body: `{ email, deviceId, purpose, code }`
- `GET  /health`

Rules enforced on the server: code expires after 10 minutes, one resend per 60 seconds,
5 wrong tries then a 15 minute lockout, 5 emails per address per hour, 30 requests per IP
per 10 minutes. Codes are stored only as an HMAC hash and work once.

`reset` is only allowed for the email this phone verified earlier: registering returns a
signed `proof`, and the server refuses reset codes without it. So the reset endpoint cannot
be used to email random people.

Honest limits:
- OTP state is in memory. If the server restarts, an unused code stops working and the user taps "Resend".
- Free hosts sleep when idle, so the first request can take up to a minute.
- Anyone can call the register endpoint, so abuse is limited only by the rate limits above.

## 1. Pick an email sender (use an HTTPS API)
Render's free plan blocks SMTP ports 25/465/587, so use an API provider.

**Brevo (recommended, works for any recipient)**
1. Create a Brevo account, add and verify a sender email (Senders, Domains and Dedicated IPs).
2. SMTP & API > API keys > create a key.
3. Env vars: `EMAIL_PROVIDER=brevo`, `BREVO_API_KEY=...`, `FROM_EMAIL=<your verified sender>`.

Resend also works (`EMAIL_PROVIDER=resend`, `RESEND_API_KEY`), but it only sends to arbitrary
recipients after you verify a domain. `EMAIL_PROVIDER=smtp` works on hosts that allow SMTP.

## 2. Deploy (example: Render)
1. Put this project in a GitHub repository.
2. Render > New > Web Service > pick the repo.
3. Root directory `backend`, build command `npm install`, start command `npm start`.
4. Environment: `NODE_ENV=production`, `OTP_SECRET=<long random>`, plus the email variables above.
   Generate a secret: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
5. Open `https://YOUR-SERVICE.onrender.com/health`. It must show `{"ok":true}`.

The server refuses to start in production without `OTP_SECRET` or with `EMAIL_PROVIDER=console`.

## 3. Point the app at it
In the project's `local.properties` (same file that holds `sdk.dir`) add:

    BACKEND_URL=https://YOUR-SERVICE.onrender.com

Rebuild the app. Until this is set, the app says "Backend address is not set".

## 4. Local test without sending email
    cd backend
    npm install
    EMAIL_PROVIDER=console OTP_SECRET=test npm start
The code is printed in the server log. (The phone needs a public HTTPS address, so this is for curl tests only.)

# App Locker (Kotlin + Jetpack Compose)

## Build
1. Open this folder in Android Studio (Koala or newer, JDK 17).
2. Let Gradle sync. Android Studio creates the missing gradle-wrapper.jar itself.
3. Run on a real phone (USB debugging on), or Build > Build APK(s).

## Phases
1. Project, theme, onboarding  (done)
2. PIN, Keystore, BiometricPrompt  (done)
3. App list and lock engine  (done)
4. Device Admin, Accessibility guard, protection status  (done)
5. Node.js backend and Gmail OTP recovery  (done)
6. Dashboard, settings, reboot restore, final guide  (done)

See RECOVERY.md for protection levels, Device Owner provisioning and recovery.

Backend setup: backend/README.md. Set BACKEND_URL in local.properties before building.

Full build and test steps: BUILD_AND_TEST.md

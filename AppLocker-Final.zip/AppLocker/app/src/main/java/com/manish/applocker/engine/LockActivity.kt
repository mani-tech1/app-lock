package com.manish.applocker.engine

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import com.manish.applocker.MainActivity
import com.manish.applocker.data.ThemePhoto
import com.manish.applocker.data.UiPrefs
import com.manish.applocker.ui.pin.LocalLockBackground
import com.manish.applocker.ui.pin.LocalVibrateOnInput
import com.manish.applocker.security.BiometricHelper
import com.manish.applocker.security.PinManager
import com.manish.applocker.ui.pin.UnlockScreen
import com.manish.applocker.ui.theme.AppLockerTheme

/** Full-screen PIN / fingerprint gate shown on top of a protected app. */
class LockActivity : FragmentActivity() {

    private var targetPkg by mutableStateOf<String?>(null)
    private var guardMode by mutableStateOf(false)
    private var sessionId by mutableIntStateOf(0)
    private val pinManager by lazy { PinManager(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        targetPkg = intent.getStringExtra(EXTRA_PKG)
        guardMode = intent.getBooleanExtra(EXTRA_GUARD, false)

        // Back must never reveal the protected app underneath: send the user Home.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })

        setContent {
            val vibrate by UiPrefs.vibrateOnInput.collectAsState()
            val background by ThemePhoto.image.collectAsState()
            CompositionLocalProvider(
                LocalVibrateOnInput provides vibrate,
                LocalLockBackground provides background
            ) {
                AppLockerTheme { LockContent() }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        targetPkg = intent.getStringExtra(EXTRA_PKG)
        guardMode = intent.getBooleanExtra(EXTRA_GUARD, false)
        sessionId++ // fresh PIN pad for the new app
    }

    @Composable
    private fun LockContent() {
        val pkg = targetPkg
        val appInfo = remember(pkg) { loadAppInfo(pkg) }
        val fingerprintReady = remember(sessionId) {
            pinManager.fingerprintEnabled && BiometricHelper.isAvailable(this)
        }
        val lockType = remember(sessionId) { pinManager.lockType }

        key(sessionId) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                UnlockScreen(
                    title = when {
                        guardMode -> "Enter PIN to continue"
                        appInfo != null -> "${appInfo.first} is locked"
                        else -> "App Locker"
                    },
                    headerIcon = if (guardMode) null else appInfo?.second,
                    fingerprintReady = fingerprintReady,
                    lockType = lockType,
                    verifyPin = { pinManager.verify(it) },
                    lockoutRemainingMs = { pinManager.remainingLockMs() },
                    requestFingerprint = { onSuccess, onError ->
                        BiometricHelper.prompt(
                            activity = this@LockActivity,
                            title = "Unlock ${appInfo?.first ?: "app"}",
                            subtitle = "Use your fingerprint",
                            negativeText = "Use PIN",
                            onSuccess = onSuccess,
                            onError = { code, msg ->
                                BiometricHelper.friendlyError(code, msg)?.let(onError)
                            }
                        )
                    },
                    onForgotPin = { openReset() },
                    onUnlocked = {
                        LockSession.unlockedPkg = pkg
                        finish()
                        @Suppress("DEPRECATION")
                        overridePendingTransition(0, 0)
                    }
                )
            }
        }
    }

    private fun loadAppInfo(pkg: String?): Pair<String, ImageBitmap>? {
        if (pkg == null) return null
        return try {
            val pm = packageManager
            val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            val icon = pm.getApplicationIcon(pkg).toBitmap(160, 160).asImageBitmap()
            label to icon
        } catch (e: Exception) {
            null
        }
    }

    /** The reset flow lives in the main app: open it, and leave the protected app locked. */
    private fun openReset() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_START_RESET, true)
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
        )
        finish()
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    companion object {
        const val EXTRA_PKG = "target_pkg"
        const val EXTRA_GUARD = "guard_mode"
    }
}

package com.manish.applocker.data

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Lists every app that has a launcher icon (including system apps like Settings / Play Store). */
class AppRepository(private val context: Context) {

    private val iconCache = ConcurrentHashMap<String, androidx.compose.ui.graphics.ImageBitmap>()

    @Suppress("DEPRECATION")
    suspend fun loadLaunchableApps(): List<InstalledApp> = withContext(Dispatchers.Default) {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val result = ArrayList<InstalledApp>()
        for (info in pm.queryIntentActivities(launcherIntent, 0)) {
            val ai = info.activityInfo ?: continue
            val pkg = ai.packageName
            if (pkg == context.packageName || !seen.add(pkg)) continue
            val icon = iconCache.getOrPut(pkg) {
                ai.loadIcon(pm).toBitmap(ICON_PX, ICON_PX).asImageBitmap()
            }
            result += InstalledApp(pkg, ai.loadLabel(pm).toString(), icon)
        }
        result.sortedBy { it.label.lowercase() }
    }

    private companion object {
        const val ICON_PX = 96
    }
}

package com.manish.applocker.ui.settings

import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.manish.applocker.security.LockType
import com.manish.applocker.security.PinResult
import com.manish.applocker.ui.pin.CreateSecretFlow
import com.manish.applocker.ui.pin.PinEntryScreen
import kotlinx.coroutines.launch
import kotlin.math.ceil

/** Change lock: prove the current one first, then choose a new one (any lock type). */
@Composable
fun ChangePinScreen(
    currentType: LockType,
    verifyPin: suspend (String) -> PinResult,
    onSave: suspend (LockType, String) -> Boolean,
    onDone: () -> Unit,
    onCancel: () -> Unit,
    startType: LockType = currentType,
    allowTypeChange: Boolean = true
) {
    var verified by remember { mutableStateOf(false) }

    if (verified) {
        CreateSecretFlow(
            initialType = startType,
            allowTypeChange = allowTypeChange,
            onSave = onSave,
            onSaved = onDone,
            extraFooter = { TextButton(onClick = onCancel) { Text("Cancel") } }
        )
    } else {
        VerifyCurrent(currentType, verifyPin, onVerified = { verified = true }, onCancel = onCancel)
    }
}

@Composable
private fun VerifyCurrent(
    type: LockType,
    verifyPin: suspend (String) -> PinResult,
    onVerified: () -> Unit,
    onCancel: () -> Unit
) {
    var resetKey by remember { mutableIntStateOf(0) }
    var shakeKey by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun error(text: String, shake: Boolean = true) {
        message = text
        isError = true
        if (shake) shakeKey++
        resetKey++
    }

    PinEntryScreen(
        title = "Enter your current ${type.noun}",
        message = message.ifEmpty { "To change it, prove it is you" },
        isError = isError,
        resetKey = resetKey,
        shakeKey = shakeKey,
        enabled = !busy,
        lockType = type,
        onComplete = { secret ->
            busy = true
            scope.launch {
                val r = verifyPin(secret)
                busy = false
                when (r) {
                    PinResult.Success -> onVerified()
                    is PinResult.Wrong ->
                        error(if (r.lockedForMs > 0) "Too many attempts. Wait, then try again." else "Wrong ${type.noun}.")
                    is PinResult.LockedOut ->
                        error("Locked. Try again in ${ceil(r.remainingMs / 1000.0).toInt()}s", shake = false)
                    else -> error("It could not be verified.")
                }
            }
        },
        footer = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

package com.manish.applocker.ui.settings

import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.manish.applocker.security.PinPolicy
import com.manish.applocker.security.PinResult
import com.manish.applocker.ui.pin.PinEntryScreen
import kotlinx.coroutines.launch
import kotlin.math.ceil

private enum class ChangeStep { OLD, NEW, CONFIRM }

/** Change PIN: current PIN first, then the new one twice. */
@Composable
fun ChangePinScreen(
    verifyPin: suspend (String) -> PinResult,
    onSetNewPin: suspend (String) -> Boolean,
    onDone: () -> Unit,
    onCancel: () -> Unit
) {
    var step by remember { mutableStateOf(ChangeStep.OLD) }
    var first by remember { mutableStateOf("") }
    var resetKey by remember { mutableIntStateOf(0) }
    var shakeKey by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun error(text: String, shake: Boolean = true) {
        message = text
        isError = true
        if (shake) shakeKey++
        resetKey++
    }

    PinEntryScreen(
        title = when (step) {
            ChangeStep.OLD -> "Enter your current PIN"
            ChangeStep.NEW -> "Choose a new PIN"
            ChangeStep.CONFIRM -> "Confirm your new PIN"
        },
        message = message.ifEmpty {
            when (step) {
                ChangeStep.OLD -> "To change your PIN, prove it is you"
                ChangeStep.NEW -> "Choose a ${PinPolicy.LENGTH}-digit PIN"
                ChangeStep.CONFIRM -> "Enter the same PIN again"
            }
        },
        isError = isError,
        resetKey = resetKey,
        shakeKey = shakeKey,
        enabled = !busy,
        onComplete = { pin ->
            when (step) {
                ChangeStep.OLD -> {
                    busy = true
                    scope.launch {
                        val r = verifyPin(pin)
                        busy = false
                        when (r) {
                            PinResult.Success -> {
                                message = ""
                                isError = false
                                step = ChangeStep.NEW
                                resetKey++
                            }
                            is PinResult.Wrong ->
                                error(if (r.lockedForMs > 0) "Too many attempts. Wait, then try again." else "Wrong PIN.")
                            is PinResult.LockedOut ->
                                error("Locked. Try again in ${ceil(r.remainingMs / 1000.0).toInt()}s", shake = false)
                            else -> error("Your PIN could not be verified.")
                        }
                    }
                }
                ChangeStep.NEW -> {
                    if (PinPolicy.isWeak(pin)) {
                        error("That PIN is too easy to guess. Try another.")
                    } else {
                        first = pin
                        message = ""
                        isError = false
                        step = ChangeStep.CONFIRM
                        resetKey++
                    }
                }
                ChangeStep.CONFIRM -> {
                    if (pin != first) {
                        first = ""
                        step = ChangeStep.NEW
                        error("PINs did not match. Start again.")
                    } else {
                        busy = true
                        scope.launch {
                            val ok = onSetNewPin(pin)
                            busy = false
                            if (ok) onDone()
                            else {
                                first = ""
                                step = ChangeStep.NEW
                                error("Secure storage failed on this device. Try again.")
                            }
                        }
                    }
                }
            }
        },
        footer = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

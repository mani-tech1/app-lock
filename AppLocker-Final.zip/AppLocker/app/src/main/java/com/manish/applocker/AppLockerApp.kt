package com.manish.applocker

import android.app.Application
import com.manish.applocker.data.LockedAppsStore
import com.manish.applocker.health.HealthMonitor
import com.manish.applocker.recovery.RecoveryStore

class AppLockerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        LockedAppsStore.init(this)
        RecoveryStore.init(this)
        HealthMonitor.schedule(this)
    }
}

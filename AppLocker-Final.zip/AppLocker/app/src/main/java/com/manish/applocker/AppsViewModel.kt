package com.manish.applocker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.manish.applocker.data.AppRepository
import com.manish.applocker.data.InstalledApp
import com.manish.applocker.data.LockedAppsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppsViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository(app)

    private val allApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val lockedPackages: StateFlow<Set<String>> = LockedAppsStore.locked

    val visibleApps: StateFlow<List<InstalledApp>> =
        combine(allApps, _query) { apps, q ->
            val t = q.trim()
            if (t.isEmpty()) apps
            else apps.filter { it.label.contains(t, true) || it.packageName.contains(t, true) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Only counts apps that are still installed. */
    val lockedCount: StateFlow<Int> =
        combine(allApps, LockedAppsStore.locked) { apps, locked ->
            apps.count { it.packageName in locked }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            if (allApps.value.isEmpty()) _loading.value = true
            allApps.value = repo.loadLaunchableApps()
            _loading.value = false
        }
    }

    fun setQuery(q: String) {
        _query.value = q
    }

    fun setLocked(pkg: String, locked: Boolean) = LockedAppsStore.setLocked(pkg, locked)
}

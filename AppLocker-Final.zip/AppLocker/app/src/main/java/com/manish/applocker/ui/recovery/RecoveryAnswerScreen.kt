package com.manish.applocker.ui.recovery

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.manish.applocker.recovery.RecoveryAnswerStore
import kotlinx.coroutines.launch

private val presetQuestions = listOf(
    "Favourite name",
    "Favourite place",
    "Favourite number",
    "Pet's name",
    "Best friend's name",
    "Favourite food"
)
private const val CUSTOM = "Write my own question"

/**
 * Set (or change) the recovery answer. Used on first run (with "Set up later")
 * and from Settings > Password recovery method.
 */
@Composable
fun RecoveryAnswerScreen(
    allowSkip: Boolean,
    onDone: () -> Unit,
    onExit: () -> Unit
) {
    var choice by rememberSaveable { mutableStateOf(presetQuestions[0]) }
    var customQuestion by rememberSaveable { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val transformation =
        if (visible) VisualTransformation.None else PasswordVisualTransformation()
    val keyboard = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Next)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Recovery answer",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            "If you forget your lock, this answer lets you set a new one. Use letters A-Z and " +
                "numbers 0-9 only, with no spaces or symbols. Capital or small letters do not matter.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Box {
            OutlinedButton(
                onClick = { menuOpen = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Question: $choice  \u25BE") }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                (presetQuestions + CUSTOM).forEach { q ->
                    DropdownMenuItem(
                        text = { Text(q) },
                        onClick = {
                            choice = q
                            menuOpen = false
                        }
                    )
                }
            }
        }
        if (choice == CUSTOM) {
            OutlinedTextField(
                value = customQuestion,
                onValueChange = { customQuestion = it.take(40) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Your question (shown on the lock screen)") }
            )
        }

        OutlinedTextField(
            value = answer,
            onValueChange = { answer = RecoveryAnswerStore.clean(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            enabled = !busy,
            label = { Text("Answer") },
            visualTransformation = transformation,
            keyboardOptions = keyboard,
            trailingIcon = {
                TextButton(onClick = { visible = !visible }) { Text(if (visible) "Hide" else "Show") }
            }
        )
        OutlinedTextField(
            value = again,
            onValueChange = { again = RecoveryAnswerStore.clean(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            enabled = !busy,
            label = { Text("Type it again") },
            visualTransformation = transformation,
            keyboardOptions = keyboard
        )

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }

        Button(
            onClick = {
                val question = if (choice == CUSTOM) customQuestion.trim() else choice
                val problem = RecoveryAnswerStore.problem(answer)
                error = when {
                    question.isEmpty() -> "Write your question."
                    problem != null -> problem
                    answer.lowercase() != again.lowercase() -> "The two answers do not match."
                    else -> null
                }
                if (error == null) {
                    busy = true
                    scope.launch {
                        val ok = RecoveryAnswerStore.save(question, answer)
                        busy = false
                        if (ok) onDone() else error = "Could not save it securely on this device."
                    }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Save") }

        TextButton(onClick = onExit, modifier = Modifier.fillMaxWidth()) {
            Text(if (allowSkip) "Set up later" else "Cancel")
        }
        if (allowSkip) {
            Text(
                "Without it, a forgotten lock cannot be reset from inside the app.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

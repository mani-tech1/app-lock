package com.manish.applocker.ui.theme

import androidx.compose.ui.graphics.Color

val Indigo400 = Color(0xFF8B85FF)
val Indigo600 = Color(0xFF5148E0)
val Violet500 = Color(0xFF8E54E9)
val Cyan400 = Color(0xFF38BDF8)

val DarkBackground = Color(0xFF0E0F1A)
val DarkSurface = Color(0xFF171827)
val DarkSurfaceVariant = Color(0xFF22243A)
val DarkOnSurface = Color(0xFFEDEDF7)
val DarkOnSurfaceVariant = Color(0xFFA6A8C2)

val LightBackground = Color(0xFFF6F6FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9E9F5)
val LightOnSurface = Color(0xFF14152A)
val LightOnSurfaceVariant = Color(0xFF5B5D78)

package com.manish.applocker.recovery

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import com.manish.applocker.security.KeystoreCipher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

/**
 * Remembers the verified recovery email on this phone.
 * The email and the server's "proof" are encrypted with the Android Keystore key.
 * The device id is a random UUID that ties OTPs to this install (not a secret).
 */
object RecoveryStore {
    private const val PREFS = "recovery_store"
    private const val K_DEVICE = "device_id"
    private const val K_EMAIL = "email"
    private const val K_PROOF = "proof"

    private lateinit var prefs: SharedPreferences
    private val _email = MutableStateFlow<String?>(null)
    val email: StateFlow<String?> = _email.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _email.value = open(K_EMAIL)
    }

    fun deviceId(): String =
        prefs.getString(K_DEVICE, null)
            ?: UUID.randomUUID().toString().also { prefs.edit().putString(K_DEVICE, it).apply() }

    fun proof(): String? = open(K_PROOF)

    /** @return false if the Keystore could not protect the data (nothing is saved then). */
    fun save(email: String, proof: String): Boolean = try {
        prefs.edit()
            .putString(K_EMAIL, seal(email))
            .putString(K_PROOF, seal(proof))
            .commit()
        _email.value = email
        true
    } catch (e: Exception) {
        false
    }

    private fun seal(s: String): String =
        Base64.encodeToString(KeystoreCipher.encrypt(s.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)

    private fun open(key: String): String? =
        prefs.getString(key, null)?.let {
            runCatching {
                String(KeystoreCipher.decrypt(Base64.decode(it, Base64.NO_WRAP)), Charsets.UTF_8)
            }.getOrNull()
        }
}

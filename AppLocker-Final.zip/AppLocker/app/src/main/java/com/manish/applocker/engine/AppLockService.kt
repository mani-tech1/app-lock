package com.manish.applocker.engine

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import com.manish.applocker.data.LockedAppsStore
import com.manish.applocker.data.UiPrefs
import com.manish.applocker.health.HealthMonitor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The lock engine and the uninstall guard.
 *
 * 1. Locked apps: when a locked app comes to the front, show [LockActivity].
 * 2. Guard: when an Android Settings / uninstall screen is showing and its text mentions
 *    App Locker (app info, device admin, accessibility, uninstall dialog), ask for the PIN.
 *    Screen text is only inspected for those system packages, never stored or sent.
 */
class AppLockService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastForeground: String? = null
    private var lastLaunchKey: String? = null
    private var lastLaunchAt = 0L
    private var ignored: Set<String> = BASE_IGNORED
    private var contentCheckPending = false

    private val ownLabel: String by lazy {
        applicationInfo.loadLabel(packageManager).toString().lowercase()
    }

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            LockSession.clear()
            lastForeground = null
        }
    }

    /** "Lock new app": lock apps installed while the engine is running. */
    private val packageAddedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!UiPrefs.lockNewApps.value) return
            if (intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
            val pkg = intent.data?.schemeSpecificPart ?: return
            if (pkg == context.packageName) return
            if (context.packageManager.getLaunchIntentForPackage(pkg) == null) return
            LockedAppsStore.setLocked(pkg, true)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        refreshIgnored()
        ContextCompat.registerReceiver(
            this, screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        ContextCompat.registerReceiver(
            this, packageAddedReceiver,
            IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        _connected.value = true
        HealthMonitor.check(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ->
                onWindowChanged(pkg, event.className?.toString())
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ->
                if (pkg in GUARD_PACKAGES && pkg == lastForeground) scheduleContentCheck(pkg)
        }
    }

    private fun onWindowChanged(pkg: String, cls: String?) {
        // Our own lock screen appearing is not "a new app".
        if (pkg == packageName && cls == LockActivity::class.java.name) return
        // Status bar, keyboards and system dialogs do not count as leaving the app.
        if (pkg in ignored) return

        if (pkg != lastForeground) {
            lastForeground = pkg
            // The user moved to a different app: the previous unlock is over.
            if (LockSession.unlockedPkg != pkg) LockSession.clear()
        }

        if (pkg == packageName) return

        if (LockedAppsStore.isLocked(pkg) && LockSession.unlockedPkg != pkg) {
            showLock(pkg, guard = false)
            return
        }

        if (pkg in GUARD_PACKAGES) {
            // Screen text may not be ready yet, so look twice.
            GUARD_DELAYS.forEach { d -> handler.postDelayed({ runGuardCheck(pkg) }, d) }
        }
    }

    private fun scheduleContentCheck(pkg: String) {
        if (contentCheckPending) return
        contentCheckPending = true
        handler.postDelayed({
            contentCheckPending = false
            runGuardCheck(pkg)
        }, 400)
    }

    private fun runGuardCheck(pkg: String) {
        if (pkg != lastForeground) return
        if (LockSession.unlockedPkg == pkg || LockSession.settingsBypassActive()) return
        val root = rootInActiveWindow ?: return
        try {
            if (root.packageName?.toString() != pkg) return
            if (mentionsThisApp(root)) showLock(pkg, guard = true)
        } finally {
            root.recycleCompat()
        }
    }

    /** Looks for App Locker's name or package in the visible text (max a few hundred nodes). */
    private fun mentionsThisApp(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        var found = false
        while (queue.isNotEmpty() && visited < MAX_NODES && !found) {
            val node = queue.removeFirst()
            visited++
            if (matches(node.text) || matches(node.contentDescription)) {
                found = true
            } else {
                for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
            }
            if (node !== root) node.recycleCompat()
        }
        queue.forEach { if (it !== root) it.recycleCompat() }
        return found
    }

    private fun matches(cs: CharSequence?): Boolean {
        if (cs == null) return false
        val s = cs.toString().lowercase()
        return s.contains(ownLabel) || s.contains(packageName)
    }

    private fun showLock(pkg: String, guard: Boolean) {
        val key = "$pkg|$guard"
        val now = SystemClock.elapsedRealtime()
        if (key == lastLaunchKey && now - lastLaunchAt < 400) return
        lastLaunchKey = key
        lastLaunchAt = now
        val intent = Intent(this, LockActivity::class.java)
            .putExtra(LockActivity.EXTRA_PKG, pkg)
            .putExtra(LockActivity.EXTRA_GUARD, guard)
            .addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
        startActivity(intent)
    }

    private fun refreshIgnored() {
        val imm = getSystemService(InputMethodManager::class.java)
        val keyboards = imm?.enabledInputMethodList?.map { it.packageName } ?: emptyList()
        ignored = BASE_IGNORED + keyboards
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        val wasRunning = _connected.value
        _connected.value = false
        if (wasRunning) HealthMonitor.checkSoon(applicationContext)
        handler.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(screenOffReceiver) }
        runCatching { unregisterReceiver(packageAddedReceiver) }
        LockSession.clear()
    }

    @Suppress("DEPRECATION")
    private fun AccessibilityNodeInfo.recycleCompat() {
        if (Build.VERSION.SDK_INT < 33) recycle()
    }

    companion object {
        private val BASE_IGNORED = setOf("com.android.systemui", "android")

        /**
         * System screens that can uninstall or deactivate App Locker.
         * OEM phones can use other package names; add yours here if the guard misses a screen
         * (find it with: adb shell dumpsys window | grep mCurrentFocus).
         */
        private val GUARD_PACKAGES = setOf(
            "com.android.settings",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.miui.packageinstaller",
            "com.miui.securitycenter"
        )
        private val GUARD_DELAYS = longArrayOf(250, 800)
        private const val MAX_NODES = 600

        private val _connected = MutableStateFlow(false)
        /** True while Android has the lock engine running. */
        val connected: StateFlow<Boolean> = _connected.asStateFlow()
    }
}

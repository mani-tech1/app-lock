package com.manish.applocker.recovery

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.manish.applocker.BuildConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class RecoveryMode { REGISTER, RESET }
enum class RecoveryStep { PICK, READY, CODE, NO_RECOVERY, DONE }

data class RecoveryUi(
    val started: Boolean = false,
    val mode: RecoveryMode = RecoveryMode.REGISTER,
    val step: RecoveryStep = RecoveryStep.PICK,
    val email: String? = null,
    val busy: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
    val errorTick: Int = 0,
    val resendInSec: Int = 0
)

/**
 * One state machine for both flows:
 *  REGISTER: pick Google account -> email code -> verified -> saved
 *  RESET:    (stored email) -> email code -> verified -> caller lets the user choose a new PIN
 */
class RecoveryViewModel(app: Application) : AndroidViewModel(app) {

    private val api = RecoveryApi()
    private val _ui = MutableStateFlow(RecoveryUi())
    val ui: StateFlow<RecoveryUi> = _ui.asStateFlow()
    private var tickJob: Job? = null

    /** Safe to call again after rotation: it keeps progress if the same flow is already running. */
    fun begin(mode: RecoveryMode) {
        val cur = _ui.value
        if (cur.started && cur.mode == mode) return
        tickJob?.cancel()
        val saved = RecoveryStore.email.value
        _ui.value = when (mode) {
            RecoveryMode.REGISTER -> RecoveryUi(started = true, mode = mode, step = RecoveryStep.PICK)
            RecoveryMode.RESET -> RecoveryUi(
                started = true,
                mode = mode,
                step = if (saved == null) RecoveryStep.NO_RECOVERY else RecoveryStep.READY,
                email = saved
            )
        }
    }

    fun end() {
        tickJob?.cancel()
        _ui.value = RecoveryUi()
    }

    fun onAccountPicked(email: String) {
        _ui.update { it.copy(email = email.trim().lowercase(), message = null, isError = false) }
        sendCode()
    }

    fun changeAccount() {
        tickJob?.cancel()
        _ui.update {
            it.copy(step = RecoveryStep.PICK, email = null, message = null, isError = false, resendInSec = 0)
        }
    }

    fun sendCode() {
        val s = _ui.value
        val email = s.email ?: return
        if (s.busy) return
        if (BuildConfig.BACKEND_URL.contains("YOUR-APP")) {
            raise("Backend address is not set. Add BACKEND_URL to local.properties and rebuild (see backend/README.md).")
            return
        }
        _ui.update { it.copy(busy = true, message = null, isError = false) }
        viewModelScope.launch {
            val reset = s.mode == RecoveryMode.RESET
            val res = api.sendOtp(
                email = email,
                deviceId = RecoveryStore.deviceId(),
                purpose = if (reset) "reset" else "register",
                proof = if (reset) RecoveryStore.proof() else null
            )
            when (res) {
                is ApiResult.Ok -> {
                    _ui.update {
                        it.copy(
                            busy = false,
                            step = RecoveryStep.CODE,
                            message = "Code sent. It expires in ${res.value.expiresInSec / 60} minutes.",
                            isError = false,
                            resendInSec = res.value.resendAfterSec
                        )
                    }
                    startTick()
                }
                is ApiResult.Err -> {
                    if (res.code == "COOLDOWN") {
                        // A code was sent a moment ago: go and enter it.
                        _ui.update {
                            it.copy(
                                busy = false,
                                step = RecoveryStep.CODE,
                                message = "A code was just sent. Enter it, or wait to resend.",
                                isError = false,
                                resendInSec = res.retryAfterSec
                            )
                        }
                        startTick()
                    } else {
                        fail(res)
                    }
                }
            }
        }
    }

    fun verify(code: String) {
        val s = _ui.value
        val email = s.email ?: return
        if (s.busy || code.length != 6) return
        _ui.update { it.copy(busy = true, message = null, isError = false) }
        viewModelScope.launch {
            val reset = s.mode == RecoveryMode.RESET
            val res = api.verifyOtp(
                email = email,
                deviceId = RecoveryStore.deviceId(),
                purpose = if (reset) "reset" else "register",
                code = code
            )
            when (res) {
                is ApiResult.Ok -> {
                    if (!reset) {
                        val proof = res.value.proof
                        if (proof == null || !RecoveryStore.save(email, proof)) {
                            raise("Could not save the recovery email securely on this phone.")
                            return@launch
                        }
                    }
                    tickJob?.cancel()
                    _ui.update { it.copy(busy = false, step = RecoveryStep.DONE, message = null, isError = false) }
                }
                is ApiResult.Err -> fail(res)
            }
        }
    }

    private fun startTick() {
        tickJob?.cancel()
        tickJob = viewModelScope.launch {
            while (_ui.value.resendInSec > 0) {
                delay(1000)
                _ui.update { it.copy(resendInSec = (it.resendInSec - 1).coerceAtLeast(0)) }
            }
        }
    }

    private fun raise(msg: String) {
        _ui.update { it.copy(busy = false, message = msg, isError = true, errorTick = it.errorTick + 1) }
    }

    private fun fail(err: ApiResult.Err) = raise(friendly(err))

    private fun friendly(e: ApiResult.Err): String = when (e.code) {
        "NETWORK" -> "Could not reach the server. Check your internet and try again."
        "COOLDOWN" -> "Please wait ${e.retryAfterSec}s before asking for another code."
        "RATE_LIMITED" -> "Too many codes requested. Try again in ${minutes(e.retryAfterSec)}."
        "LOCKED", "TOO_MANY_ATTEMPTS" -> "Too many wrong codes. Try again in ${minutes(e.retryAfterSec)}."
        "INVALID_CODE" -> if (e.attemptsLeft >= 0) "Wrong code. ${e.attemptsLeft} tries left." else "Wrong code."
        "EXPIRED" -> "That code expired or was never sent. Request a new one."
        "BAD_PROOF" -> "This phone's recovery email could not be verified. Unlock with your PIN and set it up again."
        "EMAIL_FAILED" -> "The server could not send the email. Try again later."
        "INVALID_INPUT" -> "The request was not valid."
        else -> "Something went wrong (${e.code})."
    }

    private fun minutes(sec: Int): String {
        val m = (sec + 59) / 60
        return if (m <= 1) "a minute" else "$m minutes"
    }
}

package com.manish.applocker.security

/** The four ways the user can lock App Locker and the apps. */
enum class LockType(
    val label: String,
    val noun: String,
    val createTitle: String,
    val confirmTitle: String,
    val createHint: String,
    val confirmHint: String,
    val prompt: String
) {
    PIN4(
        "4-digit PIN", "PIN",
        "Create your PIN", "Confirm your PIN",
        "Choose a 4-digit PIN", "Enter the same PIN again",
        "Enter your PIN"
    ),
    PIN6(
        "6-digit PIN", "PIN",
        "Create your PIN", "Confirm your PIN",
        "Choose a 6-digit PIN", "Enter the same PIN again",
        "Enter your PIN"
    ),
    PATTERN(
        "Pattern", "pattern",
        "Draw your pattern", "Draw it again",
        "Connect at least 4 dots", "Draw the same pattern again",
        "Draw your pattern"
    ),
    PASSWORD(
        "Password", "password",
        "Create your password", "Confirm your password",
        "Use at least 4 characters", "Type the same password again",
        "Enter your password"
    );

    /** Number of digits for PIN types, 0 for pattern and password. */
    val pinLength: Int
        get() = when (this) {
            PIN4 -> 4
            PIN6 -> 6
            else -> 0
        }
}

object SecretPolicy {
    const val MIN_PATTERN_DOTS = 4
    const val MIN_PASSWORD_CHARS = 4

    /** @return null if the new secret is acceptable, otherwise the message to show. */
    fun problem(type: LockType, secret: String): String? = when (type) {
        LockType.PIN4, LockType.PIN6 ->
            if (PinPolicy.isWeak(secret)) "That PIN is too easy to guess. Try another." else null
        LockType.PATTERN ->
            if (secret.length < MIN_PATTERN_DOTS) "Connect at least $MIN_PATTERN_DOTS dots." else null
        LockType.PASSWORD ->
            if (secret.length < MIN_PASSWORD_CHARS) "Use at least $MIN_PASSWORD_CHARS characters." else null
    }
}

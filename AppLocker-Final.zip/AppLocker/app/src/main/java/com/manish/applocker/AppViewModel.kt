package com.manish.applocker

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.manish.applocker.admin.ProtectionManager
import com.manish.applocker.admin.ProtectionSnapshot
import com.manish.applocker.data.SettingsStore
import com.manish.applocker.engine.LockSession
import com.manish.applocker.health.HealthMonitor
import com.manish.applocker.security.PinManager
import com.manish.applocker.security.PinResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val pinManager = PinManager(app)
    private val settings = SettingsStore(app)
    private val protection = ProtectionManager(app)

    val onboardingDone: Flow<Boolean> = settings.onboardingDone

    private val _pinSet = MutableStateFlow(pinManager.isPinSet())
    val pinSet: StateFlow<Boolean> = _pinSet.asStateFlow()

    private val _unlocked = MutableStateFlow(false)
    val unlocked: StateFlow<Boolean> = _unlocked.asStateFlow()

    private val _fingerprintEnabled = MutableStateFlow(pinManager.fingerprintEnabled)
    val fingerprintEnabled: StateFlow<Boolean> = _fingerprintEnabled.asStateFlow()

    private val _protectionState = MutableStateFlow(protection.snapshot())
    val protectionState: StateFlow<ProtectionSnapshot> = _protectionState.asStateFlow()

    val adbCommand: String = protection.adbCommand
    val phoneInfo: String = protection.phoneInfo()

    fun finishOnboarding() {
        viewModelScope.launch { settings.setOnboardingDone(true) }
    }

    /** Saves the PIN but keeps showing setup so the fingerprint step can follow. */
    suspend fun createPin(pin: String): Boolean = pinManager.setPin(pin)

    fun completeSetup() {
        _pinSet.value = true
        _unlocked.value = true
    }

    suspend fun verifyPin(pin: String): PinResult = pinManager.verify(pin)
    fun lockoutRemainingMs(): Long = pinManager.remainingLockMs()

    /** Change PIN (the current PIN was already verified by the screen). Keeps fingerprint setting. */
    suspend fun changePin(newPin: String): Boolean = pinManager.setPin(newPin)

    fun unlock() { _unlocked.value = true }

    /** Called the moment the user leaves the app (and by the "Lock now" button). */
    fun lockNow() { _unlocked.value = false }

    fun setFingerprintEnabled(enabled: Boolean) {
        pinManager.fingerprintEnabled = enabled
        _fingerprintEnabled.value = enabled
    }

    // ---- forgot PIN ----

    private val _resetRequested = MutableStateFlow(false)
    val resetRequested: StateFlow<Boolean> = _resetRequested.asStateFlow()

    fun startReset() { _resetRequested.value = true }
    fun cancelReset() { _resetRequested.value = false }

    /** Only reachable after the emailed code was verified. Saving a PIN also clears the lockout. */
    suspend fun completeReset(newPin: String): Boolean {
        val ok = pinManager.setPin(newPin)
        if (ok) {
            _resetRequested.value = false
            _unlocked.value = true
        }
        return ok
    }

    // ---- protection (Device Admin / Device Owner) ----

    fun refreshProtection() {
        _protectionState.value = protection.snapshot()
        HealthMonitor.noteAdmin(getApplication<Application>(), _protectionState.value.adminActive)
    }

    /** The user is already PIN-authenticated here, so let the Android admin screen open without a second PIN. */
    fun adminActivationIntent(): Intent {
        LockSession.allowSettingsFor(60_000)
        return protection.activationIntent()
    }

    /** @return null on success, otherwise an error message. */
    fun deactivateProtection(): String? {
        val error = protection.deactivate()
        // Deactivating on purpose must not later be reported as "Device Admin was switched off".
        if (error == null) HealthMonitor.clearAdminMemory(getApplication<Application>())
        refreshProtection()
        viewModelScope.launch {
            delay(700) // Android applies the removal a moment later
            refreshProtection()
        }
        return error
    }
}

package com.manish.applocker.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.manish.applocker.engine.LockSession

/** Honest warning shown whenever the lock engine (Accessibility service) is not running. */
@Composable
fun EngineBanner(connected: Boolean, modifier: Modifier = Modifier) {
    if (connected) return
    var showDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF59E0B).copy(alpha = 0.16f))
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Lock engine is OFF", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Apps are NOT being locked and the uninstall guard is not running. " +
                    "Turn on App Locker in Accessibility settings.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick = { showDialog = true }, shape = RoundedCornerShape(12.dp)) {
                Text("Enable")
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Why Accessibility?") },
            text = {
                Text(
                    "App Locker uses Accessibility to notice which app has just opened, " +
                        "so it can show the lock screen.\n\n" +
                        "It also reads on-screen text on Android Settings and uninstall " +
                        "screens, only to spot App Locker's own page and ask for your PIN. " +
                        "Nothing it reads is stored or sent anywhere.\n\n" +
                        "On the next screen open \"Installed apps\" (or \"Downloaded apps\"), " +
                        "tap App Locker and turn it on."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showDialog = false
                    // The user is PIN-authenticated here: don't gate the settings screen we send them to.
                    LockSession.allowSettingsFor(120_000)
                    context.startActivity(
                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("Open settings") }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancel") }
            }
        )
    }
}

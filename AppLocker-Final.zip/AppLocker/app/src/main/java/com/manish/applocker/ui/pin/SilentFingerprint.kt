package com.manish.applocker.ui.pin

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.manish.applocker.security.FingerprintScanner

data class FingerprintStatus(
    val mode: Mode = Mode.OFF,
    val message: String? = null
) {
    enum class Mode {
        /** Fingerprint is not used. */
        OFF,
        /** Sensor is listening right now, no pop-up. */
        LISTENING,
        /** Silent scanning is not possible on this phone: tap the icon to scan. */
        TAP_ONLY
    }
}

/**
 * Keeps the fingerprint sensor listening while the screen is visible, and stops it when the
 * screen is hidden. [onSuccess] runs when a registered finger touches the sensor.
 */
@Composable
fun rememberSilentFingerprint(enabled: Boolean, onSuccess: () -> Unit): FingerprintStatus {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val latestSuccess by rememberUpdatedState(onSuccess)
    var status by remember { mutableStateOf(FingerprintStatus()) }

    DisposableEffect(owner, enabled) {
        val scanner = FingerprintScanner(context)

        fun begin() {
            if (!enabled) {
                status = FingerprintStatus()
                return
            }
            if (!scanner.isSupported()) {
                status = FingerprintStatus(FingerprintStatus.Mode.TAP_ONLY)
                return
            }
            status = FingerprintStatus(FingerprintStatus.Mode.LISTENING)
            scanner.start(
                onSuccess = { latestSuccess() },
                onMessage = { msg -> status = FingerprintStatus(FingerprintStatus.Mode.LISTENING, msg) },
                onUnavailable = { status = FingerprintStatus(FingerprintStatus.Mode.TAP_ONLY) }
            )
        }

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> begin()
                Lifecycle.Event.ON_PAUSE -> scanner.stop()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            scanner.stop()
        }
    }
    return status
}

package com.manish.applocker.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The set of locked package names.
 * Kept in memory (the lock service reads it on every window change) and
 * mirrored to SharedPreferences so it survives restarts.
 */
object LockedAppsStore {
    private const val PREFS = "locked_apps"
    private const val KEY = "packages"

    private lateinit var prefs: SharedPreferences
    private val _locked = MutableStateFlow<Set<String>>(emptySet())
    val locked: StateFlow<Set<String>> = _locked.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _locked.value = prefs.getStringSet(KEY, emptySet())?.toSet() ?: emptySet()
    }

    fun isLocked(pkg: String): Boolean = pkg in _locked.value

    fun setLocked(pkg: String, locked: Boolean) {
        val next = if (locked) _locked.value + pkg else _locked.value - pkg
        _locked.value = next
        prefs.edit().putStringSet(KEY, next).apply()
    }
}

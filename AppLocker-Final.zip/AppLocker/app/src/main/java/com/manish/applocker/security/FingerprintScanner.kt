package com.manish.applocker.security

import android.content.Context
import android.hardware.fingerprint.FingerprintManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper

/**
 * Listens for a fingerprint WITHOUT any system pop-up, so the PIN pad and the fingerprint sensor
 * can both be active at the same time. It uses the older FingerprintManager API, which is
 * deprecated but still works on most phones. If a phone refuses it, [start] reports
 * onUnavailable and the screen falls back to a tap-to-scan icon.
 */
@Suppress("DEPRECATION")
class FingerprintScanner(context: Context) {

    private val manager: FingerprintManager? =
        if (Build.VERSION.SDK_INT >= 23) {
            context.applicationContext.getSystemService(FingerprintManager::class.java)
        } else null

    private val handler = Handler(Looper.getMainLooper())
    private var signal: CancellationSignal? = null
    private var active = false
    private var onSuccessCb: (() -> Unit)? = null
    private var onMessageCb: ((String) -> Unit)? = null
    private var onUnavailableCb: (() -> Unit)? = null

    fun isSupported(): Boolean = try {
        val m = manager
        m != null && m.isHardwareDetected && m.hasEnrolledFingerprints()
    } catch (e: Exception) {
        false
    }

    fun start(onSuccess: () -> Unit, onMessage: (String) -> Unit, onUnavailable: () -> Unit) {
        stop()
        active = true
        onSuccessCb = onSuccess
        onMessageCb = onMessage
        onUnavailableCb = onUnavailable
        listen()
    }

    fun stop() {
        active = false
        handler.removeCallbacksAndMessages(null)
        signal?.cancel()
        signal = null
    }

    private fun listen() {
        val m = manager ?: return
        signal = CancellationSignal()
        try {
            m.authenticate(null, signal, 0, callback, null)
        } catch (e: Exception) {
            onUnavailableCb?.invoke()
        }
    }

    private val callback = object : FingerprintManager.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: FingerprintManager.AuthenticationResult?) {
            if (!active) return
            active = false
            onSuccessCb?.invoke()
        }

        override fun onAuthenticationFailed() {
            if (active) onMessageCb?.invoke("Fingerprint not recognized")
        }

        override fun onAuthenticationHelp(helpCode: Int, helpString: CharSequence?) {
            if (active && helpString != null) onMessageCb?.invoke(helpString.toString())
        }

        override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
            if (!active) return
            when (errorCode) {
                FingerprintManager.FINGERPRINT_ERROR_CANCELED -> Unit
                FingerprintManager.FINGERPRINT_ERROR_LOCKOUT -> {
                    onMessageCb?.invoke("Fingerprint paused for a moment. Use your lock instead.")
                    handler.postDelayed({ if (active) listen() }, 31_000)
                }
                FingerprintManager.FINGERPRINT_ERROR_LOCKOUT_PERMANENT ->
                    onMessageCb?.invoke("Fingerprint is locked. Use your lock instead.")
                else -> onUnavailableCb?.invoke()
            }
        }
    }
}

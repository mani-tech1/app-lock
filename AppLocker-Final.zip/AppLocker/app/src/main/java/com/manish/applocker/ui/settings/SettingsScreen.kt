package com.manish.applocker.ui.settings

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.manish.applocker.engine.LockSession
import com.manish.applocker.health.HealthMonitor

@Composable
fun SettingsScreen(
    fingerprintEnabled: Boolean,
    fingerprintAvailable: Boolean,
    onFingerprintToggle: (Boolean) -> Unit,
    onChangePin: () -> Unit,
    phoneInfo: String
) {
    val context = LocalContext.current
    var batteryUnrestricted by remember { mutableStateOf(isBatteryUnrestricted(context)) }
    var alertsOn by remember { mutableStateOf(HealthMonitor.alertsEnabled(context)) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        batteryUnrestricted = isBatteryUnrestricted(context)
    }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        alertsOn = granted
        HealthMonitor.setAlertsEnabled(context, granted)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Settings",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        SectionCard("Security") {
            Button(
                onClick = onChangePin,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Change PIN") }
            SwitchRow(
                title = "Unlock with fingerprint",
                subtitle = if (fingerprintAvailable) "Your PIN always works as backup."
                else "Add a fingerprint in Android settings to use this.",
                checked = fingerprintEnabled,
                enabled = fingerprintAvailable || fingerprintEnabled,
                onChange = onFingerprintToggle
            )
        }

        SectionCard("Alerts") {
            SwitchRow(
                title = "Protection alerts",
                subtitle = "A notification if Accessibility or Device Admin is switched off.",
                checked = alertsOn,
                enabled = true,
                onChange = { want ->
                    if (!want) {
                        alertsOn = false
                        HealthMonitor.setAlertsEnabled(context, false)
                    } else if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        alertsOn = true
                        HealthMonitor.setAlertsEnabled(context, true)
                    }
                }
            )
        }

        SectionCard("Keep protection running") {
            Text(
                if (batteryUnrestricted) "Battery: App Locker is not restricted."
                else "Battery: Android may stop App Locker in the background, which switches locking off.",
                style = MaterialTheme.typography.bodyMedium,
                color = if (batteryUnrestricted) MaterialTheme.colorScheme.onSurfaceVariant
                else MaterialTheme.colorScheme.error
            )
            Text(
                "On Xiaomi, Oppo, Vivo, Realme and Samsung phones also: allow Autostart, set " +
                    "battery to \"No restrictions\", and lock App Locker in the recent apps list.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(
                onClick = {
                    // You are already PIN-authenticated: don't ask again on the Android screen we open.
                    LockSession.allowSettingsFor(60_000)
                    context.startActivity(
                        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Open battery settings") }
            OutlinedButton(
                onClick = {
                    LockSession.allowSettingsFor(60_000)
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .setData(Uri.parse("package:${context.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Open App info") }
        }

        SectionCard("About") {
            Text(
                "App Locker ${versionName(context)}\n$phoneInfo",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun isBatteryUnrestricted(c: Context): Boolean =
    c.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(c.packageName) == true

private fun versionName(c: Context): String = try {
    c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
} catch (e: Exception) {
    ""
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

package com.manish.applocker.ui.settings

import android.Manifest
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.manish.applocker.admin.UninstallLevel
import com.manish.applocker.data.ThemePhoto
import com.manish.applocker.data.UiPrefs
import com.manish.applocker.engine.ExternalFlow
import com.manish.applocker.engine.LockSession
import com.manish.applocker.health.HealthMonitor
import com.manish.applocker.security.LockType
import kotlinx.coroutines.launch

private val Orange = listOf(Color(0xFFFF7043), Color(0xFFE64A19))
private val Amber = listOf(Color(0xFFFFB300), Color(0xFFFF8F00))
private val Blue = listOf(Color(0xFF2979FF), Color(0xFF1565C0))
private val Indigo = listOf(Color(0xFF6666FF), Color(0xFF4040E0))

@Composable
fun SettingsScreen(
    lockType: LockType,
    fingerprintEnabled: Boolean,
    fingerprintAvailable: Boolean,
    recoveryHint: String?,
    uninstallLevel: UninstallLevel,
    adminActive: Boolean,
    onFaq: () -> Unit,
    onFingerprintToggle: (Boolean) -> Unit,
    onChangePassword: () -> Unit,
    onChangeType: (LockType) -> Unit,
    onRecovery: () -> Unit,
    onUninstallToggle: (Boolean) -> Unit,
    onUninstallDetails: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val vibrate by UiPrefs.vibrateOnInput.collectAsState()
    val lockNew by UiPrefs.lockNewApps.collectAsState()
    val spatial by UiPrefs.spatialApps.collectAsState()
    val photo by ThemePhoto.image.collectAsState()

    var alertsOn by remember { mutableStateOf(HealthMonitor.alertsEnabled(context)) }
    var batteryOk by remember { mutableStateOf(isBatteryUnrestricted(context)) }
    var deviceSecure by remember { mutableStateOf(isDeviceSecure(context)) }
    var photoMessage by remember { mutableStateOf<String?>(null) }
    var typeMenu by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        batteryOk = isBatteryUnrestricted(context)
        deviceSecure = isDeviceSecure(context)
    }

    val notificationPermission =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            alertsOn = granted
            HealthMonitor.setAlertsEnabled(context, granted)
        }
    val photoPicker =
        rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) {
                scope.launch {
                    photoMessage = if (ThemePhoto.save(context, uri)) null else "Could not use that photo."
                }
            }
        }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Settings",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        SettingsCard(null) {
            SettingRow(Icons.Filled.Info, Orange, "FAQ", onClick = onFaq) { Chevron() }
        }

        SettingsCard("Password & Security") {
            SettingRow(
                icon = Icons.Filled.Fingerprint,
                colors = Amber,
                title = "Fingerprint unlock",
                subtitle = if (!fingerprintAvailable && !fingerprintEnabled)
                    "Add a fingerprint in Android settings first" else null,
                badge = "Hot"
            ) {
                Switch(
                    checked = fingerprintEnabled,
                    onCheckedChange = onFingerprintToggle,
                    enabled = fingerprintAvailable || fingerprintEnabled
                )
            }
            SettingRow(Icons.Filled.Edit, Amber, "Change password", onClick = onChangePassword) { Chevron() }
            SettingRow(Icons.Filled.Lock, Amber, "Password type", onClick = { typeMenu = true }) {
                Box {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            lockType.label,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Icon(
                            Icons.Filled.KeyboardArrowDown,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    DropdownMenu(expanded = typeMenu, onDismissRequest = { typeMenu = false }) {
                        LockType.values().forEach { t ->
                            DropdownMenuItem(
                                text = { Text(if (t == lockType) "\u2713  ${t.label}" else t.label) },
                                onClick = {
                                    typeMenu = false
                                    if (t != lockType) onChangeType(t)
                                }
                            )
                        }
                    }
                }
            }
            SettingRow(
                icon = Icons.Filled.Email,
                colors = Amber,
                title = "Password recovery method",
                subtitle = if (recoveryHint == null) "Set a secret answer to reset your lock"
                else "Question: $recoveryHint",
                onClick = onRecovery
            ) {
                if (recoveryHint == null) {
                    Box(
                        modifier = Modifier.size(28.dp).clip(CircleShape).background(Color(0xFFE64A19)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("!", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Chevron()
                }
            }
        }

        SettingsCard("Smart Lock") {
            SettingRow(
                icon = Icons.Filled.Phone,
                colors = Blue,
                title = "Lock screen",
                subtitle = if (deviceSecure) "Your phone has a screen lock"
                else "Secure your phone with a screen lock",
                onClick = {
                    LockSession.allowSettingsFor(60_000)
                    context.startActivity(
                        Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            ) { Chevron() }
            SettingRow(Icons.Filled.Vibration, Blue, "Vibration on input") {
                Switch(checked = vibrate, onCheckedChange = { UiPrefs.setVibrateOnInput(it) })
            }
        }

        SettingsCard("Advanced") {
            SettingRow(
                icon = Icons.Filled.Apps,
                colors = Indigo,
                title = "Lock new app",
                subtitle = "Locks apps you install later (the lock engine must be on)"
            ) {
                Switch(checked = lockNew, onCheckedChange = { UiPrefs.setLockNewApps(it) })
            }
            SettingRow(
                icon = Icons.Filled.Star,
                colors = Indigo,
                title = "3D look of app tab",
                subtitle = "Apps float in 3D space. Hold one and drop it on the circle to lock it"
            ) {
                Switch(checked = spatial, onCheckedChange = { UiPrefs.setSpatialApps(it) })
            }
            SettingRow(
                icon = Icons.Filled.Delete,
                colors = Indigo,
                title = "Uninstall protection",
                subtitle = uninstallLevel.title,
                onClick = onUninstallDetails
            ) {
                Switch(checked = adminActive, onCheckedChange = onUninstallToggle)
            }
            SettingRow(
                icon = Icons.Filled.Notifications,
                colors = Indigo,
                title = "Protection alerts",
                subtitle = "Notify me if Accessibility or Device Admin is switched off"
            ) {
                Switch(
                    checked = alertsOn,
                    onCheckedChange = { want ->
                        if (!want) {
                            alertsOn = false
                            HealthMonitor.setAlertsEnabled(context, false)
                        } else if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                        ) {
                            ExternalFlow.begin()
                            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            alertsOn = true
                            HealthMonitor.setAlertsEnabled(context, true)
                        }
                    }
                )
            }
            SettingRow(
                icon = Icons.Filled.Settings,
                colors = Indigo,
                title = "Keep protection running",
                subtitle = if (batteryOk) "Battery: not restricted"
                else "Android may stop App Locker in the background. Tap to fix.",
                onClick = {
                    LockSession.allowSettingsFor(60_000)
                    context.startActivity(
                        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            ) { Chevron() }
        }

        SettingsCard("Theme") {
            SettingRow(
                icon = Icons.Filled.Palette,
                colors = Orange,
                title = "Theme",
                subtitle = "Photo shown behind the lock screen"
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    photo?.let {
                        Image(
                            bitmap = it,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp))
                        )
                    }
                    TextButton(onClick = {
                        ExternalFlow.begin()
                        photoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }) { Text("Browse") }
                }
            }
            if (photo != null) {
                SettingRow(
                    icon = Icons.Filled.Delete,
                    colors = Orange,
                    title = "Remove photo",
                    onClick = { ThemePhoto.clear(context) }
                ) {}
            }
            photoMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Text(
            "App Locker ${versionName(context)}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 16.dp)
        )
    }
}

private fun isBatteryUnrestricted(c: Context): Boolean =
    c.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(c.packageName) == true

private fun isDeviceSecure(c: Context): Boolean =
    c.getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true

private fun versionName(c: Context): String = try {
    c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
} catch (e: Exception) {
    ""
}

@Composable
private fun Chevron() {
    Icon(
        Icons.Filled.KeyboardArrowRight,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

/** A rounded card. With a [title] the header collapses and expands. */
@Composable
private fun SettingsCard(title: String?, content: @Composable ColumnScope.() -> Unit) {
    var expanded by rememberSaveable(title) { mutableStateOf(true) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(vertical = 6.dp)) {
            if (title != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        title,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Icon(
                        if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (expanded || title == null) content()
        }
    }
}

@Composable
private fun SettingRow(
    icon: ImageVector,
    colors: List<Color>,
    title: String,
    subtitle: String? = null,
    badge: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Brush.verticalGradient(colors)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                if (badge != null) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFE53935))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(badge, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        trailing()
    }
}

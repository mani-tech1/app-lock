package com.manish.applocker.health

import android.app.job.JobParameters
import android.app.job.JobService

class HealthJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        HealthMonitor.check(applicationContext)
        return false // finished
    }

    override fun onStopJob(params: JobParameters?): Boolean = false
}

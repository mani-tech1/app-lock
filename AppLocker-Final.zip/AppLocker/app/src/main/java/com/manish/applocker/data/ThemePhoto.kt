package com.manish.applocker.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

/**
 * The photo shown behind every lock screen. The chosen picture is shrunk and copied into the
 * app's private storage, so it keeps working even if the original is moved or deleted.
 */
object ThemePhoto {
    private const val FILE = "lock_background.jpg"
    private const val MAX_SIDE = 1600

    private val _image = MutableStateFlow<ImageBitmap?>(null)
    val image: StateFlow<ImageBitmap?> = _image.asStateFlow()

    fun init(context: Context) {
        val app = context.applicationContext
        Thread { _image.value = loadSaved(app) }.start()
    }

    private fun loadSaved(app: Context): ImageBitmap? {
        val f = File(app.filesDir, FILE)
        if (!f.exists()) return null
        return BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
    }

    suspend fun save(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val app = context.applicationContext
            val resolver = app.contentResolver

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false

            val orientation = resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val finalBitmap = if (degrees != 0f) {
                Bitmap.createBitmap(
                    decoded, 0, 0, decoded.width, decoded.height,
                    Matrix().apply { postRotate(degrees) }, true
                )
            } else decoded

            File(app.filesDir, FILE).outputStream().use {
                finalBitmap.compress(Bitmap.CompressFormat.JPEG, 88, it)
            }
            _image.value = finalBitmap.asImageBitmap()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun clear(context: Context) {
        File(context.applicationContext.filesDir, FILE).delete()
        _image.value = null
    }
}

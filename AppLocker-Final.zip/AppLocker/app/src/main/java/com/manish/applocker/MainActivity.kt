package com.manish.applocker

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import androidx.compose.runtime.CompositionLocalProvider
import com.manish.applocker.data.ThemePhoto
import com.manish.applocker.data.UiPrefs
import com.manish.applocker.engine.ExternalFlow
import com.manish.applocker.ui.pin.LocalLockBackground
import com.manish.applocker.ui.pin.LocalVibrateOnInput
import com.manish.applocker.security.BiometricHelper
import com.manish.applocker.security.findFragmentActivity
import com.manish.applocker.ui.MainShell
import com.manish.applocker.ui.onboarding.OnboardingScreen
import com.manish.applocker.ui.pin.PinSetupScreen
import com.manish.applocker.ui.pin.UnlockScreen
import com.manish.applocker.ui.recovery.ForgotPinScreen
import com.manish.applocker.ui.recovery.RecoveryAnswerScreen
import com.manish.applocker.ui.theme.AppLockerTheme

// FragmentActivity (not plain ComponentActivity) is required by BiometricPrompt.
class MainActivity : FragmentActivity() {

    private val vm: AppViewModel by viewModels()
    private val appsVm: AppsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blocks screenshots, screen recording and the recent-apps preview.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        if (savedInstanceState == null && intent.getBooleanExtra(EXTRA_START_RESET, false)) {
            vm.startReset()
        }
        setContent {
            val vibrate by UiPrefs.vibrateOnInput.collectAsState()
            val background by ThemePhoto.image.collectAsState()
            CompositionLocalProvider(
                LocalVibrateOnInput provides vibrate,
                LocalLockBackground provides background
            ) {
                AppLockerTheme {
                    AppRoot(vm, appsVm)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_START_RESET, false)) vm.startReset()
    }

    override fun onStart() {
        super.onStart()
        // Back from a picker we opened on purpose: lock now if we were away longer than allowed.
        if (ExternalFlow.finish()) vm.lockNow()
    }

    override fun onStop() {
        super.onStop()
        // Lock the moment the user leaves. Rotation also stops the activity, so skip that case.
        if (!isChangingConfigurations && !ExternalFlow.isActive()) vm.lockNow()
    }

    companion object {
        /** Set by the per-app lock screen when the user taps "Forgot PIN?". */
        const val EXTRA_START_RESET = "start_reset"
    }
}

private enum class Screen { LOADING, ONBOARDING, SETUP, RESET, UNLOCK, HOME }

@Composable
private fun AppRoot(vm: AppViewModel, appsVm: AppsViewModel) {
    val context = LocalContext.current
    val activity: FragmentActivity? = remember(context) { context.findFragmentActivity() }

    val onboardingDone by vm.onboardingDone.collectAsState(initial = null)
    val pinSet by vm.pinSet.collectAsState()
    val unlocked by vm.unlocked.collectAsState()
    val resetRequested by vm.resetRequested.collectAsState()
    val fingerprintEnabled by vm.fingerprintEnabled.collectAsState()
    val lockType by vm.lockType.collectAsState()

    val screen = when {
        onboardingDone == null -> Screen.LOADING
        onboardingDone == false -> Screen.ONBOARDING
        !pinSet -> Screen.SETUP
        resetRequested -> Screen.RESET
        !unlocked -> Screen.UNLOCK
        else -> Screen.HOME
    }
    val fingerprintAvailable = remember(screen) { BiometricHelper.isAvailable(context) }

    // Asks Android to verify a fingerprint before turning the feature on.
    val confirmFingerprint: (onResult: (Boolean) -> Unit) -> Unit = { onResult ->
        if (activity == null) {
            onResult(false)
        } else {
            BiometricHelper.prompt(
                activity = activity,
                title = "Enable fingerprint",
                subtitle = "Touch the sensor to confirm",
                negativeText = "Cancel",
                onSuccess = {
                    vm.setFingerprintEnabled(true)
                    onResult(true)
                },
                onError = { _, _ -> onResult(false) }
            )
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Crossfade(targetState = screen, label = "root") { s ->
            when (s) {
                Screen.LOADING -> Box(Modifier.fillMaxSize())

                Screen.ONBOARDING -> OnboardingScreen(onFinish = { vm.finishOnboarding() })

                Screen.SETUP -> PinSetupScreen(
                    fingerprintAvailable = fingerprintAvailable,
                    onCreateSecret = { t, s -> vm.createSecret(t, s) },
                    onEnableFingerprint = confirmFingerprint,
                    recoveryContent = { finished ->
                        RecoveryAnswerScreen(
                            allowSkip = true,
                            onDone = finished,
                            onExit = finished
                        )
                    },
                    onDone = { vm.completeSetup() }
                )

                Screen.RESET -> ForgotPinScreen(
                    initialType = lockType,
                    onSetNewSecret = { t, s -> vm.completeReset(t, s) },
                    onFinished = {},
                    onCancel = { vm.cancelReset() }
                )

                Screen.UNLOCK -> UnlockScreen(
                    fingerprintReady = fingerprintEnabled && fingerprintAvailable,
                    lockType = lockType,
                    verifyPin = { vm.verifyPin(it) },
                    lockoutRemainingMs = { vm.lockoutRemainingMs() },
                    requestFingerprint = { onSuccess, onError ->
                        if (activity != null) {
                            BiometricHelper.prompt(
                                activity = activity,
                                title = "Unlock App Locker",
                                subtitle = "Use your fingerprint",
                                negativeText = "Use PIN",
                                onSuccess = onSuccess,
                                onError = { code, msg ->
                                    BiometricHelper.friendlyError(code, msg)?.let(onError)
                                }
                            )
                        }
                    },
                    onForgotPin = { vm.startReset() },
                    onUnlocked = { vm.unlock() }
                )

                Screen.HOME -> MainShell(
                    vm = vm,
                    appsVm = appsVm,
                    fingerprintAvailable = fingerprintAvailable,
                    onFingerprintToggle = { wantOn ->
                        if (wantOn) confirmFingerprint { } else vm.setFingerprintEnabled(false)
                    }
                )
            }
        }
    }
}

package com.manish.applocker.recovery

/** manish123@gmail.com -> m*******@gmail.com */
fun maskEmail(email: String): String {
    val at = email.indexOf('@')
    if (at <= 1) return email
    return email.first() + "*".repeat((at - 1).coerceAtMost(8)) + email.substring(at)
}

package com.manish.applocker.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.manish.applocker.AppViewModel
import com.manish.applocker.AppsViewModel
import com.manish.applocker.engine.AppLockService
import com.manish.applocker.admin.UninstallLevel
import com.manish.applocker.recovery.RecoveryStore
import com.manish.applocker.recovery.RecoveryViewModel
import com.manish.applocker.ui.apps.AppsScreen
import com.manish.applocker.ui.home.HomeScreen
import com.manish.applocker.ui.protection.ProtectionScreen
import com.manish.applocker.ui.recovery.RecoverySetupScreen
import com.manish.applocker.ui.settings.ChangePinScreen
import com.manish.applocker.ui.settings.SettingsScreen

private enum class Tab { HOME, APPS, PROTECTION, SETTINGS }

/** The unlocked part of the app: bottom navigation with Dashboard, Apps and Protection. */
@Composable
fun MainShell(
    vm: AppViewModel,
    appsVm: AppsViewModel,
    recoveryVm: RecoveryViewModel,
    fingerprintAvailable: Boolean,
    onFingerprintToggle: (Boolean) -> Unit
) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    var showRecovery by rememberSaveable { mutableStateOf(false) }
    var showChangePin by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current

    val fingerprintEnabled by vm.fingerprintEnabled.collectAsState()
    val protection by vm.protectionState.collectAsState()
    val engineConnected by AppLockService.connected.collectAsState()
    val recoveryEmail by RecoveryStore.email.collectAsState()
    val lockedCount by appsVm.lockedCount.collectAsState()
    val apps by appsVm.visibleApps.collectAsState()
    val lockedPackages by appsVm.lockedPackages.collectAsState()
    val query by appsVm.query.collectAsState()
    val loading by appsVm.loading.collectAsState()

    val attention = buildList {
        if (!engineConnected) add("Lock engine is off, so apps are not being locked.")
        val level = protection.level(engineConnected)
        if (level == UninstallLevel.NONE || level == UninstallLevel.WEAK) {
            add("Uninstall protection is ${level.title.lowercase()}.")
        }
        if (recoveryEmail == null) add("No recovery email: a forgotten PIN cannot be reset.")
    }

    // Pick up new apps and real protection state whenever we come back to the screen.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        appsVm.refresh()
        vm.refreshProtection()
    }

    if (showRecovery) {
        BackHandler {
            recoveryVm.end()
            showRecovery = false
        }
        RecoverySetupScreen(
            vm = recoveryVm,
            allowSkip = false,
            onFinished = { showRecovery = false },
            onExit = { showRecovery = false }
        )
        return
    }

    if (showChangePin) {
        BackHandler { showChangePin = false }
        ChangePinScreen(
            verifyPin = { vm.verifyPin(it) },
            onSetNewPin = { vm.changePin(it) },
            onDone = { showChangePin = false },
            onCancel = { showChangePin = false }
        )
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = tab == Tab.HOME,
                    onClick = { tab = Tab.HOME },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Dashboard") }
                )
                NavigationBarItem(
                    selected = tab == Tab.APPS,
                    onClick = { tab = Tab.APPS },
                    icon = { Icon(Icons.Filled.Apps, contentDescription = null) },
                    label = { Text("Apps") }
                )
                NavigationBarItem(
                    selected = tab == Tab.PROTECTION,
                    onClick = { tab = Tab.PROTECTION },
                    icon = { Icon(Icons.Filled.Security, contentDescription = null) },
                    label = { Text("Protection") }
                )
                NavigationBarItem(
                    selected = tab == Tab.SETTINGS,
                    onClick = { tab = Tab.SETTINGS },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("Settings") }
                )
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner)) {
            when (tab) {
                Tab.HOME -> HomeScreen(
                    lockedCount = lockedCount,
                    engineConnected = engineConnected,
                    uninstallLevel = protection.level(engineConnected),
                    recoveryEmail = recoveryEmail,
                    attention = attention,
                    fingerprintEnabled = fingerprintEnabled,
                    fingerprintAvailable = fingerprintAvailable,
                    onFingerprintToggle = onFingerprintToggle,
                    onLockNow = { vm.lockNow() }
                )
                Tab.APPS -> AppsScreen(
                    apps = apps,
                    lockedPackages = lockedPackages,
                    lockedCount = lockedCount,
                    query = query,
                    loading = loading,
                    engineConnected = engineConnected,
                    onQueryChange = appsVm::setQuery,
                    onToggle = appsVm::setLocked
                )
                Tab.PROTECTION -> ProtectionScreen(
                    snapshot = protection,
                    engineRunning = engineConnected,
                    phoneInfo = vm.phoneInfo,
                    adbCommand = vm.adbCommand,
                    recoveryEmail = recoveryEmail,
                    onChangeRecovery = { showRecovery = true },
                    onActivateAdmin = { context.startActivity(vm.adminActivationIntent()) },
                    verifyPin = { vm.verifyPin(it) },
                    onDeactivate = { vm.deactivateProtection() }
                )
                Tab.SETTINGS -> SettingsScreen(
                    fingerprintEnabled = fingerprintEnabled,
                    fingerprintAvailable = fingerprintAvailable,
                    onFingerprintToggle = onFingerprintToggle,
                    onChangePin = { showChangePin = true },
                    phoneInfo = vm.phoneInfo
                )
            }
        }
    }
}

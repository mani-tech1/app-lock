package com.manish.applocker.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.manish.applocker.AppViewModel
import com.manish.applocker.AppsViewModel
import com.manish.applocker.data.UiPrefs
import com.manish.applocker.engine.AppLockService
import com.manish.applocker.engine.ExternalFlow
import com.manish.applocker.recovery.RecoveryAnswerStore
import com.manish.applocker.security.LockType
import com.manish.applocker.ui.apps.AppsScreen
import com.manish.applocker.ui.apps.SpatialAppsScreen
import com.manish.applocker.ui.components.PinConfirmDialog
import com.manish.applocker.ui.protection.ProtectionScreen
import com.manish.applocker.ui.recovery.RecoveryAnswerScreen
import com.manish.applocker.ui.settings.ChangePinScreen
import com.manish.applocker.ui.settings.FaqScreen
import com.manish.applocker.ui.settings.SettingsScreen

private enum class Tab { APPS, SETTINGS }
private enum class Overlay { NONE, CHANGE_PIN, RECOVERY, PROTECTION, FAQ }

/** The unlocked part of the app: two tabs, Apps and Settings, plus full-screen pages opened from Settings. */
@Composable
fun MainShell(
    vm: AppViewModel,
    appsVm: AppsViewModel,
    fingerprintAvailable: Boolean,
    onFingerprintToggle: (Boolean) -> Unit
) {
    var tab by rememberSaveable { mutableStateOf(Tab.APPS) }
    var overlay by rememberSaveable { mutableStateOf(Overlay.NONE) }
    var newType by rememberSaveable { mutableStateOf<LockType?>(null) }
    var askPinForRecovery by remember { mutableStateOf(false) }
    var askPinForDeactivate by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val fingerprintEnabled by vm.fingerprintEnabled.collectAsState()
    val lockType by vm.lockType.collectAsState()
    val protection by vm.protectionState.collectAsState()
    val engineConnected by AppLockService.connected.collectAsState()
    val recoveryHint by RecoveryAnswerStore.hint.collectAsState()
    val lockedCount by appsVm.lockedCount.collectAsState()
    val apps by appsVm.visibleApps.collectAsState()
    val allApps by appsVm.installedApps.collectAsState()
    val spatial by UiPrefs.spatialApps.collectAsState()
    val lockedPackages by appsVm.lockedPackages.collectAsState()
    val query by appsVm.query.collectAsState()
    val loading by appsVm.loading.collectAsState()

    // Pick up new apps and the real protection state whenever we come back to the screen.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        appsVm.refresh()
        vm.refreshProtection()
    }

    when (overlay) {
        Overlay.CHANGE_PIN -> {
            BackHandler {
                overlay = Overlay.NONE
                newType = null
            }
            ChangePinScreen(
                currentType = lockType,
                verifyPin = { vm.verifyPin(it) },
                onSave = { t, s -> vm.changeSecret(t, s) },
                onDone = {
                    overlay = Overlay.NONE
                    newType = null
                },
                onCancel = {
                    overlay = Overlay.NONE
                    newType = null
                },
                startType = newType ?: lockType,
                allowTypeChange = newType == null
            )
            return
        }
        Overlay.RECOVERY -> {
            BackHandler { overlay = Overlay.NONE }
            RecoveryAnswerScreen(
                allowSkip = false,
                onDone = { overlay = Overlay.NONE },
                onExit = { overlay = Overlay.NONE }
            )
            return
        }
        Overlay.PROTECTION -> {
            BackHandler { overlay = Overlay.NONE }
            ProtectionScreen(
                snapshot = protection,
                engineRunning = engineConnected,
                phoneInfo = vm.phoneInfo,
                adbCommand = vm.adbCommand,
                onActivateAdmin = {
                    ExternalFlow.begin()
                    context.startActivity(vm.adminActivationIntent())
                },
                verifyPin = { vm.verifyPin(it) },
                onDeactivate = { vm.deactivateProtection() },
                onBack = { overlay = Overlay.NONE }
            )
            return
        }
        Overlay.FAQ -> {
            BackHandler { overlay = Overlay.NONE }
            FaqScreen(onBack = { overlay = Overlay.NONE })
            return
        }
        Overlay.NONE -> Unit
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = tab == Tab.APPS,
                    onClick = { tab = Tab.APPS },
                    icon = { Icon(Icons.Filled.Apps, contentDescription = null) },
                    label = { Text("Apps") }
                )
                NavigationBarItem(
                    selected = tab == Tab.SETTINGS,
                    onClick = { tab = Tab.SETTINGS },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("Settings") }
                )
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner)) {
            when (tab) {
                Tab.APPS -> if (spatial) SpatialAppsScreen(
                    apps = allApps,
                    lockedPackages = lockedPackages,
                    loading = loading,
                    engineConnected = engineConnected,
                    onLockChange = appsVm::setLocked
                ) else AppsScreen(
                    apps = apps,
                    lockedPackages = lockedPackages,
                    lockedCount = lockedCount,
                    query = query,
                    loading = loading,
                    engineConnected = engineConnected,
                    onQueryChange = appsVm::setQuery,
                    onToggle = appsVm::setLocked
                )
                Tab.SETTINGS -> SettingsScreen(
                    lockType = lockType,
                    fingerprintEnabled = fingerprintEnabled,
                    fingerprintAvailable = fingerprintAvailable,
                    recoveryHint = recoveryHint,
                    uninstallLevel = protection.level(engineConnected),
                    adminActive = protection.adminActive,
                    onFaq = { overlay = Overlay.FAQ },
                    onFingerprintToggle = onFingerprintToggle,
                    onChangePassword = {
                        newType = null
                        overlay = Overlay.CHANGE_PIN
                    },
                    onChangeType = { t ->
                        newType = t
                        overlay = Overlay.CHANGE_PIN
                    },
                    onRecovery = {
                        if (recoveryHint == null) overlay = Overlay.RECOVERY
                        else askPinForRecovery = true
                    },
                    onUninstallToggle = { wantOn ->
                        if (wantOn) {
                            ExternalFlow.begin()
                            context.startActivity(vm.adminActivationIntent())
                        } else {
                            askPinForDeactivate = true
                        }
                    },
                    onUninstallDetails = { overlay = Overlay.PROTECTION }
                )
            }
        }
    }

    if (askPinForRecovery) {
        PinConfirmDialog(
            title = "Change recovery answer?",
            message = "Enter your lock to continue.",
            verifyPin = { vm.verifyPin(it) },
            onConfirmed = {
                askPinForRecovery = false
                overlay = Overlay.RECOVERY
            },
            onDismiss = { askPinForRecovery = false }
        )
    }
    if (askPinForDeactivate) {
        PinConfirmDialog(
            title = "Turn off uninstall protection?",
            message = "App Locker could then be uninstalled. Enter your lock to continue.",
            verifyPin = { vm.verifyPin(it) },
            onConfirmed = {
                askPinForDeactivate = false
                val error = vm.deactivateProtection()
                if (error != null) {
                    Toast.makeText(context, "Could not turn off: $error", Toast.LENGTH_LONG).show()
                }
            },
            onDismiss = { askPinForDeactivate = false }
        )
    }
}

package com.manish.applocker.health

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * After a reboot: re-apply the Device Owner uninstall block, make sure the health job exists,
 * and report if Accessibility was switched off. Android itself restarts an enabled
 * Accessibility service, so the lock engine comes back without us.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        HealthMonitor.schedule(context)
        HealthMonitor.check(context)
    }
}

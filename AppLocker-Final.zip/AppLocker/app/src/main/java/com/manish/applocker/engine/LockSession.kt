package com.manish.applocker.engine

import android.os.SystemClock

/**
 * Short-lived "the user has already proven who they are" state.
 * - [unlockedPkg]: the protected app (or guarded Settings screen) just unlocked.
 *   Cleared the moment the user leaves it or the screen turns off.
 * - settings bypass: a short window opened by App Locker itself right before it sends
 *   the (already PIN-authenticated) user to an Android settings screen.
 */
object LockSession {
    @Volatile
    var unlockedPkg: String? = null

    @Volatile
    private var settingsBypassUntil = 0L

    fun clear() {
        unlockedPkg = null
    }

    fun allowSettingsFor(ms: Long) {
        settingsBypassUntil = SystemClock.elapsedRealtime() + ms
    }

    fun settingsBypassActive(): Boolean = SystemClock.elapsedRealtime() < settingsBypassUntil
}

package com.manish.applocker.ui.pin

import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import com.manish.applocker.security.LockType
import com.manish.applocker.security.PinResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.ceil

/**
 * The lock screen. The PIN pad / pattern / password field AND the fingerprint sensor are
 * active at the same time, with no fingerprint pop-up.
 */
@Composable
fun UnlockScreen(
    fingerprintReady: Boolean,
    lockType: LockType,
    verifyPin: suspend (String) -> PinResult,
    lockoutRemainingMs: () -> Long,
    requestFingerprint: (onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit,
    onUnlocked: () -> Unit,
    title: String = "Welcome back",
    headerIcon: ImageBitmap? = null,
    onForgotPin: (() -> Unit)? = null
) {
    var resetKey by remember { mutableIntStateOf(0) }
    var shakeKey by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var tapMessage by remember { mutableStateOf<String?>(null) }
    var remaining by remember { mutableLongStateOf(lockoutRemainingMs()) }
    val scope = rememberCoroutineScope()

    // Ticks the countdown while a lockout is active.
    LaunchedEffect(remaining > 0L) {
        while (remaining > 0L) {
            delay(500)
            remaining = lockoutRemainingMs()
        }
    }

    val fp = rememberSilentFingerprint(enabled = fingerprintReady, onSuccess = onUnlocked)
    val fingerprintShown =
        if (fp.mode == FingerprintStatus.Mode.OFF) null
        else fp.copy(message = fp.message ?: tapMessage)

    val lockedOut = remaining > 0L
    val shown = when {
        lockedOut -> "Too many wrong attempts. Try again in ${formatMs(remaining)}"
        message.isNotEmpty() -> message
        else -> lockType.prompt
    }

    PinEntryScreen(
        title = title,
        message = shown,
        isError = lockedOut || isError,
        resetKey = resetKey,
        shakeKey = shakeKey,
        enabled = !lockedOut,
        lockType = lockType,
        fingerprint = fingerprintShown,
        onFingerprintTap = {
            requestFingerprint({ onUnlocked() }, { msg -> tapMessage = msg })
        },
        headerIcon = headerIcon,
        onComplete = { secret ->
            scope.launch {
                when (val r = verifyPin(secret)) {
                    PinResult.Success -> onUnlocked()
                    is PinResult.Wrong -> {
                        shakeKey++
                        resetKey++
                        remaining = r.lockedForMs
                        isError = true
                        message = if (r.lockedForMs > 0) ""
                        else "Wrong ${lockType.noun}. ${r.attemptsLeftBeforeDelay} tries left before a delay."
                    }
                    is PinResult.LockedOut -> {
                        resetKey++
                        remaining = r.remainingMs
                    }
                    PinResult.Corrupted -> {
                        resetKey++
                        isError = true
                        message = "Saved lock could not be read. Use Forgot ${lockType.noun}? to reset it by email."
                    }
                    PinResult.NotSet -> {
                        resetKey++
                        isError = true
                        message = "No lock is set."
                    }
                }
            }
        },
        footer = {
            if (onForgotPin != null) {
                TextButton(onClick = onForgotPin) { Text("Forgot ${lockType.noun}?") }
            }
        }
    )
}

private fun formatMs(ms: Long): String {
    val s = ceil(ms / 1000.0).toLong()
    return "%d:%02d".format(s / 60, s % 60)
}

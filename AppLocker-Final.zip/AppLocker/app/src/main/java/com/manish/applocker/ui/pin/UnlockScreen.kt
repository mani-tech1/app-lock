package com.manish.applocker.ui.pin

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.manish.applocker.security.PinResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.ceil

@Composable
fun UnlockScreen(
    fingerprintReady: Boolean,
    title: String = "Welcome back",
    headerContent: (@Composable () -> Unit)? = null,
    onForgotPin: (() -> Unit)? = null,
    verifyPin: suspend (String) -> PinResult,
    lockoutRemainingMs: () -> Long,
    requestFingerprint: (onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit,
    onUnlocked: () -> Unit
) {
    var resetKey by remember { mutableIntStateOf(0) }
    var shakeKey by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var remaining by remember { mutableLongStateOf(lockoutRemainingMs()) }
    val scope = rememberCoroutineScope()

    // Ticks the countdown while a lockout is active.
    LaunchedEffect(remaining > 0L) {
        while (remaining > 0L) {
            delay(500)
            remaining = lockoutRemainingMs()
        }
    }

    fun tryFingerprint() {
        requestFingerprint(
            { onUnlocked() },
            { msg -> message = msg; isError = true }
        )
    }

    LaunchedEffect(Unit) {
        if (fingerprintReady && remaining == 0L) tryFingerprint()
    }

    val lockedOut = remaining > 0L
    val shown = when {
        lockedOut -> "Too many wrong attempts. Try again in ${formatMs(remaining)}"
        message.isNotEmpty() -> message
        else -> "Enter your PIN"
    }

    PinEntryScreen(
        title = title,
        headerContent = headerContent,
        message = shown,
        isError = lockedOut || isError,
        resetKey = resetKey,
        shakeKey = shakeKey,
        enabled = !lockedOut,
        onComplete = { pin ->
            scope.launch {
                when (val r = verifyPin(pin)) {
                    PinResult.Success -> onUnlocked()
                    is PinResult.Wrong -> {
                        shakeKey++
                        resetKey++
                        remaining = r.lockedForMs
                        isError = true
                        message = if (r.lockedForMs > 0) ""
                        else "Wrong PIN. ${r.attemptsLeftBeforeDelay} tries left before a delay."
                    }
                    is PinResult.LockedOut -> {
                        resetKey++
                        remaining = r.remainingMs
                    }
                    PinResult.Corrupted -> {
                        resetKey++
                        isError = true
                        message = "Saved PIN could not be read. Use Forgot PIN? to reset it by email."
                    }
                    PinResult.NotSet -> {
                        resetKey++
                        isError = true
                        message = "No PIN is set."
                    }
                }
            }
        },
        leftKey = {
            if (fingerprintReady) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .clickable(enabled = !lockedOut) { tryFingerprint() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Fingerprint,
                        contentDescription = "Use fingerprint",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }
        },
        footer = {
            if (onForgotPin != null) {
                TextButton(onClick = onForgotPin) { Text("Forgot PIN?") }
            }
        }
    )
}

private fun formatMs(ms: Long): String {
    val s = ceil(ms / 1000.0).toLong()
    return "%d:%02d".format(s / 60, s % 60)
}

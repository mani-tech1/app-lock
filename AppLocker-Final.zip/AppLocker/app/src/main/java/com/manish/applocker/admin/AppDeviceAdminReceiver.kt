package com.manish.applocker.admin

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AppDeviceAdminReceiver : DeviceAdminReceiver() {
    /** Text Android shows on its own "Deactivate device admin" screen. */
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Deactivating removes App Locker's uninstall protection. " +
            "Anyone could then uninstall it. Only continue if this is you."
}

package com.manish.applocker.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

private class BackdropStar(val x: Float, val y: Float, val depth: Float, val size: Float, val phase: Float)

private val BackdropPurple = Color(0xFF8E54E9)
private val BackdropCyan = Color(0xFF38E8FF)

/** Deep-space background: dark gradient, breathing purple and cyan light, twinkling stars. */
@Composable
fun SpaceBackdrop(modifier: Modifier = Modifier, time: () -> Float) {
    val stars = remember {
        val r = Random(11)
        List(100) {
            BackdropStar(
                x = r.nextFloat(),
                y = r.nextFloat(),
                depth = 0.2f + r.nextFloat() * 0.8f,
                size = 0.6f + r.nextFloat() * 1.4f,
                phase = r.nextFloat() * 6.28f
            )
        }
    }
    Canvas(modifier) {
        val t = time()   // read here, so only this draw reruns each frame
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas
        drawRect(Brush.verticalGradient(listOf(Color(0xFF080519), Color(0xFF05040F), Color(0xFF020712))))
        drawRect(
            Brush.radialGradient(
                colors = listOf(BackdropPurple.copy(alpha = 0.38f + 0.08f * sin(t * 0.6f)), Color.Transparent),
                center = Offset(w * 0.2f, h * 0.25f),
                radius = max(1f, max(w, h) * 0.75f)
            )
        )
        drawRect(
            Brush.radialGradient(
                colors = listOf(BackdropCyan.copy(alpha = 0.24f + 0.06f * cos(t * 0.5f)), Color.Transparent),
                center = Offset(w * 0.85f, h * 0.8f),
                radius = max(1f, max(w, h) * 0.65f)
            )
        )
        for (s in stars) {
            val px = ((s.x * w + t * 5f * s.depth * density) % w + w) % w
            val py = ((s.y * h + t * 2f * s.depth * density) % h + h) % h
            val tw = 0.65f + 0.35f * sin(t * 1.6f + s.phase)
            drawCircle(
                color = Color.White.copy(alpha = ((0.18f + 0.55f * s.depth) * tw).coerceIn(0f, 1f)),
                radius = s.size * density * (0.55f + 0.6f * s.depth),
                center = Offset(px, py)
            )
        }
    }
}

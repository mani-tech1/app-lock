package com.manish.applocker.engine

import android.os.SystemClock

/**
 * App Locker locks itself the moment you leave it. The one exception: when WE open a system
 * picker (photo picker, Google account chooser, permission dialog) the result has to come back
 * to this screen, so locking is paused for a short window. If you stay away longer than the
 * window, the app locks when you return.
 */
object ExternalFlow {
    private const val WINDOW_MS = 90_000L

    @Volatile
    private var until = 0L

    fun begin() {
        until = SystemClock.elapsedRealtime() + WINDOW_MS
    }

    /** True while a picker we opened is still inside its window. */
    fun isActive(): Boolean = SystemClock.elapsedRealtime() < until

    /** Call when the app is visible again. Returns true if the window ran out while away. */
    fun finish(): Boolean {
        val expired = until != 0L && SystemClock.elapsedRealtime() >= until
        until = 0L
        return expired
    }
}

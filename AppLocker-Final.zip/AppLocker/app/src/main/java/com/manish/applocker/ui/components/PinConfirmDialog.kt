package com.manish.applocker.ui.components

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import com.manish.applocker.security.PinManager
import com.manish.applocker.security.PinResult
import com.manish.applocker.ui.pin.PinEntryScreen
import kotlinx.coroutines.launch
import kotlin.math.ceil

/**
 * Asks for the current lock (PIN, pattern or password) before a sensitive action.
 * Full-screen so a pattern can be drawn. Respects the normal attempt lockout.
 */
@Composable
fun PinConfirmDialog(
    title: String,
    message: String,
    verifyPin: suspend (String) -> PinResult,
    onConfirmed: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val type = remember { PinManager(context.applicationContext).lockType }
    var resetKey by remember { mutableIntStateOf(0) }
    var shakeKey by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            securePolicy = SecureFlagPolicy.SecureOn
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            PinEntryScreen(
                title = title,
                message = error.ifEmpty { message },
                isError = error.isNotEmpty(),
                resetKey = resetKey,
                shakeKey = shakeKey,
                enabled = !busy,
                lockType = type,
                onComplete = { secret ->
                    busy = true
                    scope.launch {
                        val result = verifyPin(secret)
                        busy = false
                        when (result) {
                            PinResult.Success -> onConfirmed()
                            is PinResult.Wrong -> {
                                error = if (result.lockedForMs > 0) "Too many attempts. Wait a moment."
                                else "Wrong ${type.noun}"
                                shakeKey++
                                resetKey++
                            }
                            is PinResult.LockedOut -> {
                                error = "Locked. Try again in ${ceil(result.remainingMs / 1000.0).toInt()}s"
                                resetKey++
                            }
                            else -> {
                                error = "It could not be verified"
                                resetKey++
                            }
                        }
                    }
                },
                footer = { TextButton(onClick = onDismiss) { Text("Cancel") } }
            )
        }
    }
}

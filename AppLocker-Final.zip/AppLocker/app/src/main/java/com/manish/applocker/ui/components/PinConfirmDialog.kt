package com.manish.applocker.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.manish.applocker.security.PinPolicy
import com.manish.applocker.security.PinResult
import kotlinx.coroutines.launch
import kotlin.math.ceil

/** Asks for the PIN again before a sensitive action. Respects the normal attempt lockout. */
@Composable
fun PinConfirmDialog(
    title: String,
    message: String,
    verifyPin: suspend (String) -> PinResult,
    onConfirmed: () -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(message)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = {
                        if (it.length <= PinPolicy.LENGTH && it.all(Char::isDigit)) pin = it
                    },
                    singleLine = true,
                    label = { Text("PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    isError = error.isNotEmpty(),
                    supportingText = { if (error.isNotEmpty()) Text(error) }
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = pin.length == PinPolicy.LENGTH && !busy,
                onClick = {
                    busy = true
                    scope.launch {
                        val result = verifyPin(pin)
                        busy = false
                        when (result) {
                            PinResult.Success -> onConfirmed()
                            is PinResult.Wrong -> {
                                error = if (result.lockedForMs > 0) "Too many attempts. Wait a moment."
                                else "Wrong PIN"
                                pin = ""
                            }
                            is PinResult.LockedOut -> {
                                error = "Locked. Try again in ${ceil(result.remainingMs / 1000.0).toInt()}s"
                                pin = ""
                            }
                            else -> {
                                error = "PIN could not be verified"
                                pin = ""
                            }
                        }
                    }
                }
            ) { Text("Confirm") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

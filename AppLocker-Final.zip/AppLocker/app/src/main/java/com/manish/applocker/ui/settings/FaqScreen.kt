package com.manish.applocker.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private val faq = listOf(
    "How do I lock an app?" to
        "Open the Apps tab and switch on the apps you want to protect. The lock screen then appears every time one of them opens.",
    "Why is Accessibility needed?" to
        "Android has no other way for an app to notice that another app just opened. App Locker only watches which app is in front. On Settings and uninstall screens it also looks for its own name so it can ask for your lock.",
    "Why does App Locker ask for my lock when I come back?" to
        "It locks itself the moment you leave it, so nobody can open it behind your back.",
    "How does fingerprint work?" to
        "The PIN pad (or pattern, or password) and the fingerprint sensor are both active. Type your lock or just touch the sensor. No pop-up appears. If your phone does not allow this, a fingerprint icon appears that you tap once.",
    "I forgot my lock. What now?" to
        "Tap \"Forgot ...?\" on the lock screen. You will be asked your recovery question. Type your answer (capital or small letters do not matter) and choose a new lock. Set the answer in Settings > Password recovery method if that row shows a red mark.",
    "What does Uninstall protection do?" to
        "It makes App Locker a Device Admin, so the Uninstall button is greyed out and Android Settings asks for your lock first. It can still be bypassed in Safe Mode. The strongest protection (Device Owner) needs a computer and is explained inside the Uninstall protection screen.",
    "Why does protection stop sometimes?" to
        "Battery savers on some phones close background apps. Allow \"No restrictions\" for App Locker, enable Autostart, and lock the app in the recent apps list.",
    "Can I change the lock type?" to
        "Yes. In Settings tap Password type and choose 4-digit PIN, 6-digit PIN, Pattern or Password. You will be asked for your current lock first."
)

@Composable
fun FaqScreen(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                "FAQ",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
        faq.forEach { (q, a) ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(q, style = MaterialTheme.typography.titleMedium)
                    Text(
                        a,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

package com.manish.applocker.security

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom

sealed interface PinResult {
    data object Success : PinResult
    data class Wrong(
        val failedAttempts: Int,
        val lockedForMs: Long,
        val attemptsLeftBeforeDelay: Int
    ) : PinResult
    data class LockedOut(val remainingMs: Long) : PinResult
    /** Stored PIN could not be decrypted (keystore key lost). Needs recovery. */
    data object Corrupted : PinResult
    data object NotSet : PinResult
}

/**
 * Stores the PIN as: PBKDF2(pin, random salt) -> AES-GCM encrypted with a
 * Keystore key. Tracks failed attempts with escalating lockouts that survive
 * app restarts, reboots and (within one boot) clock changes.
 */
class PinManager(context: Context) {

    private val app = context.applicationContext
    private val prefs: SharedPreferences =
        app.getSharedPreferences("secure_pin_store", Context.MODE_PRIVATE)

    fun isPinSet(): Boolean = prefs.contains(K_HASH) && prefs.contains(K_SALT)

    var fingerprintEnabled: Boolean
        get() = prefs.getBoolean(K_FP, false)
        set(value) {
            prefs.edit().putBoolean(K_FP, value).apply()
        }

    /** @return true if the PIN was stored securely. */
    suspend fun setPin(pin: String): Boolean = withContext(Dispatchers.Default) {
        try {
            val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
            val hash = Pbkdf2.hmacSha256(pin, salt, ITERATIONS)
            val sealed = KeystoreCipher.encrypt(hash)
            prefs.edit()
                .putString(K_SALT, enc(salt))
                .putString(K_HASH, enc(sealed))
                .putInt(K_ITER, ITERATIONS)
                .putInt(K_FAILS, 0)
                .remove(K_LOCK_WALL)
                .remove(K_LOCK_ELAPSED)
                .remove(K_BOOT)
                .commit()
        } catch (e: Exception) {
            false
        }
    }

    suspend fun verify(pin: String): PinResult = withContext(Dispatchers.Default) {
        val saltStr = prefs.getString(K_SALT, null)
        val hashStr = prefs.getString(K_HASH, null)
        if (saltStr == null || hashStr == null) return@withContext PinResult.NotSet

        val remaining = remainingLockMs()
        if (remaining > 0) return@withContext PinResult.LockedOut(remaining)

        val expected = try {
            KeystoreCipher.decrypt(dec(hashStr))
        } catch (e: Exception) {
            return@withContext PinResult.Corrupted
        }
        val actual = Pbkdf2.hmacSha256(pin, dec(saltStr), prefs.getInt(K_ITER, ITERATIONS))

        if (MessageDigest.isEqual(expected, actual)) {
            prefs.edit()
                .putInt(K_FAILS, 0)
                .remove(K_LOCK_WALL)
                .remove(K_LOCK_ELAPSED)
                .remove(K_BOOT)
                .commit()
            PinResult.Success
        } else {
            registerFailure()
        }
    }

    /** Milliseconds left in the current lockout, 0 if none. */
    fun remainingLockMs(): Long {
        if (!prefs.contains(K_LOCK_WALL)) return 0L
        val sameBoot = prefs.getInt(K_BOOT, -2) == bootCount()
        return if (sameBoot) {
            // Same boot: monotonic clock, immune to the user changing the date.
            (prefs.getLong(K_LOCK_ELAPSED, 0L) - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
        } else {
            // After a reboot the monotonic clock restarted: fall back to wall clock.
            (prefs.getLong(K_LOCK_WALL, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
        }
    }

    private fun registerFailure(): PinResult.Wrong {
        val fails = prefs.getInt(K_FAILS, 0) + 1
        val delay = delayForFailures(fails)
        val editor = prefs.edit().putInt(K_FAILS, fails)
        if (delay > 0) {
            editor
                .putLong(K_LOCK_WALL, System.currentTimeMillis() + delay)
                .putLong(K_LOCK_ELAPSED, SystemClock.elapsedRealtime() + delay)
                .putInt(K_BOOT, bootCount())
        }
        editor.commit()
        return PinResult.Wrong(
            failedAttempts = fails,
            lockedForMs = delay,
            attemptsLeftBeforeDelay = (FREE_ATTEMPTS - fails).coerceAtLeast(0)
        )
    }

    private fun delayForFailures(fails: Int): Long = when {
        fails < FREE_ATTEMPTS -> 0L
        fails == FREE_ATTEMPTS -> 30_000L
        fails == FREE_ATTEMPTS + 1 -> 60_000L
        fails == FREE_ATTEMPTS + 2 -> 5 * 60_000L
        fails == FREE_ATTEMPTS + 3 -> 15 * 60_000L
        else -> 30 * 60_000L
    }

    private fun bootCount(): Int =
        Settings.Global.getInt(app.contentResolver, Settings.Global.BOOT_COUNT, -1)

    private fun enc(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun dec(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    private companion object {
        const val SALT_BYTES = 16
        const val ITERATIONS = 100_000
        const val FREE_ATTEMPTS = 5

        const val K_SALT = "salt"
        const val K_HASH = "hash"
        const val K_ITER = "iter"
        const val K_FAILS = "fails"
        const val K_LOCK_WALL = "lock_wall"
        const val K_LOCK_ELAPSED = "lock_elapsed"
        const val K_BOOT = "lock_boot"
        const val K_FP = "fingerprint_enabled"
    }
}

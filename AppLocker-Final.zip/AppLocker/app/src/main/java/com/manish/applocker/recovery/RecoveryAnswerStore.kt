package com.manish.applocker.recovery

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import com.manish.applocker.security.KeystoreCipher
import com.manish.applocker.security.Pbkdf2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom

sealed interface AnswerResult {
    data object Success : AnswerResult
    data class Wrong(val attemptsLeftBeforeDelay: Int, val lockedForMs: Long) : AnswerResult
    data class LockedOut(val remainingMs: Long) : AnswerResult
    data object NotSet : AnswerResult
    data object Corrupted : AnswerResult
}

/**
 * The "recovery answer": a secret word or number (letters A-Z and digits 0-9 only, not case
 * sensitive) with a question label such as "Favourite place". Only a salted hash of the answer
 * is stored, encrypted with the Android Keystore. Wrong answers slow down with growing delays.
 */
object RecoveryAnswerStore {
    private const val PREFS = "recovery_answer"
    private const val K_HINT = "hint"
    private const val K_SALT = "salt"
    private const val K_HASH = "hash"
    private const val K_FAILS = "fails"
    private const val K_LOCK_WALL = "lock_wall"
    private const val K_LOCK_ELAPSED = "lock_elapsed"
    private const val K_BOOT = "lock_boot"
    private const val ITERATIONS = 100_000
    private const val FREE_ATTEMPTS = 5
    const val MIN_LENGTH = 3
    const val MAX_LENGTH = 30

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private val _hint = MutableStateFlow<String?>(null)

    /** The question label, or null when no answer has been set. */
    val hint: StateFlow<String?> = _hint.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        app = context.applicationContext
        prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _hint.value = if (prefs.contains(K_HASH)) prefs.getString(K_HINT, null) else null
    }

    fun isSet(): Boolean = prefs.contains(K_HASH)

    private fun allowed(c: Char) = c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9'

    /** Removes everything except A-Z, a-z and 0-9 (spaces and symbols never get in). */
    fun clean(raw: String): String = raw.filter { allowed(it) }.take(MAX_LENGTH)

    /** @return null if the answer is acceptable, otherwise the message to show. */
    fun problem(answer: String): String? = when {
        answer.isEmpty() -> "Type an answer."
        !answer.all { allowed(it) } -> "Only letters A-Z and numbers 0-9, no spaces or symbols."
        answer.length < MIN_LENGTH -> "Use at least $MIN_LENGTH letters or numbers."
        else -> null
    }

    suspend fun save(hint: String, answer: String): Boolean = withContext(Dispatchers.Default) {
        try {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val hash = Pbkdf2.hmacSha256(answer.lowercase(), salt, ITERATIONS)
            val sealed = KeystoreCipher.encrypt(hash)
            val ok = prefs.edit()
                .putString(K_HINT, hint)
                .putString(K_SALT, enc(salt))
                .putString(K_HASH, enc(sealed))
                .putInt(K_FAILS, 0)
                .remove(K_LOCK_WALL)
                .remove(K_LOCK_ELAPSED)
                .remove(K_BOOT)
                .commit()
            if (ok) _hint.value = hint
            ok
        } catch (e: Exception) {
            false
        }
    }

    suspend fun verify(answer: String): AnswerResult = withContext(Dispatchers.Default) {
        val saltStr = prefs.getString(K_SALT, null)
        val hashStr = prefs.getString(K_HASH, null)
        if (saltStr == null || hashStr == null) return@withContext AnswerResult.NotSet

        val remaining = remainingLockMs()
        if (remaining > 0) return@withContext AnswerResult.LockedOut(remaining)

        val expected = try {
            KeystoreCipher.decrypt(dec(hashStr))
        } catch (e: Exception) {
            return@withContext AnswerResult.Corrupted
        }
        val actual = Pbkdf2.hmacSha256(answer.lowercase(), dec(saltStr), ITERATIONS)

        if (MessageDigest.isEqual(expected, actual)) {
            prefs.edit()
                .putInt(K_FAILS, 0)
                .remove(K_LOCK_WALL)
                .remove(K_LOCK_ELAPSED)
                .remove(K_BOOT)
                .commit()
            AnswerResult.Success
        } else {
            registerFailure()
        }
    }

    /** Milliseconds left in the current lockout, 0 if none. */
    fun remainingLockMs(): Long {
        if (!prefs.contains(K_LOCK_WALL)) return 0L
        val sameBoot = prefs.getInt(K_BOOT, -2) == bootCount()
        return if (sameBoot) {
            (prefs.getLong(K_LOCK_ELAPSED, 0L) - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
        } else {
            (prefs.getLong(K_LOCK_WALL, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
        }
    }

    private fun registerFailure(): AnswerResult.Wrong {
        val fails = prefs.getInt(K_FAILS, 0) + 1
        val delay = when {
            fails < FREE_ATTEMPTS -> 0L
            fails == FREE_ATTEMPTS -> 60_000L
            fails == FREE_ATTEMPTS + 1 -> 5 * 60_000L
            fails == FREE_ATTEMPTS + 2 -> 15 * 60_000L
            else -> 60 * 60_000L
        }
        val editor = prefs.edit().putInt(K_FAILS, fails)
        if (delay > 0) {
            editor
                .putLong(K_LOCK_WALL, System.currentTimeMillis() + delay)
                .putLong(K_LOCK_ELAPSED, SystemClock.elapsedRealtime() + delay)
                .putInt(K_BOOT, bootCount())
        }
        editor.commit()
        return AnswerResult.Wrong(
            attemptsLeftBeforeDelay = (FREE_ATTEMPTS - fails).coerceAtLeast(0),
            lockedForMs = delay
        )
    }

    private fun bootCount(): Int =
        Settings.Global.getInt(app.contentResolver, Settings.Global.BOOT_COUNT, -1)

    private fun enc(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun dec(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)
}

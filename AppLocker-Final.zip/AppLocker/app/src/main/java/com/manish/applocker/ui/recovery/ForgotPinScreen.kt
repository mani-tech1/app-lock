package com.manish.applocker.ui.recovery

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.manish.applocker.recovery.AnswerResult
import com.manish.applocker.recovery.RecoveryAnswerStore
import com.manish.applocker.security.LockType
import com.manish.applocker.ui.pin.CreateSecretFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.ceil

/** Forgot lock: answer the recovery question, then choose a new lock (any type). */
@Composable
fun ForgotPinScreen(
    initialType: LockType,
    onSetNewSecret: suspend (LockType, String) -> Boolean,
    onFinished: () -> Unit,
    onCancel: () -> Unit
) {
    var verified by remember { mutableStateOf(false) }
    BackHandler { onCancel() }

    if (verified) {
        CreateSecretFlow(
            initialType = initialType,
            allowTypeChange = true,
            onSave = onSetNewSecret,
            onSaved = onFinished
        )
    } else {
        VerifyAnswer(onVerified = { verified = true }, onCancel = onCancel)
    }
}

@Composable
private fun VerifyAnswer(onVerified: () -> Unit, onCancel: () -> Unit) {
    val hint by RecoveryAnswerStore.hint.collectAsState()
    var answer by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var remaining by remember { mutableLongStateOf(RecoveryAnswerStore.remainingLockMs()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(remaining > 0L) {
        while (remaining > 0L) {
            delay(500)
            remaining = RecoveryAnswerStore.remainingLockMs()
        }
    }

    fun submit() {
        val problem = RecoveryAnswerStore.problem(answer)
        if (problem != null) {
            message = problem
            return
        }
        busy = true
        scope.launch {
            when (val r = RecoveryAnswerStore.verify(answer)) {
                AnswerResult.Success -> onVerified()
                is AnswerResult.Wrong -> {
                    remaining = r.lockedForMs
                    message = if (r.lockedForMs > 0) null
                    else "Wrong answer. ${r.attemptsLeftBeforeDelay} tries left before a delay."
                    answer = ""
                }
                is AnswerResult.LockedOut -> {
                    remaining = r.remainingMs
                    answer = ""
                }
                AnswerResult.NotSet -> message = "No recovery answer is set."
                AnswerResult.Corrupted -> message = "The saved answer could not be read."
            }
            busy = false
        }
    }

    val question = hint
    val lockedOut = remaining > 0L

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Forgot your lock?",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        if (question == null) {
            Text(
                "No recovery answer was set on this phone, so the lock cannot be reset from here. " +
                    "Restart the phone in Safe Mode (the guard is off there), then clear App Locker's " +
                    "data in Android Settings. See RECOVERY.md.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Text(
                "Answer your recovery question to set a new lock.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(question, style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = answer,
                onValueChange = { answer = RecoveryAnswerStore.clean(it) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                enabled = !busy && !lockedOut,
                label = { Text("Your answer") },
                visualTransformation =
                    if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { if (!busy && !lockedOut) submit() }),
                trailingIcon = {
                    TextButton(onClick = { visible = !visible }) { Text(if (visible) "Hide" else "Show") }
                }
            )
            Text(
                "Letters A-Z and numbers 0-9 only. Capital or small letters do not matter.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (lockedOut) {
                Text(
                    "Too many wrong answers. Try again in ${formatMs(remaining)}.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                message?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Button(
                onClick = { submit() },
                enabled = !busy && !lockedOut && answer.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Verify") }
        }

        TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
            Text("Back to lock screen")
        }
    }
}

private fun formatMs(ms: Long): String {
    val s = ceil(ms / 1000.0).toLong()
    return "%d:%02d".format(s / 60, s % 60)
}

package com.manish.applocker.ui.recovery

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.manish.applocker.recovery.RecoveryMode
import com.manish.applocker.recovery.RecoveryStep
import com.manish.applocker.recovery.RecoveryViewModel
import com.manish.applocker.security.PinPolicy
import com.manish.applocker.ui.pin.PinEntryScreen
import kotlinx.coroutines.launch

/** Forgot PIN: email code -> verified -> choose a new PIN. */
@Composable
fun ForgotPinScreen(
    vm: RecoveryViewModel,
    onSetNewPin: suspend (String) -> Boolean,
    onFinished: () -> Unit,
    onCancel: () -> Unit
) {
    val ui by vm.ui.collectAsState()
    LaunchedEffect(Unit) { vm.begin(RecoveryMode.RESET) }
    BackHandler {
        vm.end()
        onCancel()
    }

    if (!ui.started || ui.mode != RecoveryMode.RESET) {
        Box(Modifier.fillMaxSize())
        return
    }

    if (ui.step == RecoveryStep.DONE) {
        NewPinFlow(
            onSetNewPin = onSetNewPin,
            onSaved = {
                vm.end()
                onFinished()
            }
        )
    } else {
        RecoveryContent(
            ui = ui,
            vm = vm,
            exitLabel = "Back to PIN screen",
            exitNote = null,
            onExit = {
                vm.end()
                onCancel()
            },
            onFinished = {}
        )
    }
}

@Composable
private fun NewPinFlow(onSetNewPin: suspend (String) -> Boolean, onSaved: () -> Unit) {
    var confirming by remember { mutableStateOf(false) }
    var first by remember { mutableStateOf("") }
    var resetKey by remember { mutableIntStateOf(0) }
    var shakeKey by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    PinEntryScreen(
        title = if (confirming) "Confirm your new PIN" else "Create a new PIN",
        message = message.ifEmpty {
            if (confirming) "Enter the same PIN again" else "Choose a ${PinPolicy.LENGTH}-digit PIN"
        },
        isError = isError,
        resetKey = resetKey,
        shakeKey = shakeKey,
        enabled = !busy,
        onComplete = { pin ->
            if (!confirming) {
                if (PinPolicy.isWeak(pin)) {
                    message = "That PIN is too easy to guess. Try another."
                    isError = true
                    shakeKey++
                    resetKey++
                } else {
                    first = pin
                    message = ""
                    isError = false
                    confirming = true
                    resetKey++
                }
            } else if (pin == first) {
                busy = true
                scope.launch {
                    val ok = onSetNewPin(pin)
                    busy = false
                    if (ok) {
                        onSaved()
                    } else {
                        message = "Secure storage failed on this device. Try again."
                        isError = true
                        shakeKey++
                        confirming = false
                        first = ""
                        resetKey++
                    }
                }
            } else {
                message = "PINs did not match. Start again."
                isError = true
                shakeKey++
                confirming = false
                first = ""
                resetKey++
            }
        }
    )
}

package com.manish.applocker.ui.recovery

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.manish.applocker.recovery.RecoveryMode
import com.manish.applocker.recovery.RecoveryStep
import com.manish.applocker.recovery.RecoveryViewModel
import com.manish.applocker.security.LockType
import com.manish.applocker.ui.pin.CreateSecretFlow

/** Forgot password: email code -> verified -> choose a new lock (any type). */
@Composable
fun ForgotPinScreen(
    vm: RecoveryViewModel,
    initialType: LockType,
    onSetNewSecret: suspend (LockType, String) -> Boolean,
    onFinished: () -> Unit,
    onCancel: () -> Unit
) {
    val ui by vm.ui.collectAsState()
    LaunchedEffect(Unit) { vm.begin(RecoveryMode.RESET) }
    BackHandler {
        vm.end()
        onCancel()
    }

    if (!ui.started || ui.mode != RecoveryMode.RESET) {
        Box(Modifier.fillMaxSize())
        return
    }

    if (ui.step == RecoveryStep.DONE) {
        CreateSecretFlow(
            initialType = initialType,
            allowTypeChange = true,
            onSave = onSetNewSecret,
            onSaved = {
                vm.end()
                onFinished()
            }
        )
    } else {
        RecoveryContent(
            ui = ui,
            vm = vm,
            exitLabel = "Back to lock screen",
            exitNote = null,
            onExit = {
                vm.end()
                onCancel()
            },
            onFinished = {}
        )
    }
}

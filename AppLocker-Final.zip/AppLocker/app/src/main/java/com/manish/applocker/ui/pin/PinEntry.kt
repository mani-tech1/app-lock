package com.manish.applocker.ui.pin

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.manish.applocker.security.LockType
import androidx.compose.ui.layout.ContentScale
import com.manish.applocker.ui.theme.AppLockerTheme
import com.manish.applocker.ui.theme.Cyan400
import com.manish.applocker.ui.theme.Indigo600
import com.manish.applocker.ui.theme.Violet500
import kotlin.math.roundToInt

/** Settings can switch vibration on key presses off by providing false here. */
val LocalVibrateOnInput = compositionLocalOf { true }

/** The photo chosen in Settings > Theme, or null. Shown behind every lock screen. */
val LocalLockBackground = compositionLocalOf<ImageBitmap?> { null }

private val KeySize = 68.dp

/**
 * One screen for every lock type: PIN pad (4 or 6 digits), pattern grid, or password field.
 * - Bump [resetKey] to clear what was entered. Bump [shakeKey] to play the wrong-entry shake.
 * - [fingerprint] shows a hint while the sensor is listening (no pop-up).
 */
@Composable
private fun EntryContent(
    title: String,
    message: String,
    isError: Boolean,
    resetKey: Int,
    shakeKey: Int,
    enabled: Boolean,
    onComplete: (String) -> Unit,
    lockType: LockType = LockType.PIN4,
    fingerprint: FingerprintStatus? = null,
    onFingerprintTap: (() -> Unit)? = null,
    footer: @Composable () -> Unit = {},
    headerIcon: ImageBitmap? = null
) {
    val haptics = LocalHapticFeedback.current
    val vibrate = LocalVibrateOnInput.current
    val shake = remember { Animatable(0f) }

    LaunchedEffect(shakeKey) {
        if (shakeKey > 0) {
            if (vibrate) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            repeat(3) {
                shake.animateTo(16f, tween(45))
                shake.animateTo(-16f, tween(45))
            }
            shake.animateTo(0f, tween(45))
        }
    }
    val shakeModifier = Modifier.offset { IntOffset(shake.value.roundToInt(), 0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .then(if (lockType == LockType.PASSWORD) Modifier.imePadding() else Modifier)
            .padding(horizontal = 28.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(8.dp))
        if (headerIcon != null) {
            Image(
                bitmap = headerIcon,
                contentDescription = null,
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(16.dp))
            )
        } else {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Indigo600, Violet500, Cyan400))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(4.dp))
        Box(Modifier.height(40.dp), contentAlignment = Alignment.TopCenter) {
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isError) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
        if (fingerprint != null && fingerprint.mode != FingerprintStatus.Mode.OFF) {
            FingerprintHint(fingerprint, onFingerprintTap)
        }

        when (lockType) {
            LockType.PIN4, LockType.PIN6 ->
                PinPad(lockType.pinLength, resetKey, enabled, shakeModifier, onComplete)
            LockType.PATTERN ->
                PatternPad(resetKey, enabled, isError, shakeModifier, onComplete)
            LockType.PASSWORD ->
                PasswordEntry(resetKey, enabled, isError, shakeModifier, onComplete)
        }
        footer()
    }
}

@Composable
private fun FingerprintHint(status: FingerprintStatus, onTap: (() -> Unit)?) {
    val tappable = status.mode == FingerprintStatus.Mode.TAP_ONLY && onTap != null
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .then(if (tappable) Modifier.clickable { onTap?.invoke() } else Modifier)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.Fingerprint,
            contentDescription = "Fingerprint",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(28.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            status.message ?: if (tappable) "Tap to use fingerprint" else "Touch the sensor to unlock",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---------------------------------------------------------------- PIN pad

@Composable
private fun ColumnScope.PinPad(
    length: Int,
    resetKey: Int,
    enabled: Boolean,
    shakeModifier: Modifier,
    onComplete: (String) -> Unit
) {
    var pin by remember(resetKey, length) { mutableStateOf("") }
    val haptics = LocalHapticFeedback.current
    val vibrate = LocalVibrateOnInput.current
    val latestOnComplete by rememberUpdatedState(onComplete)

    fun press(d: Int) {
        if (!enabled || pin.length >= length) return
        if (vibrate) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        val next = pin + d
        pin = next
        if (next.length == length) latestOnComplete(next)
    }

    fun back() {
        if (enabled && pin.isNotEmpty()) pin = pin.dropLast(1)
    }

    Spacer(Modifier.height(10.dp))
    Row(modifier = shakeModifier, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        repeat(length) { i ->
            val dotColor by animateColorAsState(
                if (i < pin.length) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant,
                label = "dot"
            )
            Box(Modifier.size(14.dp).clip(CircleShape).background(dotColor))
        }
    }

    Spacer(Modifier.weight(1f))

    listOf(listOf(1, 2, 3), listOf(4, 5, 6), listOf(7, 8, 9)).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            row.forEach { d -> KeyButton(d.toString(), enabled) { press(d) } }
        }
        Spacer(Modifier.height(12.dp))
    }
    Row(
        horizontalArrangement = Arrangement.spacedBy(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.size(KeySize))
        KeyButton("0", enabled) { press(0) }
        Box(
            modifier = Modifier
                .size(KeySize)
                .clip(CircleShape)
                .clickable(enabled = enabled) { back() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.AutoMirrored.Filled.Backspace,
                contentDescription = "Delete",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun KeyButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(KeySize)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontSize = 24.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else 0.4f)
        )
    }
}

// ---------------------------------------------------------------- pattern

private fun dotAt(p: Offset, cell: Float): Int? {
    if (p.x < 0f || p.y < 0f) return null
    val col = (p.x / cell).toInt()
    val row = (p.y / cell).toInt()
    if (col !in 0..2 || row !in 0..2) return null
    val dx = p.x - (col + 0.5f) * cell
    val dy = p.y - (row + 0.5f) * cell
    val reach = cell * 0.3f
    return if (dx * dx + dy * dy <= reach * reach) row * 3 + col else null
}

@Composable
private fun ColumnScope.PatternPad(
    resetKey: Int,
    enabled: Boolean,
    isError: Boolean,
    shakeModifier: Modifier,
    onComplete: (String) -> Unit
) {
    var path by remember(resetKey) { mutableStateOf(listOf<Int>()) }
    var dragPos by remember(resetKey) { mutableStateOf<Offset?>(null) }
    val latestOnComplete by rememberUpdatedState(onComplete)
    val primary = MaterialTheme.colorScheme.primary
    val errorColor = MaterialTheme.colorScheme.error
    val idle = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)

    Spacer(Modifier.weight(1f))
    Canvas(
        modifier = shakeModifier
            .size(280.dp)
            .pointerInput(enabled, resetKey) {
                if (!enabled) return@pointerInput
                awaitPointerEventScope {
                    while (true) {
                        val down = awaitFirstDown()
                        path = emptyList()
                        val cell = size.width / 3f
                        fun hit(p: Offset) {
                            val idx = dotAt(p, cell)
                            if (idx != null && idx !in path) path = path + idx
                        }
                        hit(down.position)
                        dragPos = down.position
                        drag(down.id) { change ->
                            dragPos = change.position
                            hit(change.position)
                            change.consume()
                        }
                        dragPos = null
                        if (path.size >= 2) {
                            latestOnComplete(path.joinToString(""))
                        } else {
                            path = emptyList() // an accidental touch: ignore it
                        }
                    }
                }
            }
    ) {
        val cell = size.width / 3f
        fun center(i: Int) = Offset((i % 3 + 0.5f) * cell, (i / 3 + 0.5f) * cell)
        val color = if (isError) errorColor else primary
        val current = dragPos
        val stroke = 8.dp.toPx()
        for (k in 0 until path.size - 1) {
            drawLine(color, center(path[k]), center(path[k + 1]), strokeWidth = stroke, cap = StrokeCap.Round)
        }
        if (current != null && path.isNotEmpty()) {
            drawLine(color, center(path.last()), current, strokeWidth = stroke, cap = StrokeCap.Round)
        }
        for (i in 0..8) {
            val selected = i in path
            if (selected) drawCircle(color.copy(alpha = 0.2f), radius = 30.dp.toPx(), center = center(i))
            drawCircle(
                if (selected) color else idle,
                radius = if (selected) 12.dp.toPx() else 8.dp.toPx(),
                center = center(i)
            )
        }
    }
    Spacer(Modifier.weight(1f))
}

// ---------------------------------------------------------------- password

@Composable
private fun ColumnScope.PasswordEntry(
    resetKey: Int,
    enabled: Boolean,
    isError: Boolean,
    shakeModifier: Modifier,
    onComplete: (String) -> Unit
) {
    var text by remember(resetKey) { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(resetKey) { runCatching { focus.requestFocus() } }

    Spacer(Modifier.height(24.dp))
    OutlinedTextField(
        value = text,
        onValueChange = { text = it },
        modifier = shakeModifier.fillMaxWidth().focusRequester(focus),
        enabled = enabled,
        singleLine = true,
        isError = isError,
        label = { Text("Password") },
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { if (text.isNotEmpty()) onComplete(text) }),
        trailingIcon = {
            TextButton(onClick = { visible = !visible }) { Text(if (visible) "Hide" else "Show") }
        }
    )
    Spacer(Modifier.height(16.dp))
    Button(
        onClick = { if (text.isNotEmpty()) onComplete(text) },
        enabled = enabled && text.isNotEmpty(),
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp)
    ) { Text("Continue") }
    Spacer(Modifier.weight(1f))
}

/** Public entry point: the lock UI, drawn over the chosen photo when there is one. */
@Composable
fun PinEntryScreen(
    title: String,
    message: String,
    isError: Boolean,
    resetKey: Int,
    shakeKey: Int,
    enabled: Boolean,
    onComplete: (String) -> Unit,
    lockType: LockType = LockType.PIN4,
    fingerprint: FingerprintStatus? = null,
    onFingerprintTap: (() -> Unit)? = null,
    footer: @Composable () -> Unit = {},
    headerIcon: ImageBitmap? = null
) {
    val background = LocalLockBackground.current
    if (background == null) {
        EntryContent(
            title, message, isError, resetKey, shakeKey, enabled, onComplete,
            lockType, fingerprint, onFingerprintTap, footer, headerIcon
        )
    } else {
        AppLockerTheme(darkTheme = true) {
            Box(Modifier.fillMaxSize()) {
                Image(
                    bitmap = background,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)))
                EntryContent(
                    title, message, isError, resetKey, shakeKey, enabled, onComplete,
                    lockType, fingerprint, onFingerprintTap, footer, headerIcon
                )
            }
        }
    }
}

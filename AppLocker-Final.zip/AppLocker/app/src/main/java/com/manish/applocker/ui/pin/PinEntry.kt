package com.manish.applocker.ui.pin

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.manish.applocker.security.PinPolicy
import com.manish.applocker.ui.theme.Cyan400
import com.manish.applocker.ui.theme.Indigo600
import com.manish.applocker.ui.theme.Violet500
import kotlin.math.roundToInt

private val KeySize = 76.dp

/**
 * Reusable PIN screen: header, dots, keypad.
 * - Bump [resetKey] to clear the typed digits.
 * - Bump [shakeKey] to play the shake animation (wrong PIN).
 * The same composable will be reused for the per-app lock screen in Phase 3.
 */
@Composable
fun PinEntryScreen(
    title: String,
    message: String,
    isError: Boolean,
    resetKey: Int,
    shakeKey: Int,
    enabled: Boolean,
    onComplete: (String) -> Unit,
    leftKey: @Composable () -> Unit = {},
    footer: @Composable () -> Unit = {},
    headerContent: (@Composable () -> Unit)? = null
) {
    var pin by remember(resetKey) { mutableStateOf("") }
    val haptics = LocalHapticFeedback.current
    val shake = remember { Animatable(0f) }

    LaunchedEffect(shakeKey) {
        if (shakeKey > 0) {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            repeat(3) {
                shake.animateTo(16f, tween(45))
                shake.animateTo(-16f, tween(45))
            }
            shake.animateTo(0f, tween(45))
        }
    }

    fun press(d: Int) {
        if (!enabled || pin.length >= PinPolicy.LENGTH) return
        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        val next = pin + d
        pin = next
        if (next.length == PinPolicy.LENGTH) onComplete(next)
    }

    fun back() {
        if (enabled && pin.isNotEmpty()) pin = pin.dropLast(1)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 32.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        if (headerContent != null) {
            headerContent()
        } else {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Indigo600, Violet500, Cyan400))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        Box(Modifier.height(44.dp), contentAlignment = Alignment.TopCenter) {
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isError) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.offset { IntOffset(shake.value.roundToInt(), 0) },
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            repeat(PinPolicy.LENGTH) { i ->
                val dotColor by animateColorAsState(
                    if (i < pin.length) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceVariant,
                    label = "dot"
                )
                Box(Modifier.size(14.dp).clip(CircleShape).background(dotColor))
            }
        }

        Spacer(Modifier.weight(1f))

        listOf(listOf(1, 2, 3), listOf(4, 5, 6), listOf(7, 8, 9)).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                row.forEach { d -> KeyButton(d.toString(), enabled) { press(d) } }
            }
            Spacer(Modifier.height(16.dp))
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(KeySize), contentAlignment = Alignment.Center) { leftKey() }
            KeyButton("0", enabled) { press(0) }
            Box(
                modifier = Modifier
                    .size(KeySize)
                    .clip(CircleShape)
                    .clickable(enabled = enabled) { back() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Delete",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        footer()
    }
}

@Composable
private fun KeyButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(KeySize)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontSize = 26.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else 0.4f)
        )
    }
}

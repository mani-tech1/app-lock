package com.manish.applocker.ui.pin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.manish.applocker.security.PinPolicy
import com.manish.applocker.ui.theme.Cyan400
import com.manish.applocker.ui.theme.Indigo600
import com.manish.applocker.ui.theme.Violet500
import kotlinx.coroutines.launch

private enum class SetupStep { ENTER, CONFIRM, FINGERPRINT, RECOVERY }

@Composable
fun PinSetupScreen(
    fingerprintAvailable: Boolean,
    onCreatePin: suspend (String) -> Boolean,
    onEnableFingerprint: (onResult: (Boolean) -> Unit) -> Unit,
    recoveryContent: @Composable (onFinished: () -> Unit) -> Unit,
    onDone: () -> Unit
) {
    var step by remember { mutableStateOf(SetupStep.ENTER) }
    var firstPin by remember { mutableStateOf("") }
    var resetKey by remember { mutableIntStateOf(0) }
    var shakeKey by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (step == SetupStep.FINGERPRINT) {
        FingerprintOffer(
            onEnable = { onResult -> onEnableFingerprint(onResult) },
            onSkip = { step = SetupStep.RECOVERY },
            onEnabled = { step = SetupStep.RECOVERY }
        )
        return
    }

    if (step == SetupStep.RECOVERY) {
        recoveryContent(onDone)
        return
    }

    val defaultMessage = if (step == SetupStep.ENTER) {
        "Choose a ${PinPolicy.LENGTH}-digit PIN"
    } else {
        "Enter the same PIN again"
    }

    PinEntryScreen(
        title = if (step == SetupStep.ENTER) "Create your PIN" else "Confirm your PIN",
        message = message.ifEmpty { defaultMessage },
        isError = isError,
        resetKey = resetKey,
        shakeKey = shakeKey,
        enabled = !busy,
        onComplete = { pin ->
            if (step == SetupStep.ENTER) {
                if (PinPolicy.isWeak(pin)) {
                    message = "That PIN is too easy to guess. Try another."
                    isError = true
                    shakeKey++
                    resetKey++
                } else {
                    firstPin = pin
                    message = ""
                    isError = false
                    step = SetupStep.CONFIRM
                    resetKey++
                }
            } else if (pin == firstPin) {
                busy = true
                scope.launch {
                    val ok = onCreatePin(pin)
                    busy = false
                    firstPin = ""
                    if (!ok) {
                        message = "Secure storage failed on this device. Try again."
                        isError = true
                        shakeKey++
                        step = SetupStep.ENTER
                        resetKey++
                    } else if (fingerprintAvailable) {
                        step = SetupStep.FINGERPRINT
                    } else {
                        step = SetupStep.RECOVERY
                    }
                }
            } else {
                message = "PINs did not match. Start again."
                isError = true
                shakeKey++
                firstPin = ""
                step = SetupStep.ENTER
                resetKey++
            }
        }
    )
}

@Composable
private fun FingerprintOffer(
    onEnable: (onResult: (Boolean) -> Unit) -> Unit,
    onSkip: () -> Unit,
    onEnabled: () -> Unit
) {
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Indigo600, Violet500, Cyan400))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Fingerprint, null, tint = Color.White, modifier = Modifier.size(64.dp))
        }
        Spacer(Modifier.height(32.dp))
        Text(
            "Use fingerprint too?",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Unlock faster with your fingerprint. Your PIN always stays as the backup.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(error, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = { onEnable { ok -> if (ok) onEnabled() else error = "Fingerprint was not confirmed." } },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Enable fingerprint") }
        TextButton(onClick = onSkip) { Text("Maybe later") }
    }
}

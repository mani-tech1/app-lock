package com.manish.applocker.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.manish.applocker.ui.components.SpaceBackdrop
import com.manish.applocker.ui.theme.AppLockerTheme
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private val OrbitPurple = Color(0xFF8E54E9)
private val OrbitCyan = Color(0xFF38E8FF)

private class OrbitSpec(
    val part: SettingsPart,
    val label: String,
    val icon: ImageVector,
    val colors: List<Color>
)

private val orbitItems = listOf(
    OrbitSpec(SettingsPart.SECURITY, "Security", Icons.Filled.Lock, listOf(Color(0xFFFFB300), Color(0xFFFF8F00))),
    OrbitSpec(SettingsPart.SMART, "Smart Lock", Icons.Filled.Phone, listOf(Color(0xFF2979FF), Color(0xFF1565C0))),
    OrbitSpec(SettingsPart.ADVANCED, "Advanced", Icons.Filled.Settings, listOf(Color(0xFF6666FF), Color(0xFF4040E0))),
    OrbitSpec(SettingsPart.THEME, "Theme", Icons.Filled.Palette, listOf(Color(0xFFFF7043), Color(0xFFE64A19))),
    OrbitSpec(SettingsPart.FAQ, "FAQ", Icons.Filled.Info, listOf(Color(0xFF26C6DA), Color(0xFF00838F)))
)

private fun partTitle(p: SettingsPart): String = when (p) {
    SettingsPart.SECURITY -> "Password & Security"
    SettingsPart.SMART -> "Smart Lock"
    SettingsPart.ADVANCED -> "Advanced"
    SettingsPart.THEME -> "Theme"
    SettingsPart.FAQ -> "FAQ"
}

/**
 * Settings as an orbit: a glowing lock in space with the setting groups circling it.
 * Tap one to open its panel. [settings] draws the real settings rows for one group.
 */
@Composable
fun OrbitSettingsScreen(
    bottomInset: Dp,
    onClassic: () -> Unit,
    settings: @Composable (SettingsPart?) -> Unit
) {
    val time = remember { mutableFloatStateOf(0f) }
    var panel by remember { mutableStateOf<SettingsPart?>(null) }
    val calm by rememberUpdatedState(panel != null)
    val density = LocalDensity.current.density

    // The orbit slows down while a panel is open.
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0f else ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
                last = now
                time.floatValue += if (calm) dt * 0.15f else dt
            }
        }
    }

    BackHandler(enabled = panel != null) { panel = null }

    Box(Modifier.fillMaxSize()) {
        SpaceBackdrop(Modifier.fillMaxSize()) { time.floatValue }

        BoxWithConstraints(
            Modifier.fillMaxSize().statusBarsPadding().padding(bottom = bottomInset)
        ) {
            val wPx = constraints.maxWidth.toFloat()
            val hPx = constraints.maxHeight.toFloat()
            val rx = min(wPx * 0.36f, 420f * density)
            val ry = rx * 0.5f
            val cy = -hPx * 0.02f

            // the orbit rings and the glowing lock in the middle
            Canvas(Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2f, size.height / 2f + cy)
                val t = time.floatValue
                drawOval(
                    color = OrbitPurple.copy(alpha = 0.30f),
                    topLeft = Offset(c.x - rx, c.y - ry),
                    size = Size(rx * 2f, ry * 2f),
                    style = Stroke(width = 1.5f * density)
                )
                drawOval(
                    color = OrbitCyan.copy(alpha = 0.14f),
                    topLeft = Offset(c.x - rx * 1.22f, c.y - ry * 1.22f),
                    size = Size(rx * 2.44f, ry * 2.44f),
                    style = Stroke(width = 1f * density)
                )
                val breathe = 0.5f + 0.5f * sin(t * 2f)
                val r = 40f * density * (1f + 0.06f * breathe)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            OrbitCyan.copy(alpha = 0.35f + 0.25f * breathe),
                            OrbitPurple.copy(alpha = 0.2f),
                            Color.Transparent
                        ),
                        center = c,
                        radius = r * 2.8f
                    ),
                    radius = r * 2.8f,
                    center = c
                )
                drawCircle(Color(0xCC090419), radius = r, center = c)
                drawCircle(OrbitCyan, radius = r, center = c, style = Stroke(width = 2.5f * density))
                drawLock(c, r * 0.5f, OrbitCyan)
            }

            Text(
                "Tap an orbit icon",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset { IntOffset(0, (cy + 78f * density).roundToInt()) }
            )

            orbitItems.forEachIndexed { i, spec ->
                OrbitItem(
                    spec = spec,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .graphicsLayer {
                            val a = time.floatValue * 0.35f + i * (2f * PI.toFloat() / orbitItems.size)
                            val front = (sin(a) + 1f) / 2f          // 0 = behind, 1 = in front
                            translationX = rx * cos(a)
                            translationY = ry * sin(a) + cy
                            val sc = 0.76f + 0.34f * front
                            scaleX = sc
                            scaleY = sc
                            alpha = 0.62f + 0.38f * front
                        },
                    onClick = { panel = spec.part }
                )
            }
        }

        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Settings",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White
            )
            TextButton(onClick = onClassic) { Text("Classic view", color = OrbitCyan) }
        }

        val open = panel
        if (open != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .pointerInput(Unit) { detectTapGestures { panel = null } }
            )
            AppLockerTheme(darkTheme = true) {
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .fillMaxHeight(0.74f)
                        .padding(bottom = bottomInset),
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xF2100B24))
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp, top = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            partTitle(open),
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        TextButton(onClick = { panel = null }) { Text("Close", color = OrbitCyan) }
                    }
                    Box(Modifier.weight(1f)) { settings(open) }
                }
            }
        }
    }
}

@Composable
private fun OrbitItem(spec: OrbitSpec, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.verticalGradient(spec.colors)),
            contentAlignment = Alignment.Center
        ) {
            Icon(spec.icon, contentDescription = spec.label, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(spec.label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

private fun DrawScope.drawLock(center: Offset, r: Float, color: Color) {
    val bw = r * 0.95f
    val bh = r * 0.72f
    val top = center.y - bh * 0.15f
    drawRoundRect(
        color = color,
        topLeft = Offset(center.x - bw / 2f, top),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(r * 0.14f, r * 0.14f)
    )
    drawArc(
        color = color,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = false,
        topLeft = Offset(center.x - bw * 0.3f, top - bw * 0.3f),
        size = Size(bw * 0.6f, bw * 0.6f),
        style = Stroke(width = r * 0.18f)
    )
}

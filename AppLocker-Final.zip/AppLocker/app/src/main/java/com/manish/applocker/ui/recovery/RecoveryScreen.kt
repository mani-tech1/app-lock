package com.manish.applocker.ui.recovery

import android.accounts.AccountManager
import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.manish.applocker.recovery.RecoveryMode
import com.manish.applocker.recovery.RecoveryStep
import com.manish.applocker.recovery.RecoveryUi
import com.manish.applocker.recovery.RecoveryViewModel
import com.manish.applocker.recovery.googleAccountChooserIntent
import com.manish.applocker.recovery.maskEmail
import com.manish.applocker.ui.theme.Cyan400
import com.manish.applocker.ui.theme.Indigo600
import com.manish.applocker.ui.theme.Violet500

/** Register (or change) the recovery email by choosing a Google account on this phone. */
@Composable
fun RecoverySetupScreen(
    vm: RecoveryViewModel,
    allowSkip: Boolean,
    onFinished: () -> Unit,
    onExit: () -> Unit
) {
    val ui by vm.ui.collectAsState()
    LaunchedEffect(Unit) { vm.begin(RecoveryMode.REGISTER) }
    if (!ui.started || ui.mode != RecoveryMode.REGISTER) {
        Box(Modifier.fillMaxSize())
        return
    }
    RecoveryContent(
        ui = ui,
        vm = vm,
        exitLabel = if (allowSkip) "Set up later" else "Cancel",
        exitNote = if (allowSkip) {
            "Without a recovery email, a forgotten PIN cannot be reset by email."
        } else null,
        onExit = { vm.end(); onExit() },
        onFinished = { vm.end(); onFinished() }
    )
}

/** Shared by the setup flow and the forgot-PIN flow. */
@Composable
fun RecoveryContent(
    ui: RecoveryUi,
    vm: RecoveryViewModel,
    exitLabel: String?,
    exitNote: String?,
    onExit: () -> Unit,
    onFinished: () -> Unit
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val name = r.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
        if (r.resultCode == Activity.RESULT_OK && !name.isNullOrBlank()) vm.onAccountPicked(name)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when (ui.step) {
            RecoveryStep.PICK -> {
                Hero(Icons.Filled.Email)
                Title("Add a recovery email")
                Body(
                    "Choose the Google account on this phone. We will email a 6-digit code to " +
                        "check it is yours. You will use it if you forget your PIN."
                )
                Spacer(Modifier.height(24.dp))
                PrimaryButton("Choose Google account", enabled = !ui.busy) {
                    picker.launch(googleAccountChooserIntent())
                }
                Spacer(Modifier.height(8.dp))
                Body("No Google account yet? The chooser lets you add one.", small = true)
            }

            RecoveryStep.READY -> {
                Hero(Icons.Filled.Email)
                Title("Reset your PIN")
                Body("We will email a 6-digit code to ${ui.email?.let(::maskEmail) ?: "your recovery email"}.")
                Spacer(Modifier.height(24.dp))
                PrimaryButton("Send code", enabled = !ui.busy) { vm.sendCode() }
            }

            RecoveryStep.CODE -> CodeStep(ui, vm)

            RecoveryStep.NO_RECOVERY -> {
                Hero(Icons.Filled.Email)
                Title("No recovery email")
                Body(
                    "A recovery email was never set on this phone, so the PIN cannot be reset " +
                        "by email. Restart the phone in Safe Mode (the guard is off there), then " +
                        "clear App Locker's data in Android Settings. See RECOVERY.md."
                )
            }

            RecoveryStep.DONE -> {
                Hero(Icons.Filled.CheckCircle)
                Title("Recovery email saved")
                Body(ui.email ?: "")
                Spacer(Modifier.height(24.dp))
                PrimaryButton("Continue", enabled = true) { onFinished() }
            }
        }

        if (ui.busy) {
            Spacer(Modifier.height(20.dp))
            CircularProgressIndicator()
            Spacer(Modifier.height(8.dp))
            Body("Contacting the server. The first request can take up to a minute.", small = true)
        }
        if (ui.message != null && ui.step != RecoveryStep.CODE) {
            Spacer(Modifier.height(16.dp))
            Text(
                ui.message,
                color = if (ui.isError) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        if (exitLabel != null && ui.step != RecoveryStep.DONE) {
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onExit) { Text(exitLabel) }
            if (exitNote != null) Body(exitNote, small = true)
        }
    }
}

@Composable
private fun CodeStep(ui: RecoveryUi, vm: RecoveryViewModel) {
    var code by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(ui.errorTick) { code = "" } // clear after a wrong code

    Hero(Icons.Filled.Email)
    Title("Enter the code")
    Body("We emailed a 6-digit code to ${ui.email?.let(::maskEmail) ?: "you"}.")
    Spacer(Modifier.height(20.dp))
    OutlinedTextField(
        value = code,
        onValueChange = { v ->
            if (v.length <= 6 && v.all(Char::isDigit)) {
                code = v
                if (v.length == 6 && !ui.busy) vm.verify(v)
            }
        },
        enabled = !ui.busy,
        singleLine = true,
        textStyle = LocalTextStyle.current.copy(
            fontSize = 28.sp, letterSpacing = 8.sp, textAlign = TextAlign.Center
        ),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .focusRequester(focus)
    )
    Spacer(Modifier.height(10.dp))
    if (ui.message != null) {
        Text(
            ui.message,
            color = if (ui.isError) MaterialTheme.colorScheme.error
            else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
    }
    Spacer(Modifier.height(8.dp))
    TextButton(onClick = { vm.sendCode() }, enabled = ui.resendInSec == 0 && !ui.busy) {
        Text(if (ui.resendInSec > 0) "Resend code in ${ui.resendInSec}s" else "Resend code")
    }
    if (ui.mode == RecoveryMode.REGISTER) {
        TextButton(onClick = { vm.changeAccount() }, enabled = !ui.busy) {
            Text("Use a different account")
        }
    }
}

@Composable
private fun Hero(icon: ImageVector) {
    Box(
        modifier = Modifier
            .size(96.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Indigo600, Violet500, Cyan400))),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
    }
    Spacer(Modifier.height(24.dp))
}

@Composable
private fun Title(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.headlineMedium,
        color = MaterialTheme.colorScheme.onBackground,
        textAlign = TextAlign.Center
    )
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun Body(text: String, small: Boolean = false) {
    Text(
        text,
        style = if (small) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
    )
}

@Composable
private fun PrimaryButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(56.dp),
        shape = RoundedCornerShape(16.dp)
    ) { Text(label) }
}

package com.manish.applocker.ui.apps

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.manish.applocker.data.InstalledApp
import com.manish.applocker.ui.components.EngineBanner
import com.manish.applocker.ui.pin.LocalVibrateOnInput
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private const val ICON_DP = 54f          // icon size in world units (dp)
private const val FOCAL = 700f           // perspective strength
private const val LONG_PRESS_MS = 500L
private const val FLY_SEC = 0.38f
private const val RETURN_SEC = 0.32f

private val Purple = Color(0xFF8E54E9)
private val Cyan = Color(0xFF38E8FF)

private enum class Phase { IDLE, DRAG, FLY, RETURN }

private class Node(
    val app: InstalledApp,
    val x: Float,
    val y: Float,
    val z: Float,        // -300 = very close, +300 = far away
    val phase: Float,
    val speed: Float,
    val tint: Int
)

private class Star(val x: Float, val y: Float, val depth: Float, val size: Float, val phase: Float)

private fun buildNodes(apps: List<InstalledApp>): Pair<List<Node>, Float> {
    val n = max(apps.size, 1)
    val worldR = 60f * sqrt(n.toFloat()) + 60f
    val golden = 2.3999632f
    val list = apps.mapIndexed { i, app ->
        val rnd = Random(app.packageName.hashCode().toLong())
        val r = worldR * sqrt((i + 0.5f) / n)
        val a = i * golden
        Node(
            app = app,
            x = r * cos(a) + (rnd.nextFloat() - 0.5f) * 26f,
            y = r * sin(a) + (rnd.nextFloat() - 0.5f) * 26f,
            z = (rnd.nextFloat() * 2f - 1f) * 280f,
            phase = rnd.nextFloat() * 6.2831f,
            speed = 0.5f + rnd.nextFloat() * 0.6f,
            tint = i % 2
        )
    }
    // far icons first, so near icons are drawn on top
    return list.sortedByDescending { it.z } to worldR
}

private fun buildStars(): List<Star> {
    val r = Random(7)
    return List(110) {
        Star(
            x = r.nextFloat(),
            y = r.nextFloat(),
            depth = 0.2f + r.nextFloat() * 0.8f,
            size = 0.6f + r.nextFloat() * 1.4f,
            phase = r.nextFloat() * 6.28f
        )
    }
}

/** All the moving parts, kept outside Compose state so a frame costs one draw and no recomposition. */
private class Spatial {
    var nodes: List<Node> = emptyList()
    var worldR = 600f
    var locked: Set<String> = emptySet()

    var width = 0f
    var height = 0f
    var density = 1f

    var camX = 0f
    var camY = 0f
    var zoom = 0.85f
    private var velX = 0f
    private var velY = 0f
    private var touching = false

    var time = 0f
    private var lastNanos = 0L

    var targetX = 0f
    var targetY = 0f
    var targetR = 0f
    var hover = 0f
    var pulse = 0f

    var phase = Phase.IDLE
    var active: Node? = null
    var dragX = 0f
    var dragY = 0f
    var dragScale = 1f
    var animFromX = 0f
    var animFromY = 0f
    var animStart = 0f
    private var overTarget = false

    var onHaptic: (Boolean) -> Unit = {}
    var onDropped: (InstalledApp) -> Unit = {}

    val tmp = FloatArray(3)

    fun setSize(w: Float, h: Float, d: Float) {
        width = w
        height = h
        density = d
        targetR = 36f * d
        targetX = w - 22f * d - targetR
        targetY = h - 22f * d - targetR
    }

    /** World -> screen. out = [x, y, scale]. Nearer icons are bigger and move faster (parallax). */
    fun project(n: Node, out: FloatArray) {
        val sp = n.speed
        val bobX = sin(time * sp + n.phase) * 7f
        val bobY = cos(time * sp * 0.83f + n.phase * 1.3f) * 9f
        val wz = n.z + sin(time * sp * 0.5f + n.phase) * 18f
        val s = zoom * (FOCAL / (FOCAL + wz))
        out[0] = width / 2f + (n.x + bobX - camX) * s * density
        out[1] = height / 2f + (n.y + bobY - camY) * s * density
        out[2] = s
    }

    fun hit(px: Float, py: Float): Node? {
        for (i in nodes.indices.reversed()) {   // nearest first
            val n = nodes[i]
            project(n, tmp)
            val half = ICON_DP * density * tmp[2] * 0.58f
            val dx = px - tmp[0]
            val dy = py - tmp[1]
            if (dx * dx + dy * dy <= half * half) return n
        }
        return null
    }

    fun touchStart() {
        touching = true
        velX = 0f
        velY = 0f
    }

    fun touchEnd() {
        touching = false
    }

    fun pan(dx: Float, dy: Float, dtMs: Long) {
        val k = zoom * density
        camX -= dx / k
        camY -= dy / k
        val sec = max(dtMs, 1L) / 1000f
        velX = velX * 0.5f + (-dx / k / sec) * 0.5f
        velY = velY * 0.5f + (-dy / k / sec) * 0.5f
        clampCamera()
    }

    fun zoomBy(f: Float) {
        zoom = (zoom * f).coerceIn(0.4f, 3f)
    }

    private fun clampCamera() {
        val lim = worldR * 0.95f
        camX = camX.coerceIn(-lim, lim)
        camY = camY.coerceIn(-lim, lim)
    }

    fun beginDrag(n: Node, x: Float, y: Float) {
        project(n, tmp)
        dragScale = max(tmp[2], 0.95f) * 1.28f
        active = n
        phase = Phase.DRAG
        dragX = x
        dragY = y
        overTarget = false
        onHaptic(true)
    }

    fun dragTo(x: Float, y: Float) {
        dragX = x
        dragY = y
        val dx = x - targetX
        val dy = y - targetY
        val reach = targetR * 1.3f
        val over = dx * dx + dy * dy <= reach * reach
        if (over && !overTarget) onHaptic(false)
        overTarget = over
    }

    fun endDrag() {
        if (phase != Phase.DRAG) return
        animFromX = dragX
        animFromY = dragY
        animStart = time
        phase = if (overTarget) Phase.FLY else Phase.RETURN
        overTarget = false
    }

    fun step(nanos: Long) {
        val dt = if (lastNanos == 0L) 0.016f
        else ((nanos - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNanos = nanos
        time += dt

        hover += ((if (overTarget) 1f else 0f) - hover) * min(1f, dt * 12f)
        pulse = max(0f, pulse - dt * 2.2f)

        if (!touching && phase == Phase.IDLE && (velX != 0f || velY != 0f)) {
            camX += velX * dt
            camY += velY * dt
            val k = exp(-dt * 3.5f)
            velX *= k
            velY *= k
            if (abs(velX) < 2f) velX = 0f
            if (abs(velY) < 2f) velY = 0f
            clampCamera()
        }

        when (phase) {
            Phase.FLY -> if (time - animStart >= FLY_SEC) {
                val n = active
                phase = Phase.IDLE
                active = null
                pulse = 1f
                if (n != null) onDropped(n.app)
            }
            Phase.RETURN -> if (time - animStart >= RETURN_SEC) {
                phase = Phase.IDLE
                active = null
            }
            else -> Unit
        }
    }
}

@Composable
fun SpatialAppsScreen(
    apps: List<InstalledApp>,
    lockedPackages: Set<String>,
    loading: Boolean,
    engineConnected: Boolean,
    onLockChange: (String, Boolean) -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current.density
    val e = remember { Spatial() }
    val tick = remember { mutableLongStateOf(0L) }
    var hintVisible by remember { mutableStateOf(true) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    val measurer = rememberTextMeasurer()
    val haptics = LocalHapticFeedback.current
    val vibrate = LocalVibrateOnInput.current
    val latestVibrate by rememberUpdatedState(vibrate)

    // What happens when an app is dropped in the circle: really lock (or unlock) it.
    val dropHandler: (InstalledApp) -> Unit = { app ->
        val nowLocked = app.packageName !in lockedPackages
        onLockChange(app.packageName, nowLocked)
        Toast.makeText(
            context,
            if (nowLocked) "${app.label} locked" else "${app.label} unlocked",
            Toast.LENGTH_SHORT
        ).show()
    }
    val latestDrop by rememberUpdatedState(dropHandler)

    val built = remember(apps) { buildNodes(apps) }
    val stars = remember { buildStars() }
    val labelStyle = remember {
        TextStyle(fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Medium)
    }
    val labels = remember(apps, density) {
        apps.associate { app ->
            app.packageName to measurer.measure(
                text = AnnotatedString(app.label),
                style = labelStyle,
                overflow = TextOverflow.Ellipsis,
                maxLines = 1,
                constraints = Constraints(maxWidth = (92f * density).roundToInt())
            )
        }
    }
    val hintStyle = remember { TextStyle(fontSize = 12.sp, color = Cyan, fontWeight = FontWeight.Medium) }
    val hintLock = remember(density) { measurer.measure(text = AnnotatedString("Drop to lock"), style = hintStyle) }
    val hintUnlock = remember(density) { measurer.measure(text = AnnotatedString("Drop to unlock"), style = hintStyle) }

    val bg = remember {
        Brush.verticalGradient(listOf(Color(0xFF080519), Color(0xFF05040F), Color(0xFF020712)))
    }
    val glowA = remember(canvasSize) {
        Brush.radialGradient(
            colors = listOf(Purple.copy(alpha = 0.40f), Color.Transparent),
            center = Offset(canvasSize.width * 0.2f, canvasSize.height * 0.25f),
            radius = max(1f, max(canvasSize.width, canvasSize.height) * 0.75f)
        )
    }
    val glowB = remember(canvasSize) {
        Brush.radialGradient(
            colors = listOf(Cyan.copy(alpha = 0.26f), Color.Transparent),
            center = Offset(canvasSize.width * 0.85f, canvasSize.height * 0.8f),
            radius = max(1f, max(canvasSize.width, canvasSize.height) * 0.65f)
        )
    }

    SideEffect {
        e.nodes = built.first
        e.worldR = built.second
        e.locked = lockedPackages
        e.onHaptic = { strong ->
            if (latestVibrate) {
                haptics.performHapticFeedback(
                    if (strong) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
                )
            }
        }
        e.onDropped = { app -> latestDrop(app) }
    }

    // One frame loop: it only asks the Canvas to redraw, nothing is recomposed.
    LaunchedEffect(e) {
        while (true) {
            withFrameNanos { now ->
                e.step(now)
                tick.longValue = now
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF05040F))) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { s ->
                    canvasSize = s
                    e.setSize(s.width.toFloat(), s.height.toFloat(), density)
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        hintVisible = false
                        e.touchStart()
                        val target = e.hit(down.position.x, down.position.y)

                        // 1 = move the camera, 2 = it was only a tap, null = held for 500 ms
                        var outcome: Int? = 1
                        if (target != null && e.phase == Phase.IDLE) {
                            outcome = withTimeoutOrNull(LONG_PRESS_MS) {
                                var r = 0
                                while (r == 0) {
                                    val event = awaitPointerEvent()
                                    val pressed = event.changes.filter { it.pressed }
                                    if (pressed.isEmpty()) {
                                        r = 2
                                    } else if (pressed.size > 1) {
                                        r = 1
                                    } else if ((pressed[0].position - down.position).getDistance() >
                                        viewConfiguration.touchSlop
                                    ) {
                                        r = 1
                                    }
                                }
                                r
                            }
                        }

                        when (outcome) {
                            null -> {
                                // Held: now the app itself follows the finger.
                                e.beginDrag(target!!, down.position.x, down.position.y)
                                var stillDown = true
                                while (stillDown) {
                                    val event = awaitPointerEvent()
                                    val change = event.changes.firstOrNull { it.id == down.id }
                                    if (change == null || !change.pressed) {
                                        stillDown = false
                                    } else {
                                        e.dragTo(change.position.x, change.position.y)
                                        change.consume()
                                    }
                                }
                                e.endDrag()
                            }
                            2 -> Unit
                            else -> {
                                // One finger pans, two fingers pinch to zoom.
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val pressed = event.changes.filter { it.pressed }
                                    if (pressed.isEmpty()) break
                                    if (pressed.size == 1) {
                                        val c = pressed[0]
                                        val d = c.position - c.previousPosition
                                        e.pan(d.x, d.y, c.uptimeMillis - c.previousUptimeMillis)
                                    } else {
                                        val a = pressed[0]
                                        val b = pressed[1]
                                        val span = (a.position - b.position).getDistance()
                                        val prev = (a.previousPosition - b.previousPosition).getDistance()
                                        if (prev > 1f && span > 1f) e.zoomBy(span / prev)
                                        val mid = ((a.position + b.position) -
                                            (a.previousPosition + b.previousPosition)) / 2f
                                        e.pan(mid.x, mid.y, 16L)
                                    }
                                    event.changes.forEach { it.consume() }
                                }
                            }
                        }
                        e.touchEnd()
                    }
                }
        ) {
            val frame = tick.longValue // reading it makes this draw run every frame
            if (e.width <= 0f || frame < 0L) return@Canvas
            drawSpace(e, stars, labels, hintLock, hintUnlock, bg, glowA, glowB)
        }

        if (loading && apps.isEmpty()) {
            CircularProgressIndicator(color = Cyan, modifier = Modifier.align(Alignment.Center))
        }

        Box(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
            EngineBanner(connected = engineConnected)
        }

        if (hintVisible) {
            Text(
                "Drag to explore, pinch to zoom.\nHold an app, then drop it on the circle to lock it.",
                color = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.align(Alignment.BottomStart).padding(20.dp)
            )
        }
    }
}

// ------------------------------------------------------------------ drawing

private fun DrawScope.drawSpace(
    e: Spatial,
    stars: List<Star>,
    labels: Map<String, TextLayoutResult>,
    hintLock: TextLayoutResult,
    hintUnlock: TextLayoutResult,
    bg: Brush,
    glowA: Brush,
    glowB: Brush
) {
    val w = size.width
    val h = size.height
    val d = e.density
    val t = e.time

    // deep space: dark gradient with slowly breathing purple and cyan light
    drawRect(bg)
    drawRect(glowA, alpha = 0.75f + 0.25f * sin(t * 0.6f))
    drawRect(glowB, alpha = 0.7f + 0.3f * cos(t * 0.5f))

    // particles, they drift a little with the camera (parallax)
    for (s in stars) {
        val px = ((s.x * w - e.camX * s.depth * 0.3f * d) % w + w) % w
        val py = ((s.y * h - e.camY * s.depth * 0.3f * d) % h + h) % h
        val tw = 0.65f + 0.35f * sin(t * 1.6f + s.phase)
        drawCircle(
            color = Color.White.copy(alpha = ((0.18f + 0.55f * s.depth) * tw).coerceIn(0f, 1f)),
            radius = s.size * d * (0.55f + 0.6f * s.depth),
            center = Offset(px, py)
        )
    }

    // floating icons, far to near
    val out = e.tmp
    val active = e.active
    for (n in e.nodes) {
        if (n === active) continue
        e.project(n, out)
        val sx = out[0]
        val sy = out[1]
        val s = out[2]
        val px = ICON_DP * d * s
        if (sx < -px || sx > w + px || sy < -px || sy > h + px) continue
        val depthT = ((n.z + 300f) / 600f).coerceIn(0f, 1f)   // 0 near .. 1 far
        val df = 1f - depthT * 0.5f
        val glow = if (n.tint == 0) Purple else Cyan
        drawCircle(glow.copy(alpha = 0.10f * df), radius = px * 0.78f, center = Offset(sx, sy))
        drawAppIcon(n.app, sx, sy, px, df)
        if (n.app.packageName in e.locked) {
            drawPadlock(Offset(sx + px * 0.36f, sy + px * 0.36f), px * 0.2f, Purple, Color.White)
        }
        if (s >= 0.8f) {
            labels[n.app.packageName]?.let { drawLabel(it, sx, sy + px * 0.5f + 3f * d, df) }
        }
    }

    // the glowing lock target, fixed at the bottom right
    val tr = e.targetR * (1f + 0.12f * e.hover + 0.22f * e.pulse)
    val tc = Offset(e.targetX, e.targetY)
    val breathe = 0.5f + 0.5f * sin(t * 2.2f)
    val haloA = (0.25f + 0.25f * breathe + 0.4f * e.hover + 0.4f * e.pulse).coerceAtMost(0.95f)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Cyan.copy(alpha = haloA), Purple.copy(alpha = haloA * 0.5f), Color.Transparent),
            center = tc,
            radius = tr * 2.4f
        ),
        radius = tr * 2.4f,
        center = tc
    )
    drawCircle(Color(0xCC090419), radius = tr, center = tc)
    drawCircle(
        color = lerp(Cyan, Color.White, e.hover),
        radius = tr,
        center = tc,
        style = Stroke(width = (2.5f + 3.5f * e.hover) * d)
    )
    drawCircle(
        color = Purple.copy(alpha = 0.55f + 0.3f * breathe),
        radius = tr * 0.82f,
        center = tc,
        style = Stroke(width = 1.5f * d)
    )
    drawPadlock(tc, tr * 0.5f, null, lerp(Cyan, Color.White, e.hover))

    val hint = if (active != null && active.app.packageName in e.locked) hintUnlock else hintLock
    drawText(
        textLayoutResult = hint,
        color = Cyan,
        topLeft = Offset(tc.x - hint.size.width / 2f, tc.y - tr - 14f * d - hint.size.height),
        alpha = 0.5f + 0.5f * max(e.hover, if (active != null) 0.6f else 0f)
    )

    // the app being dragged / flying in / returning is drawn on top of everything
    if (active != null) {
        val base = ICON_DP * d
        when (e.phase) {
            Phase.DRAG -> {
                val px = base * e.dragScale
                val c = Offset(e.dragX, e.dragY)
                drawCircle(Cyan.copy(alpha = 0.16f + 0.2f * e.hover), radius = px * 0.95f, center = c)
                drawAppIcon(active.app, c.x, c.y, px, 1f)
                if (active.app.packageName in e.locked) {
                    drawPadlock(Offset(c.x + px * 0.36f, c.y + px * 0.36f), px * 0.2f, Purple, Color.White)
                }
                labels[active.app.packageName]?.let { drawLabel(it, c.x, c.y + px * 0.5f + 3f * d, 1f) }
            }
            Phase.FLY -> {
                val p = ((t - e.animStart) / FLY_SEC).coerceIn(0f, 1f)
                val k = 1f - (1f - p) * (1f - p) * (1f - p)
                val x = lerp(e.animFromX, e.targetX, k)
                val y = lerp(e.animFromY, e.targetY, k)
                val sc = lerp(e.dragScale, 0.15f, k)
                drawAppIcon(active.app, x, y, base * sc, 1f - 0.7f * p * p)
            }
            Phase.RETURN -> {
                e.project(active, out)
                val p = ((t - e.animStart) / RETURN_SEC).coerceIn(0f, 1f)
                val k = 1f - (1f - p) * (1f - p) * (1f - p)
                val x = lerp(e.animFromX, out[0], k)
                val y = lerp(e.animFromY, out[1], k)
                val sc = lerp(e.dragScale, out[2], k)
                drawAppIcon(active.app, x, y, base * sc, 1f)
            }
            else -> Unit
        }
    }
}

private fun DrawScope.drawAppIcon(app: InstalledApp, cx: Float, cy: Float, size: Float, alpha: Float) {
    val sz = max(size.roundToInt(), 1)
    drawImage(
        image = app.icon,
        dstOffset = IntOffset((cx - sz / 2f).roundToInt(), (cy - sz / 2f).roundToInt()),
        dstSize = IntSize(sz, sz),
        alpha = alpha.coerceIn(0f, 1f)
    )
}

private fun DrawScope.drawLabel(layout: TextLayoutResult, cx: Float, top: Float, alpha: Float) {
    drawText(
        textLayoutResult = layout,
        color = Color.White,
        topLeft = Offset(cx - layout.size.width / 2f, top),
        alpha = alpha.coerceIn(0f, 1f)
    )
}

/** A small padlock: used as the "locked" badge and inside the lock target. */
private fun DrawScope.drawPadlock(center: Offset, r: Float, badge: Color?, glyph: Color) {
    if (badge != null) drawCircle(badge, radius = r, center = center)
    val bw = r * 0.95f
    val bh = r * 0.72f
    val top = center.y - bh * 0.15f
    drawRoundRect(
        color = glyph,
        topLeft = Offset(center.x - bw / 2f, top),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(r * 0.14f, r * 0.14f)
    )
    drawArc(
        color = glyph,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = false,
        topLeft = Offset(center.x - bw * 0.3f, top - bw * 0.3f),
        size = Size(bw * 0.6f, bw * 0.6f),
        style = Stroke(width = r * 0.18f)
    )
}

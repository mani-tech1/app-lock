package com.manish.applocker.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Simple on/off settings that the lock screens and the lock engine read instantly. */
object UiPrefs {
    private const val PREFS = "ui_prefs"
    private const val K_VIBRATE = "vibrate_on_input"
    private const val K_LOCK_NEW = "lock_new_apps"
    private const val K_SPATIAL = "spatial_apps"

    private lateinit var prefs: SharedPreferences
    private val _vibrate = MutableStateFlow(true)
    private val _lockNew = MutableStateFlow(true)
    private val _spatial = MutableStateFlow(false)

    val vibrateOnInput: StateFlow<Boolean> = _vibrate.asStateFlow()
    val lockNewApps: StateFlow<Boolean> = _lockNew.asStateFlow()

    /** "3D look of app tab": the Apps tab as a floating 3D launcher. Off by default. */
    val spatialApps: StateFlow<Boolean> = _spatial.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _vibrate.value = prefs.getBoolean(K_VIBRATE, true)
        _lockNew.value = prefs.getBoolean(K_LOCK_NEW, true)
        _spatial.value = prefs.getBoolean(K_SPATIAL, false)
    }

    fun setVibrateOnInput(on: Boolean) {
        _vibrate.value = on
        prefs.edit().putBoolean(K_VIBRATE, on).apply()
    }

    fun setLockNewApps(on: Boolean) {
        _lockNew.value = on
        prefs.edit().putBoolean(K_LOCK_NEW, on).apply()
    }

    fun setSpatialApps(on: Boolean) {
        _spatial.value = on
        prefs.edit().putBoolean(K_SPATIAL, on).apply()
    }
}

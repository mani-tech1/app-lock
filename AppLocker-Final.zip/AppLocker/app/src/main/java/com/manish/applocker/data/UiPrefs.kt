package com.manish.applocker.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Simple on/off settings that the lock screens and the lock engine read instantly. */
object UiPrefs {
    private const val PREFS = "ui_prefs"
    private const val K_VIBRATE = "vibrate_on_input"
    private const val K_LOCK_NEW = "lock_new_apps"
    private const val K_SPATIAL = "spatial_apps"
    private const val K_ORBIT = "orbit_settings"
    private const val K_DELAY = "lock_delay_sec"

    private lateinit var prefs: SharedPreferences
    private val _vibrate = MutableStateFlow(true)
    private val _lockNew = MutableStateFlow(true)
    private val _spatial = MutableStateFlow(false)
    private val _orbit = MutableStateFlow(false)
    private val _delay = MutableStateFlow(0)

    val vibrateOnInput: StateFlow<Boolean> = _vibrate.asStateFlow()
    val lockNewApps: StateFlow<Boolean> = _lockNew.asStateFlow()

    /** "3D look of app tab": the Apps tab as a floating 3D launcher. Off by default. */
    val spatialApps: StateFlow<Boolean> = _spatial.asStateFlow()

    /** "Orbit look of settings tab". Off by default. */
    val orbitSettings: StateFlow<Boolean> = _orbit.asStateFlow()

    /** Seconds before a protected app asks for the lock again after you leave it. 0 = right away. */
    val lockDelaySec: StateFlow<Int> = _delay.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _vibrate.value = prefs.getBoolean(K_VIBRATE, true)
        _lockNew.value = prefs.getBoolean(K_LOCK_NEW, true)
        _spatial.value = prefs.getBoolean(K_SPATIAL, false)
        _orbit.value = prefs.getBoolean(K_ORBIT, false)
        _delay.value = prefs.getInt(K_DELAY, 0)
    }

    fun setVibrateOnInput(on: Boolean) {
        _vibrate.value = on
        prefs.edit().putBoolean(K_VIBRATE, on).apply()
    }

    fun setLockNewApps(on: Boolean) {
        _lockNew.value = on
        prefs.edit().putBoolean(K_LOCK_NEW, on).apply()
    }

    fun setSpatialApps(on: Boolean) {
        _spatial.value = on
        prefs.edit().putBoolean(K_SPATIAL, on).apply()
    }

    fun setOrbitSettings(on: Boolean) {
        _orbit.value = on
        prefs.edit().putBoolean(K_ORBIT, on).apply()
    }

    fun setLockDelaySec(sec: Int) {
        val v = sec.coerceIn(0, 3600)
        _delay.value = v
        prefs.edit().putInt(K_DELAY, v).apply()
    }
}

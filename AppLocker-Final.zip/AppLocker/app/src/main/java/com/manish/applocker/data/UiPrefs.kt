package com.manish.applocker.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Simple on/off settings that the lock screens and the lock engine read instantly. */
object UiPrefs {
    private const val PREFS = "ui_prefs"
    private const val K_VIBRATE = "vibrate_on_input"
    private const val K_LOCK_NEW = "lock_new_apps"

    private lateinit var prefs: SharedPreferences
    private val _vibrate = MutableStateFlow(true)
    private val _lockNew = MutableStateFlow(true)

    val vibrateOnInput: StateFlow<Boolean> = _vibrate.asStateFlow()
    val lockNewApps: StateFlow<Boolean> = _lockNew.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _vibrate.value = prefs.getBoolean(K_VIBRATE, true)
        _lockNew.value = prefs.getBoolean(K_LOCK_NEW, true)
    }

    fun setVibrateOnInput(on: Boolean) {
        _vibrate.value = on
        prefs.edit().putBoolean(K_VIBRATE, on).apply()
    }

    fun setLockNewApps(on: Boolean) {
        _lockNew.value = on
        prefs.edit().putBoolean(K_LOCK_NEW, on).apply()
    }
}

package com.manish.applocker.ui.pin

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.manish.applocker.security.LockType
import com.manish.applocker.security.SecretPolicy
import kotlinx.coroutines.launch

/**
 * Choose a new lock: enter it, enter it again, save it.
 * With [allowTypeChange] a "Lock type" menu sits at the bottom centre
 * (4-digit PIN, 6-digit PIN, Pattern, Password) and the screen changes to match.
 */
@Composable
fun CreateSecretFlow(
    initialType: LockType,
    allowTypeChange: Boolean,
    onSave: suspend (LockType, String) -> Boolean,
    onSaved: () -> Unit,
    extraFooter: (@Composable () -> Unit)? = null
) {
    var type by rememberSaveable { mutableStateOf(initialType) }
    var confirming by remember { mutableStateOf(false) }
    var first by remember { mutableStateOf("") }
    var resetKey by remember { mutableIntStateOf(0) }
    var shakeKey by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun fail(text: String) {
        message = text
        isError = true
        shakeKey++
        resetKey++
    }

    PinEntryScreen(
        title = if (confirming) type.confirmTitle else type.createTitle,
        message = message.ifEmpty { if (confirming) type.confirmHint else type.createHint },
        isError = isError,
        resetKey = resetKey,
        shakeKey = shakeKey,
        enabled = !busy,
        lockType = type,
        onComplete = { secret ->
            if (!confirming) {
                val problem = SecretPolicy.problem(type, secret)
                if (problem != null) {
                    fail(problem)
                } else {
                    first = secret
                    message = ""
                    isError = false
                    confirming = true
                    resetKey++
                }
            } else if (secret == first) {
                busy = true
                scope.launch {
                    val ok = onSave(type, secret)
                    busy = false
                    if (ok) {
                        onSaved()
                    } else {
                        first = ""
                        confirming = false
                        fail("Secure storage failed on this device. Try again.")
                    }
                }
            } else {
                first = ""
                confirming = false
                fail("They did not match. Start again.")
            }
        },
        footer = {
            if (allowTypeChange && !confirming) {
                LockTypeChooser(type) { newType ->
                    type = newType
                    first = ""
                    message = ""
                    isError = false
                    resetKey++
                }
            }
            if (extraFooter != null) extraFooter()
        }
    )
}

/** "Lock type: 4-digit PIN v" - opens a menu with the four lock types. */
@Composable
fun LockTypeChooser(current: LockType, onChange: (LockType) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }) {
            Text("Lock type: ${current.label}  \u25BE")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            LockType.values().forEach { t ->
                DropdownMenuItem(
                    text = { Text(if (t == current) "\u2713  ${t.label}" else t.label) },
                    onClick = {
                        open = false
                        onChange(t)
                    }
                )
            }
        }
    }
}

package com.manish.applocker.ui.protection

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.manish.applocker.admin.ProtectionSnapshot
import com.manish.applocker.admin.UninstallLevel
import com.manish.applocker.security.PinResult
import com.manish.applocker.ui.components.PinConfirmDialog

private val Green = Color(0xFF22C55E)
private val Amber = Color(0xFFF59E0B)

@Composable
fun ProtectionScreen(
    snapshot: ProtectionSnapshot,
    engineRunning: Boolean,
    phoneInfo: String,
    adbCommand: String,
    recoveryEmail: String?,
    onChangeRecovery: () -> Unit,
    onActivateAdmin: () -> Unit,
    verifyPin: suspend (String) -> PinResult,
    onDeactivate: () -> String?,
    onBack: (() -> Unit)? = null
) {
    val level = snapshot.level(engineRunning)
    val clipboard = LocalClipboardManager.current
    var showPinDialog by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var showRecoveryPin by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
            Text(
                "Uninstall protection",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        SectionCard("Uninstall protection") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(if (level == UninstallLevel.STRONG) Green else Amber)
                )
                Spacer(Modifier.size(10.dp))
                Text(level.title, style = MaterialTheme.typography.titleMedium)
            }
            Text(
                level.detail,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            HorizontalDivider()
            DetailRow("Device Admin", if (snapshot.adminActive) "Active" else "Not active", snapshot.adminActive)
            DetailRow("Guard (Accessibility)", if (engineRunning) "Running" else "Off", engineRunning)
            DetailRow("Device Owner", if (snapshot.deviceOwner) "Yes" else "No", snapshot.deviceOwner)
            DetailRow(
                "Android blocks uninstall",
                if (snapshot.uninstallBlocked) "Yes" else "No",
                snapshot.uninstallBlocked
            )
            if (!snapshot.adminActive) {
                Button(
                    onClick = onActivateAdmin,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Activate Device Admin") }
            }
        }

        SectionCard("This phone") {
            Text(phoneInfo, style = MaterialTheme.typography.bodyMedium)
        }

        SectionCard("Device Owner (strongest, optional)") {
            Text(
                "Device Owner is the only way Android itself blocks uninstalling. It is set " +
                    "from a computer with ADB, and Android normally refuses it while any " +
                    "account (Google, Samsung, Xiaomi...) is signed in. If you cannot remove " +
                    "all accounts or reset the phone, skip this: Device Admin plus the guard " +
                    "still works, but it is weaker.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text("1. Settings > About phone > tap Build number 7 times, then turn on USB debugging in Developer options.", style = MaterialTheme.typography.bodyMedium)
            Text("2. Remove every account from the phone (or use a freshly reset phone).", style = MaterialTheme.typography.bodyMedium)
            Text("3. Connect to a computer and run:", style = MaterialTheme.typography.bodyMedium)
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(12.dp)
            ) {
                Text(
                    adbCommand,
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            TextButton(onClick = { clipboard.setText(AnnotatedString(adbCommand)) }) {
                Text("Copy command")
            }
            Text("4. Reopen App Locker. Protection should now say Strong. If it does not, Android refused it: do not assume it worked.", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Warning: Device Owner cannot be removed from Android settings. Only " +
                    "\"Deactivate protection\" below (PIN needed) or a factory reset removes it.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error
            )
        }

        SectionCard("Recovery email") {
            Text(
                recoveryEmail ?: "Not set. If you forget your PIN it cannot be reset by email.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = { showRecoveryPin = true },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text(if (recoveryEmail == null) "Set recovery email" else "Change recovery email") }
            if (showRecoveryPin) {
                PinConfirmDialog(
                    title = "Change recovery email?",
                    message = "Enter your PIN to continue.",
                    verifyPin = verifyPin,
                    onConfirmed = {
                        showRecoveryPin = false
                        onChangeRecovery()
                    },
                    onDismiss = { showRecoveryPin = false }
                )
            }
        }

        SectionCard("Deactivate and recovery") {
            Text(
                "To uninstall App Locker or turn protection off, deactivate it here first. " +
                    "Your PIN is asked again.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = { showPinDialog = true },
                enabled = snapshot.adminActive || snapshot.deviceOwner,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Deactivate protection") }
            resultMessage?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }
            HorizontalDivider()
            Text("If something goes wrong", style = MaterialTheme.typography.titleMedium)
            Text("- Forgot PIN: use \"Forgot PIN?\" on the lock screen; a code is sent to your recovery email.", style = MaterialTheme.typography.bodyMedium)
            Text("- Device Admin only, and no way in: start the phone in Safe Mode, open Settings > Security > Device admin apps, turn off App Locker, then uninstall.", style = MaterialTheme.typography.bodyMedium)
            Text("- Device Owner and no way in: a factory reset is the last resort (a debug build installed from Android Studio can usually be removed with adb; see RECOVERY.md).", style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showPinDialog) {
        PinConfirmDialog(
            title = "Deactivate protection?",
            message = "App Locker will no longer block uninstalling. Enter your PIN to continue.",
            verifyPin = verifyPin,
            onConfirmed = {
                showPinDialog = false
                val error = onDeactivate()
                resultMessage = if (error == null) {
                    "Protection deactivated. You can now uninstall App Locker from Android settings (the guard may still ask for your PIN)."
                } else {
                    "Could not deactivate: $error"
                }
            },
            onDismiss = { showPinDialog = false }
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = if (ok) Green else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

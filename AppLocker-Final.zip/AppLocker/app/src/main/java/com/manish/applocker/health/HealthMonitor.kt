package com.manish.applocker.health

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.manish.applocker.MainActivity
import com.manish.applocker.R
import com.manish.applocker.admin.ProtectionManager
import com.manish.applocker.data.LockedAppsStore
import com.manish.applocker.engine.AppLockService

/**
 * Watches for protection being switched off behind the user's back and says so.
 * Runs: right after boot, every ~15 minutes (a persisted job), and when the lock engine stops.
 * It never "fixes" anything silently: Android only lets the user turn Accessibility on.
 */
object HealthMonitor {
    private const val PREFS = "health"
    private const val K_ALERTS = "alerts_enabled"
    private const val K_ADMIN_WAS_ACTIVE = "admin_was_active"
    private const val CHANNEL = "protection_alerts"
    private const val NOTIFICATION_ID = 4201
    private const val JOB_ID = 4202

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun alertsEnabled(c: Context): Boolean = prefs(c).getBoolean(K_ALERTS, true)

    fun setAlertsEnabled(c: Context, enabled: Boolean) {
        prefs(c).edit().putBoolean(K_ALERTS, enabled).apply()
        if (!enabled) cancel(c)
    }

    /** Remember that Device Admin was on, so losing it later can be reported. */
    fun noteAdmin(c: Context, active: Boolean) {
        if (active) prefs(c).edit().putBoolean(K_ADMIN_WAS_ACTIVE, true).apply()
    }

    /** Call after the user deactivates protection on purpose, so it is not reported as a problem. */
    fun clearAdminMemory(c: Context) {
        prefs(c).edit().putBoolean(K_ADMIN_WAS_ACTIVE, false).apply()
    }

    fun schedule(c: Context) {
        val scheduler = c.getSystemService(JobScheduler::class.java) ?: return
        if (scheduler.allPendingJobs.any { it.id == JOB_ID }) return
        val job = JobInfo.Builder(JOB_ID, ComponentName(c, HealthJobService::class.java))
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true) // survives reboot (needs RECEIVE_BOOT_COMPLETED)
            .build()
        scheduler.schedule(job)
    }

    /** Check again in a moment (Android updates its settings list just after a service stops). */
    fun checkSoon(c: Context) {
        val app = c.applicationContext
        Handler(Looper.getMainLooper()).postDelayed({ check(app) }, 2000)
    }

    fun check(c: Context) {
        val app = c.applicationContext
        LockedAppsStore.init(app)
        val snapshot = ProtectionManager(app).snapshot() // also re-applies the Device Owner uninstall block
        noteAdmin(app, snapshot.adminActive)

        val adminLost = prefs(app).getBoolean(K_ADMIN_WAS_ACTIVE, false) && !snapshot.adminActive
        val hasLockedApps = LockedAppsStore.locked.value.isNotEmpty()
        val engineEnabled = isAccessibilityEnabled(app)
        val engineRunning = AppLockService.connected.value
        // Right after the process starts, the service may not have reconnected yet: give it 2 minutes.
        val processOldEnough =
            SystemClock.elapsedRealtime() - Process.getStartElapsedRealtime() > 120_000
        val engineProblem = hasLockedApps && (!engineEnabled || (!engineRunning && processOldEnough))

        val problems = buildList {
            if (engineProblem) {
                add(
                    if (!engineEnabled) "Accessibility was turned off, so locked apps are NOT protected."
                    else "The lock engine is not running (battery restrictions can stop it)."
                )
            }
            if (adminLost) add("Device Admin was deactivated, so App Locker can be uninstalled.")
        }
        if (problems.isEmpty()) cancel(app) else notify(app, problems)
    }

    private fun isAccessibilityEnabled(c: Context): Boolean {
        val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(c, AppLockService::class.java)
        return enabled.split(':').any {
            it.equals(me.flattenToString(), true) || it.equals(me.flattenToShortString(), true)
        }
    }

    private fun notify(c: Context, problems: List<String>) {
        if (!alertsEnabled(c)) return
        val nm = NotificationManagerCompat.from(c)
        if (!nm.areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Protection alerts", NotificationManager.IMPORTANCE_HIGH)
            c.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(
            c, 0,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = problems.joinToString(" ")
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("App Locker protection needs attention")
            .setContentText(problems.first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(NOTIFICATION_ID, n)
        } catch (e: SecurityException) {
            // Notification permission not granted (Android 13+): nothing we can do silently.
        }
    }

    fun cancel(c: Context) {
        NotificationManagerCompat.from(c).cancel(NOTIFICATION_ID)
    }
}

package com.manish.applocker.recovery

import android.accounts.AccountManager
import android.content.Intent
import android.os.Build
import com.manish.applocker.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

sealed interface ApiResult<out T> {
    data class Ok<T>(val value: T) : ApiResult<T>
    data class Err(
        val code: String,
        val retryAfterSec: Int = 0,
        val attemptsLeft: Int = -1
    ) : ApiResult<Nothing>
}

data class SendOk(val expiresInSec: Int, val resendAfterSec: Int)
data class VerifyOk(val proof: String?)

/** Talks to the OTP backend over HTTPS. The phone never sees any email credentials. */
class RecoveryApi {

    suspend fun sendOtp(
        email: String,
        deviceId: String,
        purpose: String,
        proof: String?
    ): ApiResult<SendOk> {
        val body = JSONObject()
            .put("email", email)
            .put("deviceId", deviceId)
            .put("purpose", purpose)
        if (proof != null) body.put("proof", proof)
        return when (val r = post("/otp/send", body)) {
            is ApiResult.Ok -> ApiResult.Ok(
                SendOk(
                    r.value.optInt("expiresInSec", 600),
                    r.value.optInt("resendAfterSec", 60)
                )
            )
            is ApiResult.Err -> r
        }
    }

    suspend fun verifyOtp(
        email: String,
        deviceId: String,
        purpose: String,
        code: String
    ): ApiResult<VerifyOk> {
        val body = JSONObject()
            .put("email", email)
            .put("deviceId", deviceId)
            .put("purpose", purpose)
            .put("code", code)
        return when (val r = post("/otp/verify", body)) {
            is ApiResult.Ok -> ApiResult.Ok(VerifyOk(r.value.optString("proof").ifEmpty { null }))
            is ApiResult.Err -> r
        }
    }

    private suspend fun post(path: String, body: JSONObject): ApiResult<JSONObject> =
        withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(BuildConfig.BACKEND_URL.trimEnd('/') + path).openConnection()
                    as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20_000
                    readTimeout = 60_000 // free hosts can take ~1 minute to wake up
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val status = conn.responseCode
                val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = try {
                    JSONObject(text)
                } catch (e: JSONException) {
                    null
                }
                when {
                    json == null -> ApiResult.Err(if (status >= 500) "SERVER" else "BAD_RESPONSE")
                    json.optBoolean("ok", false) -> ApiResult.Ok(json)
                    else -> ApiResult.Err(
                        json.optString("error", "SERVER"),
                        json.optInt("retryAfterSec", 0),
                        json.optInt("attemptsLeft", -1)
                    )
                }
            } catch (e: IOException) {
                ApiResult.Err("NETWORK")
            } finally {
                conn?.disconnect()
            }
        }
}

/**
 * Android's own account chooser, limited to Google accounts on this phone.
 * It needs no permission and returns only the account the user taps.
 */
@Suppress("DEPRECATION")
fun googleAccountChooserIntent(): Intent =
    if (Build.VERSION.SDK_INT >= 26) {
        AccountManager.newChooseAccountIntent(
            null, null, arrayOf("com.google"), null, null, null, null
        )
    } else {
        AccountManager.newChooseAccountIntent(
            null, null, arrayOf("com.google"), true, null, null, null, null
        )
    }

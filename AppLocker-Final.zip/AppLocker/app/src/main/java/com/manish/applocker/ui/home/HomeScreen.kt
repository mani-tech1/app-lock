package com.manish.applocker.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.manish.applocker.admin.UninstallLevel
import com.manish.applocker.recovery.maskEmail
import com.manish.applocker.ui.components.EngineBanner

private enum class Level(val color: Color) {
    OK(Color(0xFF22C55E)),
    WARN(Color(0xFFF59E0B)),
    OFF(Color(0xFF9CA3AF))
}

/** Dashboard. Rows for later phases are shown honestly as "not active". */
@Composable
fun HomeScreen(
    lockedCount: Int,
    engineConnected: Boolean,
    uninstallLevel: UninstallLevel,
    recoveryEmail: String?,
    attention: List<String>,
    fingerprintEnabled: Boolean,
    fingerprintAvailable: Boolean,
    onFingerprintToggle: (Boolean) -> Unit,
    onLockNow: () -> Unit
) {
    val fingerprintValue: String
    val fingerprintLevel: Level
    when {
        fingerprintEnabled && fingerprintAvailable -> { fingerprintValue = "On"; fingerprintLevel = Level.OK }
        fingerprintEnabled -> { fingerprintValue = "Enabled, but no fingerprint on device"; fingerprintLevel = Level.WARN }
        else -> { fingerprintValue = "Off"; fingerprintLevel = Level.OFF }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text(
            "App Locker",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = (if (attention.isEmpty()) Level.OK.color else Level.WARN.color).copy(alpha = 0.16f)
            )
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (attention.isEmpty()) "Everything looks good" else "Needs attention",
                    style = MaterialTheme.typography.titleMedium
                )
                attention.forEach { Text("- $it", style = MaterialTheme.typography.bodyMedium) }
            }
        }

        EngineBanner(connected = engineConnected)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Protection overview", style = MaterialTheme.typography.titleMedium)
                StatusRow("PIN", "Active", Level.OK)
                StatusRow(
                    "Lock engine",
                    if (engineConnected) "Running" else "Off - apps are not being locked",
                    if (engineConnected) Level.OK else Level.WARN
                )
                StatusRow(
                    "Locked apps",
                    if (lockedCount == 0) "None selected" else "$lockedCount selected",
                    if (lockedCount > 0) Level.OK else Level.OFF
                )
                StatusRow("Fingerprint", fingerprintValue, fingerprintLevel)
                StatusRow(
                    "Uninstall protection",
                    uninstallLevel.title,
                    if (uninstallLevel == UninstallLevel.STRONG) Level.OK else Level.WARN
                )
                StatusRow(
                    "Recovery email",
                    recoveryEmail?.let { maskEmail(it) } ?: "Not set - a forgotten PIN cannot be reset",
                    if (recoveryEmail != null) Level.OK else Level.WARN
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Unlock with fingerprint", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (fingerprintAvailable) "Your PIN always works as backup."
                        else "Add a fingerprint in Android settings to use this.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = fingerprintEnabled,
                    onCheckedChange = onFingerprintToggle,
                    enabled = fingerprintAvailable || fingerprintEnabled
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onLockNow,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Lock now") }
    }
}

@Composable
private fun StatusRow(label: String, value: String, level: Level) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(level.color))
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

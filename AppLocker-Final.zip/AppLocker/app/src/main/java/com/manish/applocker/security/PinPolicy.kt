package com.manish.applocker.security

object PinPolicy {
    /** Rejects PINs like 1111, 123456, 4321. */
    fun isWeak(pin: String): Boolean {
        if (pin.length < 4 || !pin.all { it.isDigit() }) return true
        val diffs = pin.zipWithNext { a, b -> b - a }
        return diffs.distinct().size == 1 && diffs[0] in -1..1
    }
}

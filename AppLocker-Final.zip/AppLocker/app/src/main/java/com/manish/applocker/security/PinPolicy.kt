package com.manish.applocker.security

object PinPolicy {
    /** Change this one number to switch between 4, 5 or 6 digit PINs. */
    const val LENGTH = 6

    /** Rejects PINs like 111111, 123456, 654321. */
    fun isWeak(pin: String): Boolean {
        if (pin.length != LENGTH || !pin.all { it.isDigit() }) return true
        val diffs = pin.zipWithNext { a, b -> b - a }
        return diffs.distinct().size == 1 && diffs[0] in -1..1
    }
}

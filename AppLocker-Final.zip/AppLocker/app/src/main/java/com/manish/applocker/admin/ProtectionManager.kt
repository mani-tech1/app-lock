package com.manish.applocker.admin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build

enum class UninstallLevel(val title: String, val detail: String) {
    STRONG(
        "Strong",
        "Android itself blocks uninstalling App Locker (Device Owner is active)."
    ),
    PARTIAL(
        "Partial",
        "Device Admin is active and the guard is running. This stops casual removal, " +
            "but it can be bypassed, for example in Safe Mode."
    ),
    WEAK(
        "Weak",
        "Device Admin is active, but the guard is off, so the Android screen that " +
            "deactivates it is not PIN-protected."
    ),
    NONE(
        "Not protected",
        "App Locker can be uninstalled normally. Activate Device Admin to start protecting it."
    )
}

/** What Android actually reports right now. Nothing here is assumed. */
data class ProtectionSnapshot(
    val adminActive: Boolean,
    val deviceOwner: Boolean,
    val uninstallBlocked: Boolean
) {
    fun level(engineRunning: Boolean): UninstallLevel = when {
        deviceOwner && uninstallBlocked -> UninstallLevel.STRONG
        adminActive && engineRunning -> UninstallLevel.PARTIAL
        adminActive -> UninstallLevel.WEAK
        else -> UninstallLevel.NONE
    }
}

class ProtectionManager(context: Context) {

    private val app = context.applicationContext
    private val dpm = app.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(app, AppDeviceAdminReceiver::class.java)

    /** The exact command to run on a computer to make this app Device Owner. */
    val adbCommand: String =
        "adb shell dpm set-device-owner ${admin.flattenToShortString()}"

    fun phoneInfo(): String =
        "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), " +
            "${Build.MANUFACTURER} ${Build.MODEL}"

    /** Reads the real state. If we are Device Owner, (re)applies the uninstall block. */
    fun snapshot(): ProtectionSnapshot {
        val owner = dpm.isDeviceOwnerApp(app.packageName)
        if (owner) {
            runCatching { dpm.setUninstallBlocked(admin, app.packageName, true) }
        }
        val blocked = owner &&
            runCatching { dpm.isUninstallBlocked(admin, app.packageName) }.getOrDefault(false)
        return ProtectionSnapshot(
            adminActive = dpm.isAdminActive(admin),
            deviceOwner = owner,
            uninstallBlocked = blocked
        )
    }

    fun activationIntent(): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            .putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Stops App Locker from being uninstalled without your PIN."
            )

    /**
     * Gives up Device Owner (if held) and Device Admin.
     * @return null on success, otherwise a message describing what failed.
     */
    @Suppress("DEPRECATION")
    fun deactivate(): String? = try {
        if (dpm.isDeviceOwnerApp(app.packageName)) {
            dpm.setUninstallBlocked(admin, app.packageName, false)
            dpm.clearDeviceOwnerApp(app.packageName)
        }
        if (dpm.isAdminActive(admin)) {
            dpm.removeActiveAdmin(admin)
        }
        null
    } catch (e: Exception) {
        e.message ?: "Android refused the request"
    }
}

# App Locker: protection, recovery and deactivation

## What each protection level really means
| Level | What Android does | What can still defeat it |
|---|---|---|
| Strong (Device Owner) | Android refuses to uninstall the app | Factory reset; this app's own "Deactivate protection" (needs PIN) |
| Partial (Device Admin + guard) | Uninstall button is greyed out; the guard asks for the PIN on Settings/uninstall screens | Safe Mode, an unlisted OEM settings screen, switching the Accessibility service off from a path the guard misses |
| Weak (Device Admin only) | Uninstall button is greyed out | Anyone can open the "Device admin apps" screen and turn it off |
| Not protected | nothing | normal uninstall |

The Dashboard and Protection tab show the level Android reports right now. If Device Owner
setup fails, the app says so; it never claims a level it does not have.

## Normal removal (you know your PIN)
1. App Locker > Protection > Deactivate protection > enter PIN.
2. Android Settings > Apps > App Locker > Uninstall (the guard may ask for your PIN first).

## Forgot the PIN
1. Lock screen > Forgot PIN? > Send code. A 6-digit code goes to the recovery email you verified.
2. Enter the code (10 minute expiry, 60 second resend, 5 tries) and choose a new PIN.
- Needs internet and a running backend (see backend/README.md).
- If no recovery email was ever set, a PIN cannot be reset by email. Use Safe Mode:
  restart in Safe Mode (the guard is off there), then Settings > Apps > App Locker >
  Storage > Clear data, which also removes your PIN and locked-apps list.

## Device Admin only, PIN lost, no recovery
1. Restart in Safe Mode (hold the power-off option, press and hold "Power off", confirm).
   Third-party services, including the guard, do not run in Safe Mode.
2. Settings > Security > Device admin apps (name varies by brand) > turn off App Locker.
3. Uninstall App Locker, then restart normally.

## Device Owner provisioning (optional, strongest)
Requirements: PC with ADB, USB debugging on, and normally NO accounts on the phone
(Settings > Accounts: remove Google, Samsung, Xiaomi etc.), or a freshly reset phone.

    adb shell dpm set-device-owner com.manish.applocker/.admin.AppDeviceAdminReceiver

Success prints "Device owner set". Common failures:
- "already some accounts on the device": remove all accounts, retry.
- "already several users" / managed profile: remove extra users, retry.
- Xiaomi/MIUI: also enable "USB debugging (Security settings)".
Reopen the app: Protection must show Strong. If not, it is not protected.

## Removing Device Owner
- In app: Protection > Deactivate protection (PIN needed). This calls clearDeviceOwnerApp().
- If the app or PIN is gone: factory reset.
- Builds that Android Studio installs with Run are usually marked testOnly. For those,
  `adb shell dpm remove-active-admin com.manish.applocker/.admin.AppDeviceAdminReceiver`
  works. Test this on your debug build BEFORE relying on Device Owner. Release APKs
  cannot be removed this way.

## If the guard misses a screen on your phone
Find the package of the screen that uninstalls apps:

    adb shell dumpsys window | grep mCurrentFocus

Add that package to GUARD_PACKAGES in engine/AppLockService.kt.

# Build, install and test App Locker

## 1. Build the APK
1. Install Android Studio (Koala or newer). It brings JDK 17.
2. File > Open > choose the AppLocker folder. Wait for Gradle sync (first time downloads a lot).
3. Optional but needed for email recovery: open `local.properties` (it already has `sdk.dir`)
   and add `BACKEND_URL=https://YOUR-SERVICE.onrender.com` (see backend/README.md).
4. Connect your phone (Settings > About phone > tap Build number 7 times > Developer options >
   USB debugging ON) and press Run, or Build > Build APK(s) and copy
   `app/build/outputs/apk/debug/app-debug.apk` to the phone.
This is a debug-signed APK, fine for your own phone. A Play Store release needs your own signing key.

## 2. First-run checklist (do these in order)
1. Onboarding > create a 6-digit PIN > (optional) fingerprint > choose your Google account >
   enter the emailed code.
2. Apps tab > switch on a few apps (try Settings or a game).
3. Enable the lock engine: tap Enable on the orange banner > open Installed apps > App Locker > ON.
4. Protection tab > Activate Device Admin.
5. Settings tab > open battery settings and allow "No restrictions"; allow Autostart on Xiaomi/Oppo/Vivo.

## 3. Test checklist
- Open a locked app: the lock screen appears. Wrong PIN 5 times: delay countdown.
- Press Home from the lock screen, reopen the app: it asks again.
- Leave App Locker (Home): coming back asks for the PIN again.
- Settings > Apps > App Locker: the PIN screen appears (guard). Uninstall button is greyed out.
- Forgot PIN? > Send code > code arrives > set a new PIN.
- Turn Accessibility off: an alert notification appears within a few seconds.
- Reboot the phone: locked apps are protected again (Android restarts the service by itself).

## 4. If something is wrong
| Problem | Fix |
|---|---|
| Gradle sync / build error | Send me the exact error text |
| Lock screen never appears | Accessibility is off, or the phone's battery saver killed it: see Settings tab |
| Lock appears a moment late | Normal: Android cannot block an app before it is drawn |
| "Backend address is not set" | Add BACKEND_URL to local.properties and rebuild |
| First code takes ~1 minute | Free server was asleep; wait, then Resend |
| Guard misses a Settings screen | See "If the guard misses a screen" in RECOVERY.md |
| Device Owner command fails | Remove all accounts first; see RECOVERY.md |

## 5. What this app cannot do (so you are not surprised)
- Without Device Owner, someone who knows Safe Mode can remove it. The Protection tab says so.
- It cannot lock an app before it appears on screen.
- Accessibility apps are usually rejected by Google Play; sideloading is fine.

## 6. Build the APK on GitHub (no Android Studio needed)
1. Create a GitHub repository and upload the CONTENTS of the AppLocker folder (so `settings.gradle.kts`
   and `.github/workflows/build-apk.yml` sit at the top level of the repo).
2. Optional: Settings > Secrets and variables > Actions > Variables > New variable `BACKEND_URL`.
3. Open the Actions tab > "Build APK" > Run workflow (it also runs on every push to main).
4. When it is green, open the run > Artifacts > download `AppLocker-debug-apk` and install the APK.
If the run is red, open the failed step and send me the error text.
